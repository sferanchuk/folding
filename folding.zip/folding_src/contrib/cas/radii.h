/* extracted from dsspcmbi package by s.f. */

#define ORDER           2
#define RN              1.65
#define RCA             1.87
#define RC              1.76
#define RO              1.4
#define RSIDEATOM       1.8
#define RWATER          1.4
