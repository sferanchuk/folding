
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct FFAAtom
{
	char name[5];
	char type[5];
	double charge;
};

struct FFAAA
{
	char name1;
	char *name3;
	FFAAtom atom[30];
};

static char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIE", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};


char *header = 
"struct FFAAtom\n"
"{\n"
"	char *name;\n"
"	char *type;\n"
"	double charge;\n"
"};\n"
"\n"
"struct FFAAA\n"
"{\n"
"	char name1;\n"
"	char *name3;\n"
"	FFAAtom atom[30];\n"
"};\n"
"\n";

int main()
{
	FFAAA ff[26];
	for ( int c = 0; c < 26; c++ )
	{
		ff[c].name1 = c + 'A';
		ff[c].name3 = a_name[c];
		for ( int ac = 0; ac < 30; ac++ ) ff[c].atom[ac].name[0] = 0;
	}
	char buf[200];
	FILE *ifile = stdin;
	int ac = 0;
	int rc = -1;
	while ( fgets( buf, 200, ifile ) )
	{
		if ( buf[0] == '!' )
		{
			if ( strncmp( buf + 10, ".unit.atoms ", 12 ) == 0 )
			{
				ac = 0;
				for ( rc = 0; rc < 26; rc++ )
				{
					if ( strncmp( a_name[rc], buf + 7, 3 ) == 0 ) break;
				}
				if ( rc == 26 ) rc = -1;
			}
			else rc = -1;
		}
		else if ( strlen( buf ) > 1 && rc != -1 )
		{
			char *p = strtok( buf, " \n\t\"" );
			strcpy( ff[rc].atom[ac].name, p );
			p = strtok( 0, " \n\t\"" );
			strcpy( ff[rc].atom[ac].type, p );
			p = strtok( 0, " \n\t\"" );
			p = strtok( 0, " \n\t\"" );
			p = strtok( 0, " \n\t\"" );
			p = strtok( 0, " \n\t\"" );
			p = strtok( 0, " \n\t\"" );
			p = strtok( 0, " \n\t\"" );
			if ( p == 0 ) fprintf( stderr, "bad charge for %d\n", rc );
			ff[rc].atom[ac].charge = atof( p );
			ac++;
			if ( ac >= 30 ) fprintf( stderr, "bad atom count for %d\n", rc );
		}
	}
	FILE *ofile = stdout;
	fprintf( ofile, header );
	fprintf( ofile, "FFAAA ffamber94[26] = {\n" );
	for ( int c = 0; c < 26; c++ )
	{
		fprintf( ofile, "{ \'%c\', \"%s\", { ", ff[c].name1, ff[c].name3 );
		for ( int ac = 0; ff[c].atom[ac].name[0]; ac++ )
		{
			fprintf( ofile, " { \"%s\", \"%s\", %7.3f }", ff[c].atom[ac].name, ff[c].atom[ac].type, ff[c].atom[ac].charge );
			if ( ff[c].atom[ac+1].name[0] ) fprintf( ofile, "," );
		}
		if ( c < 25 ) fprintf( ofile, "} },\n" );
	}
	fprintf( ofile, "} } };" );
}