
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <vector>
using namespace std;

#include "vector.h"
#include "ff_amb.cpp"
#include "chain.h"

static int tinker2amber[26][30] = {
{ 0, 2, 8, 9, 4, 5, 6, 7, 3, 1 },
{ 0 },
{ 0, 2, 9, 10, 4, 7, 5, 6, 8, 3, 1 },
{ 0, 2, 10, 11, 4, 7, 8, 9, 5, 6, 3, 1 },
{ 0, 2, 13, 14, 4, 7, 10, 11, 12, 5, 6, 8, 9, 3, 1 },
{ 0, 2, 18, 19, 4, 7, 8, 16, 10, 12, 14, 5, 6, 9, 17, 11, 13, 15, 3, 1 },
{ 0, 2, 5, 6, 4, 3, 1 },
{ 0, 2, 15, 16, 4, 7, 8, 13, 9, 11, 5, 6, 14, 10, 12, 3, 1 },
{ 0, 2, 17, 18, 4, 6, 10, 13, 5, 7, 8, 9, 11, 12, 14, 15, 16, 3, 1 },
{ 0 }, 
{ 0, 2, 20, 21, 4, 7, 10, 13, 16, 5, 6, 8, 9, 11, 12, 14, 15, 17, 18, 19, 3, 1 },
{ 0, 2, 17, 18, 4, 7, 9, 13, 5, 6, 8, 10, 11, 12, 14, 15, 16, 3, 1 },
{ 0, 2, 15, 16, 4, 7, 10, 11, 5, 6, 8, 9, 12, 13, 14, 3, 1 },
{ 0, 2, 12, 13, 4, 7, 8, 9, 5, 6, 10, 11, 3, 1 },
{ 0 },
{ 0, 10, 12, 13, 7, 4, 1, 9, 8, 5, 6, 2, 3, 11 },
{ 0, 2, 15, 16, 4, 7, 10, 11, 12, 5, 6, 8, 9, 13, 14, 3, 1 },
{ 0, 2, 22, 23, 4, 7, 10, 13, 15, 16, 19, 5, 6, 8, 9, 11, 12, 14, 17, 18, 20, 21, 3, 1 },
{ 0, 2, 9, 10, 4, 7, 5, 6, 8, 3, 1 },
{ 0, 2, 12, 13, 4, 10, 6, 5, 11, 7, 8, 9, 3, 1 },
{ 0 },
{ 0, 2, 14, 15, 4, 6, 10, 5, 7, 8, 9, 11, 12, 13, 3, 1 },
{ 0, 2, 22, 23, 4, 7, 8, 21, 10, 12, 19, 13, 17, 15, 5, 6, 9, 20, 11, 18, 16, 14, 3, 1 },
{ 0 },
{ 0, 2, 19, 20, 4, 7, 8, 17, 10, 15, 12, 13, 5, 6, 9, 18, 11, 16, 14, 3, 1 },
{ 0 } };

/*
static char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIE", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

const int pdbLineSize = 100;

struct pdbLine
{
	char s[ pdbLineSize ];

	char *lineType() { return s; }
	char *atomNumber() { return s + 7; }
	char *atomType() { return s + 13; }
	char *chainName() { return s + 21; }
	char *aaNumber() { return s + 23; }
	char *aaName() { return s + 17; }
	char *x() { return s + 31; }
	char *y() { return s + 39; }
	char *z() { return s + 47; }
};

void LoadChain( Chain& chain, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	pdbLine line;
	while( ifile && fgets( line.s, pdbLineSize, ifile ) )
	{
		if ( strncmp( line.lineType(), "ATOM", 4 ) ) continue;
		if ( !chain.residue.size() || chain.residue.back().number != atoi( line.aaNumber() ) )
		{
			chain.residue.resize( chain.residue.size() + 1 );
			strncpy( chain.residue.back().name3, line.aaName(), 3 );
			chain.residue.back().name3[3] = 0;
			for ( int lc = 0; lc < 26; lc++ ) if ( strncmp( line.aaName(), a_name[lc], 3 ) == 0 ) chain.residue.back().name1 = lc + 'A';
			chain.residue.back().number = atoi( line.aaNumber() );
		}
		if ( strncmp( line.s + 12, "1H ", 3 ) == 0
			|| strncmp( line.s + 12, "2H ", 3 ) == 0
			//|| strncmp( line.s + 12, "3H ", 3 ) == 0
			|| strncmp( line.s + 13, "OXT", 3 ) == 0 ) continue;
		Atom a;
		memset( a.name, 0, sizeof( a.name ) );
		strncpy( a.name, line.atomType(), strcspn( line.atomType(), " " ) );
		if ( strcmp( a.name, "OXT" ) == 0 ) strcpy( a.name, "O" );
		a.coord = Vector( atof( line.x() ), atof( line.y() ), atof( line.z() ) );
		chain.residue.back().atom.push_back( a );
	}
	if ( ifile ) fclose( ifile );
}
*/
		
// gbalpha, gbbeta, gbgamma, gbneckscale
static double gbparam[8][4] = { 
	{ 1., 0., 0., 0.333 }, 
	{ 1., 0., 0., 0.333 }, 
	{ 0.8, 0, 2.909, 0.333 }, 
	{ 1., 0., 0., 0.333 }, 
	{ 1., 0., 0., 0.333 }, 
	{ 1., 0.8, 2.909, 0.333 }, 
	{ 1., 0., 0., 0.333 }, 
	{ 1.095, 1.907, 2.507, 0.362 } };
 
 
static const char *atypes[5] = { "H", "C", "N", "O", "S" };
static double screening[8][5] = {
	{ 0.85, 0.72, 0.79, 0.85, 0.96 },
	{ 0.85, 0.72, 0.79, 0.85, 0.96 },
	{ 0.85, 0.72, 0.79, 0.85, 0.96 },
	{ 0.85, 0.72, 0.79, 0.85, 0.96 },
	{ 0.85, 0.72, 0.79, 0.85, 0.96 },
	{ 0.85, 0.72, 0.79, 0.85, 0.96 },
	{ 0.85, 0.72, 0.79, 0.85, 0.96 },
	{ 1.09, 0.48, 0.70, 1.06, 0.60 } };
	
static double pcoeff[5][5] = {
	{ 0, 0, 0, 0, 0 },
	{ 3.1, 0.51, -0.159, -0.000198, 0.000164 },
	{ 3.05, 0.73, -0.22, -0.00089, 0.000251 },
	{ 3.0, 0.78, -0.25, -0.0016, 0.00035 },
	{ 3.3, 0.54, -0.19, -0.012, 0.00029 } }; 

	
static double radii[5] = { 1.3, 1.7, 1.55, 1.5, 1.8 };

typedef double doublereal;
typedef int integer;


//extern "C" integer egb_calc_radii__( integer *);

extern "C" int egb_calc_radii_
	( integer *igb, integer *natom, doublereal *x, doublereal *fs, 
	doublereal *reff, doublereal *onereff, doublereal *fsmax,
	doublereal *rgbmax, doublereal *rborn, doublereal *offset, 
	doublereal *gbalpha, doublereal *gbbeta, doublereal *gbgamma, 
	integer *rbornstat, doublereal *rbave, doublereal *rbfluct, 
	doublereal *rbmax, doublereal *rbmin, doublereal *gbneckscale, 
	integer *ncopy, doublereal *rdt );

extern "C" int egb_(doublereal *x,doublereal *f, doublereal *rborn,
	doublereal *fs, doublereal *reff, doublereal *onereff, doublereal *charge,
	integer *iac, integer *ico, integer *numex, integer *natex, 
	doublereal *dcharge, doublereal *cut, integer *ntypes, integer *natom,
	integer *natbel, doublereal *epol, doublereal *eelt, doublereal *evdw, 
	doublereal *esurf, doublereal *dvdl, doublereal *vdwrad, integer *ineighbor,
	doublereal *p1, doublereal *p2, doublereal *p3, doublereal *p4,
    doublereal *rbmax, doublereal *rbmin, doublereal *rbave, doublereal *rbfluct,
	integer *ncopy );
	  
/*
void AmberEnergy( Chain& chain, double& Epol, double& Eelt )
{
	
	integer igb = 5;
	integer natom = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ ) natom += chain.residue[rc].atom.size();
	doublereal *x = new doublereal[ 3 * natom ];
	doublereal *fs = new doublereal[ natom ];
	doublereal *reff = new doublereal[ natom ];
	doublereal *onereff = new doublereal [ natom ];
	doublereal fsmax = 0;
	doublereal rgbmax = 25;
	doublereal *rborn = new doublereal[ natom ];
	doublereal *vdwrad = new doublereal[ natom ];
	doublereal *charge = new doublereal[ natom ];
	doublereal *p1 = new doublereal[ natom ];
	doublereal *p2 = new doublereal[ natom ];
	doublereal *p3 = new doublereal[ natom ];
	doublereal *p4 = new doublereal[ natom ];
	doublereal offset = 0.09;
	doublereal gbalpha = gbparam[igb][0];
	doublereal gbbeta = gbparam[igb][1];
	doublereal gbgamma = gbparam[igb][2];
	integer rbornstat = 0;
	doublereal rbave;
	doublereal rbfluct;
	doublereal rbmax;
	doublereal rbmin;
	doublereal gbneckscale = gbparam[igb][3];
	integer ncopy = 1;
	doublereal rdt = 0;
	
	int acc = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Residue& r = chain.residue[rc];
		FFAAA *aa = ffamber94 + r.name1 - 'A';
		for ( int ac = 0; ac < r.atom.size(); ac++, acc++ )
		{
			if ( !aa->atom[ac].name )
			{
				printf( "bad atom %s %d count at %d %s\n", r.atom[ac].name, ac, rc, r.name3 );
				exit( 1 );
			}
			int at;
			for ( at = 0; at < 5; at++ ) if ( atypes[at][0] == aa->atom[ac].name[0] ) break;
			if ( at == 5 )
			{
				printf( "bad atom type\n" );
				exit( 1 );
			}
			x[ 3 * acc ] = r.atom[ac].coord.x;
			x[ 3 * acc + 1 ] = r.atom[ac].coord.y;
			x[ 3 * acc + 2 ] = r.atom[ac].coord.z;
			rborn[acc] = radii[at];
			vdwrad[acc] = radii[at] + 1.4;
			fs[acc] = ( radii[at] - offset ) * screening[igb][at];
			if ( fsmax < fs[acc] ) fsmax = fs[acc];
			onereff[acc] = 1./ radii[at];
			int aind = tinker2amber[ r.name1 - 'A' ][ ac ];
			if ( aa->atom[aind].name[0] != r.atom[ac].name[0] )
			{
				printf( "tinker2amber mismatch: res = %s %d, atom = %s %d, ambatom = %s %d\n",
					r.name3, rc, r.atom[ac].name, ac, aa->atom[aind].name, aind );
				exit( 1 );
			}
			charge[acc] = aa->atom[aind].charge;
			p1[acc] = pcoeff[at][1];
			p2[acc] = pcoeff[at][2];
			p3[acc] = pcoeff[at][3];
			p4[acc] = pcoeff[at][4];
		}
	}
	egb_calc_radii_( &igb,&natom,x,fs,reff,onereff,&fsmax,&rgbmax, 
        rborn, &offset,&gbalpha,&gbbeta,&gbgamma,&rbornstat, 
        &rbave,&rbfluct,&rbmax,&rbmin, &gbneckscale, &ncopy, &rdt 
        );
	//printf( "charge = %g\n", charge );
	//printf( "reff 100 = %g\n", reff[100] );
	doublereal *f = new doublereal[ 3 * natom ];
	integer *iac = new integer[ natom ];
	memset( iac, 0, natom * sizeof( integer ) );
	integer *ico = new integer[ natom ];
	memset( ico, 0, natom * sizeof( integer ) );
	doublereal cut = 30;
	integer ntypes = 5;
	
	integer *numex = new integer[natom];
	integer *natex;
	integer natbel = 0;
	doublereal epol = 0;
	doublereal eelt = 0;
	doublereal evdw = 0;
	doublereal esurf = 0;
	doublereal dvdl = 0;
	integer *ineighbor = new integer[ natom * natom ];
	memset( ineighbor, 0, natom * sizeof( integer ) );
	
	egb_( x, f, rborn, fs, reff, onereff, charge, iac, ico,numex, 
      natex, charge, &cut, &ntypes, &natom, &natbel, 
      &epol, &eelt, &evdw, &esurf, &dvdl, vdwrad,ineighbor,p1,p2,p3,p4,
      &rbmax, &rbmin, &rbave, &rbfluct, &ncopy );
	  
	Epol = epol;
	Eelt = eelt;
 
	delete[] x ;
	delete[] charge;
	delete[] f;
	delete[] p1;
	delete[] p2;
	delete[] p3;
	delete[] p4;
	delete[] iac;
	delete[] ico;
	delete[] numex;
	delete[] ineighbor;
	delete[] fs;
	delete[] reff;
	delete[] onereff;
	delete[] rborn;
	delete[] vdwrad;
}
*/
inline double sqri( double x ) { return x * x; }

void AmberEnergy( Chain& chain, double& Epol, double& Eelt )
{
	
	/*
	integer igb = 5;
	integer natom = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ ) natom += chain.residue[rc].atom.size();
	doublereal *x = new doublereal[ 3 * natom ];
	doublereal *charge = new doublereal[ natom ];
	
	int acc = 0;
	*/
	Epol = 0;
	Eelt = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Residue& r = chain.residue[rc];
		FFAAA *aa = ffamber94 + r.name1 - 'A';
		for ( int ac = 0; ac < r.atom.size(); ac++ )
		{
			int aind = tinker2amber[ r.name1 - 'A' ][ ac ];
			Vector coord = r.atom[ac].coord;
			double charge = aa->atom[aind].charge;
			for ( int rc1 = 0; rc1 <= rc; rc1++ )
			{
				Residue& r1 = chain.residue[rc1];
				FFAAA *aa1 = ffamber94 + r1.name1 - 'A';
				for ( int ac1 = 0; ac1 < r1.atom.size(); ac1++ )
				{
					if ( rc1 == rc && ac1 >= ac ) break;
					int aind1 = tinker2amber[ r1.name1 - 'A' ][ ac1 ];
					Vector coord1 = r1.atom[ac1].coord;
					double charge1 = aa1->atom[aind1].charge;
					double dist = ( coord - coord1 ).norm();
					Eelt += charge * charge1 / dist;
				}
			}
		}
	}
}