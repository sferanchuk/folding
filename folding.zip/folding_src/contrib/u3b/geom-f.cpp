
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "vector.h"
#include "geom-f.h"


typedef float real;
typedef int integer;
typedef double doublereal;

extern "C" integer u3b_(real *w, real *x, real *y, integer *n, integer *
	mode, real *rms, real *u, real *t, integer *ier);

displacement *FindDisplacement( short N, Vector* first, Vector* second)
{
	if ( N < 3 ) return 0;
	real *x = new real[ 3 * N ];
	real *y = new real[ 3 * N ];
	real *w = new real[ N ];
	for ( int vc = 0; vc < N; vc++ )
	{
		y[ 3 * vc ] = first[vc].x;
		y[ 3 * vc + 1 ] = first[vc].y;
		y[ 3 * vc + 2 ] = first[vc].z;
		x[ 3 * vc ] = second[vc].x;
		x[ 3 * vc + 1 ] = second[vc].y;
		x[ 3 * vc + 2 ] = second[vc].z;
		w[ vc ] = 1.;
	}
	integer n = N;
	integer mode = 1;
	real rms;
	real u[9];
	real t[3];
	integer ier;

	u3b_( w, x, y, &n, &mode, &rms, u, t, &ier );
	delete [] x;
	delete [] y;
	delete [] w;
	if ( ier !=0 && ier != -1 )
	{
		printf( "eg u3b = %d\n", ier );
		return 0;
	}
	displacement *rv = new displacement;
	rv->Shift.x = t[0];
	rv->Shift.y = t[1];
	rv->Shift.z = t[2];
	rv->Turn.xx = u[0];
	rv->Turn.yx = u[1];
	rv->Turn.zx = u[2];
	rv->Turn.xy = u[3];
	rv->Turn.yy = u[4];
	rv->Turn.zy = u[5];
	rv->Turn.xz = u[6];
	rv->Turn.yz = u[7];
	rv->Turn.zz = u[8];
	
	return rv;
}


double FindRmsd( short N, Vector* first, Vector* second)
{
	//if ( N < 3 ) return 0;
	real *x = new real[ 3 * N ];
	real *y = new real[ 3 * N ];
	real *w = new real[ N ];
	for ( int vc = 0; vc < N; vc++ )
	{
		x[ 3 * vc ] = first[vc].x;
		x[ 3 * vc + 1 ] = first[vc].y;
		x[ 3 * vc + 2 ] = first[vc].z;
		y[ 3 * vc ] = second[vc].x;
		y[ 3 * vc + 1 ] = second[vc].y;
		y[ 3 * vc + 2 ] = second[vc].z;
		w[ vc ] = 1.;
	}
	integer n = N;
	integer mode = 0;
	real rms;
	real u[9];
	real t[3];
	integer ier;

	u3b_( w, x, y, &n, &mode, &rms, u, t, &ier );
	delete [] x;
	delete [] y;
	delete [] w;
	return sqrt( rms / N );
}


