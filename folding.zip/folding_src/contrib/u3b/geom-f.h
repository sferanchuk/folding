#ifndef GEOM_H
#define GEOM_H


struct displacement {
  matrix Turn;
  Vector Shift;
  Vector Move(Vector a){ return (Turn * a) + Shift; };
};

displacement *FindDisplacement( short N, Vector* first, Vector* second );
double FindRmsd( short N, Vector* first, Vector* second );

#endif
