
#include "common.h"

//#include "coils.cpp"
//#include "letters.cpp"
#include "contacts.cpp"

int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	int sum1 = 0;
	int sum2 = 0;
	int sum5 = 0;
	int sum6 = 0;
	FILE *ifile = fopen( argv[1], "rt" );
	if ( !ifile ) return 1;
	int letter = -1;
	if ( argc > 2 ) letter = argv[2][0];
	string seq;
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() == "HEADER" ) 
		{
			seq = l.GetString( "SEQ" );
			for ( int c = 0; c < seq.size(); c++ ) if ( seq[c] == letter ) sum5++;
			sum1 += seq.size();
		}
		if ( l.GetType() != "STRUCT" ) continue;
		Line ll;
		if ( l.GetFirst( ll ) ) do
		{
			string conts = ll.GetString( "USCH" );
			for ( int c = 0; c < ll.GetInt( fSize ); c++ )
			{
				sum2 += conts[c] - 'A';
				if ( seq[ ll.GetInt( fFirst ) + c ] == letter )
				{
					sum6 += conts[c] - 'A';
				}
			}
		}
		while ( l.GetNext( ll ) );
	}
	while ( 1 );
	fclose( ifile );
	int sum3 = 0;
	int sum4 = 0;
	for ( int lc = 0; lc < 26; lc++ )
	{
		sum3 += cData[ 0 ][ lc ];
		sum4 += cData[ 1 ][ lc ];
	}
	//printf( "total: exp. %g, theor. %g\n", double( sum2 ) / sum1,  double( sum4 ) / sum3 );
	if ( sum5 > 0 ) 
		//printf( "%c: exp. %g, theor. %g\n", letter, 
		//double( sum6 ) / sum5,  double( cData[ 1 ][ letter - 'A' ] ) / cData[ 0 ][ letter - 'A' ] );
		printf( "cfreq %g\n", ( double( sum6 ) / sum5 
			/ (  double( cData[ 1 ][ letter - 'A' ] ) / cData[ 0 ][ letter - 'A' ] ) )
			/ ( ( double( sum2 ) / sum1 ) / ( double( sum4 ) / sum3 ) ) );
	return 0;
}

