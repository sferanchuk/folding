
#include "common.h"

#include "coils.cpp"
#include "letters.cpp"
#include "contacts.cpp"

int main( int argc, char **argv )
{
	/*
	if ( argc < 2 ) return 1;
	double sum1 = 0;
	double ent1 = 0;
	FILE *ifile = fopen( argv[1], "rt" );
	if ( !ifile ) return 1;
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() != "LAST" ) continue;
		double v = l.GetDouble( "VALUE" );
		sum1 += v;
		ent1 += v * log( v );
	}
	while ( 1 );
	fclose( ifile );
	*/
	/*
	double sum2[ maxLength ] = { 0 };
	double ent2[ maxLength ] = { 0 };
	for ( int lc = 0; lc < maxLength; lc++ )
	{
		for ( int dc = 0; dc < maxDist; dc++ )
		{
			for ( int ac = 0; ac < maxAngle; ac++ )
			{
				double v = coilData[lc][dc][ac];
				if ( v == 0 ) continue;
				sum2[lc] += v;
				ent2[lc] += v * log( v );
			}
		}
	}
	double sum3[3] = { 0 };
	double ent3[3] = { 0 };
	for ( int lc = 0; lc < 26; lc++ )
	{
		for ( int tc = 0; tc < 3; tc++ )
		{
			double v = double( lData[tc][lc] ) / cData[0][lc];
			if ( v == 0 || cData[0][lc] == 0 ) continue;
			sum3[tc] += v;
			ent3[tc] += v * log( v );
		}
	}
	printf( "double cOffset[ maxLength ] = { " );
	for ( int lc = 0; lc < maxLength; lc++ )
	{
		printf( " %6g", ent2[lc]/sum2[lc] );
		if ( lc < maxLength - 1 ) printf( "," );
		else printf( " };\n" );
	}
	*/
	double sum4 = 0;
	double ent4 = 0;
	for ( int lc = 0; lc < 26; lc++ )
	{
		double v = log( double( cData[1][lc] ) / cData[0][lc] / 6.51 );
		double f = double( cData[1][lc] ) / cData[0][lc];
		if ( cData[0][lc] == 0 ) continue;
		sum4 += f;
		ent4 += f * v;
	}
	printf( "contOffest = %g\n", 6.51 * ent4 / sum4 );
	//printf ( "double lOffsets[3] = { %g, %g, %g };\n", ent3[0] / sum3[0], ent3[1] / sum3[1], ent3[2] / sum3[2] );
	return 0;
}

