
#include "common.h"

int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	FILE *ifile = fopen( argv[1], "rt" );
	if ( !ifile ) return 1;
	string name;
	string letter;
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() == rHeader )
		{
			name = l.GetString( fName );
			letter = l.GetString( fLetter );
		}
		if ( l.GetType() == rCoil && l.GetInt( fSS1 ) >= 0 && l.GetInt( fSS2 ) >= 0 )
		{
			Line ll( rCoil );
			ll.PutInt( fSize, l.GetInt( fSize ) );
			ll.PutDouble( fDistance, l.GetDouble( fDistance ) );
			ll.PutDouble( fAngle, l.GetDouble( fAngle ) );
			ll.PutString( fName, name );
			ll.PutString( fLetter, letter );
			ll.PutInt( fOrder, l.GetInt( fOrder ) );
			ll.Write( stdout );
		}
	}
	while ( 1 );
	fclose( ifile );
	return 0;
}



/*

struct HtmlReader
{
	FILE *file;
	char last;
	bool isComment;

	HtmlReader( FILE *ifile )
	{
		file = ifile;
		last = getc( ifile );
		isComment = false;
	}
	bool ReadTag( string& tag, string& text );
};

string TagName( const wxString& tag )
{
	string rv;
	int cnt = 1;
	while ( isalpha( tag[cnt] ) || tag[cnt] == '/' )
	{
		rv.append( 1, tag[cnt] );
		cnt++;
	}
	return rv;
}

string TrimAll( const string& text )
{
	string rv = text;
	int pos = 0;
	while ( pos < rv.size() && isspace( rv[pos] ) ) pos++;
	rv = rv.Right( rv.Length() - pos );
	if ( rv.IsEmpty() ) return rv;
	pos = rv.Length() - 1;
	while ( mIsspace( rv[pos] ) ) pos--;
	rv = rv.Left( pos + 1 );
	return rv;
}

bool HtmlReader::ReadTag( sring& tag, string& text )
{
	if ( last != '<' ) return false;
	tag.clear();
	while ( !feof( file ) )
	{
		tag.append( 1, last );
		if ( tag.Left( 3 ) != "<!-" && tag.Right( 1 ) == ">" || tag.Right( 3 ) == "-->" ) break;
		last = getc( file );
	}
	if ( last == EOF ) return false;
	text.clear();
	last = getc( file );
	while ( !feof( file ) && last != '<' )
	{
		text.append( 1, last );
		last = getc( file );
	}
	return true;
}

int trc;
int tdc;
string pdb;
string chain;

void ProcessPdb

int ReadTag( string& tag, string& value)
{
   	if ( TagName(tag) == "td" )
  	{
  		mtext=value;
		}
  	else if (TagName(tag)=="tr")
  	{
  		if (ic==0) trc++;
  		ic++;
  		tdc=0;
  	}
};


int ReadTable( char *filename )
{
	FILE *ifile = fopen( filename, "rt" );
	if ( !ifile ) 
	{
    	return 0;
    }
	HtmlReader reader(ifile);;
	string tag;
	string value;

	do 
	{
		if ( !reader.ReadTag( tag, value ) ) break;
		ReadTag(tag, value);
	}
	while ( true );
	fclose( ifile );
}
*/