
#include <stdio.h>
#include <stdlib.h>

const int MaxSizeCount = 40;

int main()
{
	FILE *ifile = fopen( "surface.dat", "rt" );
	if ( !ifile ) return 1;
	double res[MaxSizeCount][26] = { 0 };
	int cnt[MaxSizeCount][26] = { 0 };
	char buf[500];
	while ( fgets( buf, 500, ifile ) )
	{
	    int sc = atoi(buf);
	    if ( sc > MaxSizeCount ) continue;
		for ( int lc = 0; lc < 26; lc++ )
		{
			double v = atof( buf + lc * 10 + 6 );
			res[ sc - 1 ][lc] += v;
			if ( v != 0 ) cnt[ sc - 1 ][lc]++;
		}
	}
	fclose( ifile );
	printf( "const int MaxSizeCount = %d;\n", MaxSizeCount );
	printf( "const int SizeStep = 5;\n" );
	printf( "double averageSurface[MaxSizeCount][26] = { \n " );
	for ( int sc = 0; sc < MaxSizeCount; sc++ )
	{
	    printf( "{ " );
	    for ( int lc = 0; lc < 26; lc++ )
	    {
		if ( cnt[sc][lc] > 0 ) res[sc][lc] /= cnt[sc][lc];
		printf( " %8.2f", res[sc][lc] );
		if ( lc < 25 ) printf( " ," );
	    }
	    printf( "}" );
	    if ( sc < MaxSizeCount - 1 ) printf( "," );
	    printf( "\n" );
	}
	printf( "};\n" );
	return 0;
}
	
	