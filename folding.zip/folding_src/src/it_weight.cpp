
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main( int argc, char **argv )
{
	if ( argc < 3 ) return 1;
	double maxW = getenv( "MAXW" ) ? atof( getenv( "MAXW" ) ) : 1.;
	double minW = getenv( "MINW" ) ? atof( getenv( "MINW" ) ) : -1.;
	double curW = getenv( "CURW" ) ? atof( getenv( "CURW" ) ) : 0.;
	FILE *ifile = fopen( argv[1], "rt+" );
	if ( ifile )
	{
		double sumw = 0;
		int cnt = 0;
		char buf[80];
		while ( fgets( buf, 80, ifile ) )
		{
			if ( strncmp( buf, "weight", 6 ) == 0 )
			{
				sumw = 0;
				cnt = 0;
			}
			else if ( strncmp( buf, "cfreq", 5 ) == 0 )
			{
				sumw += atof( buf + 6 );
				cnt++;
			}
		}
		if ( cnt > 0 ) sumw /= cnt;
		if ( sumw > 1 )
		{
			maxW = curW;
		}
		else
		{
			minW = curW;
		}
	}
	else
	{
		ifile = fopen( argv[1], "wt" );
	}
	curW = ( maxW + minW ) * 0.5;
	fprintf( ifile, "weight %g (%g %g)\n", curW, minW, maxW );
	fclose( ifile );
	
	FILE *ofile = fopen( argv[2], "wt" );	
	fprintf( ofile, "export MAXW=%g\nexport MINW=%g\nexport CURW=%g\n", maxW, minW, curW );
	fclose( ofile );
	return 0;
}
		