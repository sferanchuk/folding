
#include "vector.h"

//-------------------------------------------------------------------
Vector to_turn(const Vector& x, const Vector& s, double Fi){
  Vector result, tmp;   //make sure s-normalized
  double Scprod = x*s;     //s-axis , counterclockwise Fi
  tmp = s*Scprod;
  result = tmp + (x - tmp)*cos(Fi) + (s & x)*sin(Fi);
  return result;
}
Vector turn(const Vector& x, const Vector& s, double Cos_, double Sin_){
  Vector result, tmp;      //make sure sin_**2 + cos_**2 = 1; s -normalized.
  double Scprod = x*s;     //s-axis
  tmp = s*Scprod;
  result = tmp + (x - tmp)*Cos_ + (s & x)*Sin_;
  return result;
}

//------------------------------------------------------------------
 matrix::matrix(const Vector& X_, const Vector& Y_, const Vector& Z_, char mode)
  {
  switch(mode){
   case ROW: xx = X_.x; xy = Y_.x; xz = Z_.x;
			 yx = X_.y; yy = Y_.y; yz = Z_.y;
			 zx = X_.z; zy = Y_.z; zz = Z_.z;
			 return;
   case LINE:xx = X_.x; yx = Y_.x; zx = Z_.x;
			 xy = X_.y; yy = Y_.y; zy = Z_.y;
			 xz = X_.z; yz = Y_.z; zz = Z_.z;
			 return;
   default:  matrix();
			 return;
   }
  }
Vector matrix::row(char N){
  switch(N){
   case 1: return Vector(xx, yx, zx);
   case 2: return Vector(xy, yy, zy);
   case 3: return Vector(xz, yz, zz);
   default: return Vector();
   }
  }
Vector matrix::line(char N){
  switch(N){
   case 1: return Vector(xx, xy, xz);
   case 2: return Vector(yx, yy, yz);
   case 3: return Vector(zx, zy, zz);
   default: return Vector();
   }
  }
matrix operator! (const matrix& a)
{
matrix result;
  result.xx = a.xx;
  result.xy = a.yx;
  result.xz = a.zx;
  result.yx = a.xy;
  result.yy = a.yy;
  result.yz = a.zy;
  result.zx = a.xz;
  result.zy = a.yz;
  result.zz = a.zz;
return result;
}
matrix operator+ (const matrix& a, const matrix& b)
{
matrix result;
  result.xx = a.xx + b.xx;
  result.xy = a.xy + b.xy;
  result.xz = a.xz + b.xz;
  result.yx = a.yx + b.yx;
  result.yy = a.yy + b.yy;
  result.yz = a.yz + b.yz;
  result.zx = a.zx + b.zx;
  result.zy = a.zy + b.zy;
  result.zz = a.zz + b.zz;
return result;
}
matrix operator- (const matrix& a, const matrix& b)
{
matrix result;
  result.xx = a.xx - b.xx;
  result.xy = a.xy - b.xy;
  result.xz = a.xz - b.xz;
  result.yx = a.yx - b.yx;
  result.yy = a.yy - b.yy;
  result.yz = a.yz - b.yz;
  result.zx = a.zx - b.zx;
  result.zy = a.zy - b.zy;
  result.zz = a.zz - b.zz;
return result;
}
matrix operator* (const matrix& a, const matrix& b)
{
matrix result;
  result.xx = a.xx*b.xx + a.xy*b.yx + a.xz*b.zx;
  result.xy = a.xx*b.xy + a.xy*b.yy + a.xz*b.zy;
  result.xz = a.xx*b.xz + a.xy*b.yz + a.xz*b.zz;
  result.yx = a.yx*b.xx + a.yy*b.yx + a.yz*b.zx;
  result.yy = a.yx*b.xy + a.yy*b.yy + a.yz*b.zy;
  result.yz = a.yx*b.xz + a.yy*b.yz + a.yz*b.zz;
  result.zx = a.zx*b.xx + a.zy*b.yx + a.zz*b.zx;
  result.zy = a.zx*b.xy + a.zy*b.yy + a.zz*b.zy;
  result.zz = a.zx*b.xz + a.zy*b.yz + a.zz*b.zz;
return result;
}
Vector operator* (const matrix& a, const Vector& b)
{
Vector result;
  result.x = a.xx*b.x + a.xy*b.y + a.xz*b.z;
  result.y = a.yx*b.x + a.yy*b.y + a.yz*b.z;
  result.z = a.zx*b.x + a.zy*b.y + a.zz*b.z;
return result;
}

double dihedral_angle( Vector v1, Vector v2, Vector v3, Vector v4)
{
  /*CALCULATES TORSION ANGLE OF A SET OF 4 ATOMS V1-V2-V3-V4.
    DIHEDRALANGLE IS THE ANGLE BETWEEN THE PROJECTION OF
    V1-V2 AND THE PROJECTION OF V4-V3 ONTO A PLANE NORMAL TO
    BOND V2-V3.*/
  /***/
  double u, v;
  Vector v21, v32, v43, vv2, vv3;

  v21 = v2 - v1;
  v32 = v3 - v2;
  v43 = v4 - v3;
  vv2 = v21 & v32;
  vv3 = v32 & v43;
  u = vv2 * vv3;
  v = ( vv2 * v43 ) * v32.norm();
  return atan2(v, u);
}
