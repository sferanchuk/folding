
#include "common.h"

enum { tC, tH, tE };
const int MaxSize = 25;
const int NumIt = 200;

struct PredPos
{
	double p[3];
};

typedef vector<PredPos> Pred;

int LoadCasp( Pred& pred, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	char buf[100];
	while ( fgets( buf, 100, ifile ) )
	{
		if ( strncmp( buf, "MODEL", 5 ) == 0 ) continue;
		strtok( buf, " " );
		char *tp = strtok( 0, " " );
		char *p = strtok( 0, " " );
		if ( !p ) continue;
		double v = atof( p );
		int t = ( tp[0] == 'C' ) ? tC : ( tp[0] == 'H' ) ? tH : tE;
		PredPos cur;
		cur.p[t] = v;
		for ( int c = 0; c < 3; c++ ) if ( c != t ) cur.p[c] = 0.5 - 0.5 * v;
		pred.push_back( cur );
	}
	fclose ( ifile );
	return 1;
}

int LoadSSPro( Pred& pred, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	char buf[1000];
	fgets( buf, 1000, ifile );
	fgets( buf, 1000, ifile );
	fgets( buf, 1000, ifile );
	for ( int c = 0; c < strlen( buf ) && buf[c] != '\n'; c++ )
	{
		double v = 0.75;
		int t = ( buf[c] == 'C' ) ? tC : ( buf[c] == 'H' ) ? tH : tE;
		PredPos cur;
		cur.p[t] = v;
		for ( int c = 0; c < 3; c++ ) if ( c != t ) cur.p[c] = 0.125;
		pred.push_back( cur );
	}
	fclose ( ifile );
	return 1;
}

int WriteEnergies( Pred& pred, const char *oname )
{
	FILE *ofile = fopen( oname, "wt" );
	if ( !ofile ) return 0;
	for ( int lc = 1; lc <= MaxSize; lc++ )
	{
		vector<short> buf;
		buf.resize( lc );
		for ( int sc = 0; sc + lc <= pred.size(); sc++ )
		{
			double res[ NumIt ];
			double sum = 0;
			for ( int ic = 0; ic < NumIt; ic++ )
			{
				for ( int pc = 0; pc < lc; pc++ )
				{
					buf[pc] = rand() % 3;
				}
				double w = 0;
				for ( int pc = 0; pc < lc; pc++ )
				{
					w += pred[ sc + pc ].p[ buf[pc] ];
				}
				res[ ic ]  = w;
				sum += w;
			}
			sum /= NumIt;
			double ssq = 0;
			for ( int ic = 0; ic < NumIt; ic++ )
			{
				double diff = res[ic] - sum;
				ssq += diff * diff;
			}
			ssq /= NumIt;
			double mdisp = sqrt( ssq );
			for ( int tc = 0; tc < 3; tc++ )
			{
				double w = 0;
				for ( int pc = 0; pc < lc; pc++ )
				{
					w += pred[ sc + pc ].p[tc];
				}
				double energy = ( w - sum ) / mdisp;
				Line l( "SSPRED" );
				l.PutInt( fType, tc );
				l.PutInt( fFirst, sc );
				l.PutInt( fSize, lc );
				l.PutDouble( fValue, energy );
				l.Write( ofile );
			}
		}
	}
	fclose( ofile );
	return 1;
}	

int main( int argc, char **argv )
{
	if ( argc < 3 ) return 1;
	Pred pred;
	if ( !LoadSSPro( pred, argv[1] ) ) return 1;
	if ( !WriteEnergies( pred, argv[2] ) ) return 1;
	return 0;
}
	
	
