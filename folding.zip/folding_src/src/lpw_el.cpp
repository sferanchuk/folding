
#include <dirent.h>

#include "common.h"
#include "counters.h"
#include "chain.h"


#include <map>

#include <pdb++.h>


static const char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

static double aa_conf[] = { 0.438069, 0, 0.251111, 1.24089,  1.2104, 0.421711,  0.41509,
						0.354882,  0.442724, 0,  0.510083,  0.713571,  0.7922, 1.59425,
						0, 0.429024, 1.5923,  2.4284,  0.875718, 0.860051, 0,
						0.824068,  0.702748, 0,  0.823387, 0 };
						
static char *aa_letters = "ACDEFGHIKLMNPQRSTVWY";

double aa_frequences[] = {
        0.085, 0.018, 0.055, 0.066, 0.040,              // A,C,D,E,F
        0.075, 0.022, 0.059, 0.059, 0.094,              // G,H,I,K,L
        0.025, 0.044, 0.052, 0.040, 0.050,              // M,N,P,Q,R
        0.069, 0.060, 0.072, 0.014, 0.034, 0.0   // S,T,V,W,Y,-
        };

int LoadChain2( Chain &chain, const char * fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	if ( !fgets(buf, 256, ifile ) ) return 0;
	PDB *ppdb = new PDB( buf );
	Residue *r = NULL;
	bool model = false;

	do
	{
		PDB& pdb = *ppdb;
		if ( pdb.type() == PDB::ATOM ) 
		{
  			PDB::Atom &a = pdb.atom;
  			if ( a.residue.chainId == '\0' ) a.residue.chainId = ' ';
  			if ( a.residue.insertCode == '\0' ) a.residue.insertCode = ' ';
  			
  			if ( r == NULL || r->number != a.residue.seqNum || r->icode != a.residue.insertCode )
  			{
  				int order = chain.residue.size();
  				chain.residue.resize( order + 1 );
  				r = &( chain.residue.back() );
  				r->number = a.residue.seqNum;
   				r->icode = a.residue.insertCode;
 				strcpy( r->name3, a.residue.name );
				if ( strncmp( r->name3, "HI", 2 ) == 0 ) r->name3[2] = 'S';
				for ( int lc = 0; lc < 26; lc++ ) if ( strncmp( r->name3, a_name[lc], 3 ) == 0 ) r->name1 = lc + 'A';
  			}
  			r->atom.resize( r->atom.size() + 1 );
  			Atom &at = r->atom.back();
  			at.coord = Vector( a.xyz[0], a.xyz[1], a.xyz[2] );
			if ( a.name[0] == ' ' )
			{
				strcpy( at.name, a.name + 1 );
			}
			else strcpy( at.name, a.name );
  		}
		else if ( pdb.type() == PDB::MODEL ) 
		{
			if ( model ) break;
			else model = true;
		}
   		char buf[256];
   		if ( !fgets( buf, 256, ifile ) ) 
   		{
   			fclose( ifile );
   			return 1;
   		}
   		delete ppdb;
   		ppdb = new PDB( buf );
   	}
   	while ( 1 );
   	return 1;
}

typedef float real;
typedef int integer;
typedef short ftnlen;

#include "ff.cpp"
#include "rotamersbb.cpp"

extern "C" integer tinkerside_( char resname[3], real *chi, integer *n0, real *coord, integer *n );

void BuildSide( Residue& rs, Residue& r, Vector cprev, double *cchi )
{
	rs = r;
	real chi[4];
	integer n0 = 40, n;
	real coord[120];
	coord[0] = cprev.x;
	coord[1] = cprev.y;
	coord[2] = cprev.z;
	char resname[3];
	memcpy( resname, r.name3, 3 );
	for ( int ac = 1; ac < 4; ac++ )
	{
		coord[ ac * 3 ] = r.atom[ ac - 1 ].coord.x;
		coord[ ac * 3 + 1 ] = r.atom[ ac - 1 ].coord.y;
		coord[ ac * 3 + 2 ] = r.atom[ ac - 1 ].coord.z;
	}
	for ( int cc = 0; cc < 4; cc++ ) chi[cc] = cchi[cc];
	tinkerside_( resname, chi, &n0, coord, &n );
	FFAA *aa = ffaa + r.name1 - 'A';
	//for ( aa = ffaa; aa < ffaa + 20 && strcmp( aa->name3, r.name3 ); aa++ );
	for ( int ac = 4; ac < n - 1; ac++ )
	{
		if ( !( aa->atom[ ac ].name ) ) break;
		rs.atom.resize( ac + 1 );
		rs.atom[ ac ].coord.x = coord[ ac * 3 ];
		rs.atom[ ac ].coord.y = coord[ ac * 3 + 1 ];
		rs.atom[ ac ].coord.z = coord[ ac * 3 + 2 ];
		strcpy( rs.atom[ ac ].name, aa->atom[ ac ].name );
	}
}


void BuildSide( RotChain& rchain, Chain& chain )
{
	int ssconv[7] = { 0, 1, 1, 1, 1, 2 };
	double dummy[4] = {0};
	rchain.residue.resize( chain.residue.size() );
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Vector cprev;
		if ( rc > 0 && chain.residue[rc].number == chain.residue[rc-1].number + 1 )
			cprev = chain.residue[rc-1].atom[2].coord;
		else
		{
			Vector dir = chain.residue[rc].atom[0].coord - chain.residue[rc].atom[1].coord;
			dir = !dir;
			Vector cdir = chain.residue[rc].atom[1].coord - chain.residue[rc].atom[2].coord;
			Vector ort = cdir - dir * ( cdir * dir );
			ort = !ort;
			cprev = chain.residue[rc].atom[0].coord + dir * 1.41 * 0.5 + ort * 1.41 * 0.866;
		}
			
		int ord = chain.residue[rc].name1 - 'A';
		int type = 1;
		if ( numRotamers[ type ][ ord ] == 0 )
		{
			rchain.residue[rc].r.resize( 1 );
			BuildSide( rchain.residue[rc].r[0], chain.residue[rc], cprev, dummy );
			rchain.residue[rc].r[0].rotamer = 0;
			rchain.residue[rc].r[0].freq = 1;
		}
		else if ( rotamerFrequences[type][ord][0] == 0 )
		{
			rchain.residue[rc].r.resize( 1 );
			BuildSide( rchain.residue[rc].r[0], chain.residue[rc], cprev, &( rotamers[type][ord][0][0] ) );
			rchain.residue[rc].r[0].rotamer = 0;
			rchain.residue[rc].r[0].freq = 1;
		}
		else
		{ 
			int rtc = 0;
			for ( int tc = 0; tc < numRotamers[type][ord]; tc++ )
			{
				if ( rotamerFrequences[type][ord][tc] == 0 ) continue;
				rchain.residue[rc].r.resize( rtc + 1 );
				BuildSide( rchain.residue[rc].r[rtc], chain.residue[rc], cprev, 
					&( rotamers[type][ord][tc][0] ) );
				rchain.residue[rc].r[rtc].rotamer = tc;
				rchain.residue[rc].r[rtc].freq = rotamerFrequences[type][ord][tc];
				rtc++;
			}
		}
		rchain.residue[rc].surface = 0;
	}
}

void BuildSideWithH( Residue& rs, Residue& r, Vector cprev, double *cchi )
{
	rs = r;
	rs.atom.erase( rs.atom.begin() + 4, rs.atom.end() );
	real chi[4];
	integer n0 = 40, n;
	real coord[120];
	coord[0] = cprev.x;
	coord[1] = cprev.y;
	coord[2] = cprev.z;
	char resname[3];
	memcpy( resname, r.name3, 3 );
	if ( strncmp( resname, "HIS", 3 ) == 0 ) resname[2] = 'E';
	for ( int ac = 1; ac < 4; ac++ )
	{
		coord[ ac * 3 ] = r.atom[ ac - 1 ].coord.x;
		coord[ ac * 3 + 1 ] = r.atom[ ac - 1 ].coord.y;
		coord[ ac * 3 + 2 ] = r.atom[ ac - 1 ].coord.z;
	}
	for ( int cc = 0; cc < 4; cc++ ) chi[cc] = cchi[cc];
	tinkerside_( resname, chi, &n0, coord, &n );
	FFAA *aa = ffaa + r.name1 - 'A';
	//for ( aa = ffaa; aa < ffaa + 20 && strcmp( aa->name3, r.name3 ); aa++ );
	for ( int ac = 4; ac < n - 1; ac++ )
	{
		rs.atom.resize( ac + 1 );
		rs.atom[ ac ].coord.x = coord[ ac * 3 ];
		rs.atom[ ac ].coord.y = coord[ ac * 3 + 1 ];
		rs.atom[ ac ].coord.z = coord[ ac * 3 + 2 ];
		if ( ( aa->atom[ ac ].name ) )	strcpy( rs.atom[ ac ].name, aa->atom[ ac ].name );
		else strcpy( rs.atom[ac].name, "H" );
	}
	strncpy( rs.name3, resname, 3 );
	rs.name3[3] = 0;
}
			
void BuildSideWithH( Chain& nchain, Chain& chain )
{
	int ssconv[7] = { 0, 1, 1, 1, 1, 2 };
	double dummy[4] = {0};
	nchain.residue.resize( chain.residue.size() );
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Vector cprev;
		if ( rc > 0 && chain.residue[rc].number == chain.residue[rc-1].number + 1 )
			cprev = chain.residue[rc-1].atom[2].coord;
		else
		{
			Vector dir = chain.residue[rc].atom[0].coord - chain.residue[rc].atom[1].coord;
			dir = !dir;
			Vector cdir = chain.residue[rc].atom[1].coord - chain.residue[rc].atom[2].coord;
			Vector ort = cdir - dir * ( cdir * dir );
			ort = !ort;
			cprev = chain.residue[rc].atom[0].coord + dir * 1.41 * 0.5 + ort * 1.41 * 0.866;
		}
		nchain.residue[rc].name1 = chain.residue[rc].name1;
		nchain.residue[rc].rotamer = chain.residue[rc].rotamer;
		nchain.residue[rc].number = chain.residue[rc].number;
			
		int ord = chain.residue[rc].name1 - 'A';
		int type = 1;
		if ( numRotamers[ type ][ ord ] == 0 )
		{
			BuildSideWithH( nchain.residue[rc], chain.residue[rc], cprev, dummy );
		}
		else
		{ 
			BuildSideWithH( nchain.residue[rc], chain.residue[rc], cprev, 
				&( rotamers[type][ord][ chain.residue[rc].rotamer ][0] ) );
		}
	}
}


char *header = 
"param n:= 20;\n"
"set V := 1..n;\n"
"var w{i in V}, >= 0;\n";
const double lbound = 0;
const double ubound = 5;

char *footer=
//"minimize obj: sum{i in V} w[i];\n"
"solve;\n"
"printf {i in V}: \"TAG TAG %d; VALUE %g;\\n\", i, w[i] > \"el.res\";\n"
"end;\n";

typedef map<int,double> idmap;

struct ST
{
	idmap lp;
	double rp;
	int sign;
};

struct Problem
{
	vector<ST> tst;
	ST obj;
};

static void add( idmap& mmap, int value )
{
	if ( mmap.find( value ) == mmap.end() ) mmap[value] = 1;
	else mmap[value]++;
}

/*
void operator+=( imap& m1, const imap& m2 )
{
	imap::const_iterator it = m2.begin();
	while ( it != m2.end() )
	{
		if ( m1.find( (*it).first ) == m1.end() ) 
		{
			m1[ (*it).first ] = (*it).second;
		}
		else
		{
			m1[ (*it).first ] += (*it).second;
		}
		it++;
	}
}

void operator-=( imap& m1, const imap& m2 )
{
	imap::const_iterator it = m2.begin();
	while ( it != m2.end() )
	{
		imap::iterator it1 = m1.find( (*it).first );
		if ( it1 == m1.end() ) 
		{
			m1[ (*it).first ] = -(*it).second;
		}
		else
		{
			(*it1).second -= (*it).second;
			if ( (*it1).second == 0 ) m1.erase( it1 );
			
		}
		it++;
	}
}

imap operator*( const imap& m1, int factor )
{
	imap rv = m1;
	imap::iterator it = rv.begin();
	while ( it != rv.end() )
	{
		(*it).second *= factor;
		it++;
	}
	return rv;
}

bool Exclude( ST& eq1, ST& eq2, int pos )
{
	if ( eq1.lp.find( pos ) == eq1.lp.end() ) return false;
	ST ex;
	ex.lp = eq1.lp * eq2.lp[pos];
	ex.rp = eq1.rp * eq2.lp[pos];
	ex.lp -= eq2.lp * eq1.lp[pos];
	ex.rp -= eq2.rp * eq1.lp[pos];
//	if ( eq1.lp[pos] < 0 ) ex.sign = - ex.sign;
	eq1 = ex;
	return true;
}

*/
void MakeHeader( char *wname, FILE *ofile )
{
	FILE *ifile = fopen( wname, "rt" );
	int cnt = 1;
	do
	{
		Line l;
		if ( l.Read( ifile ) == eEOF ) break;
		if ( l.GetType() == rHeader ) 
		{
			fprintf( ofile, header, l.GetInt( fTag ) );
			continue;
		}
		/*
		int tag = l.GetInt( fTag );
		if ( tag > 0 )
		{
			fprintf( ofile, "s.t. u%d: w[%d] <= %g + ud;\n", 
				cnt++,
				tag,
				l.GetDouble( fValue ) );
			fprintf( ofile, "s.t. l%d: w[%d] >= %g - ld;\n", 
				cnt++,
				tag,
				l.GetDouble( fValue ) );
		}
		*/
	}
	while ( 1 );
	fclose( ifile );
}

bool PrintImap( idmap& mmap, FILE *ofile )
{
	idmap::iterator it = mmap.begin();
	if ( it == mmap.end() ) return false;
	if ( (*it).second == 1 ) fprintf( ofile, " w[%d] ", (*it).first );
	else fprintf( ofile, " %g * w[%d] ", (*it).second, (*it).first );
	it++;
	while ( it != mmap.end() )
	{
		if ( (*it).second == 1 ) fprintf( ofile, " + w[%d] ", (*it).first );
		else 
		{
			char pm = (*it).second > 0 ? '+' : '-';
			fprintf( ofile, " %c %g * w[%d] ", pm, fabs( (*it).second ), (*it).first );
		}
		it++;
	}
	return true;
}

bool PrintST( ST& st, FILE *ofile )
{
	static int cnt = 1;
	fprintf( ofile, "s.t. cc%d: ", cnt++ );
	PrintImap( st.lp, ofile );
	fprintf( ofile, " %c= %g; \n", (st.sign) ? '>' : '<', st.rp );
}

bool PutProblem( Problem& pr, FILE *ofile )
{
	fprintf( ofile, header );
	for ( int tc = 0; tc < pr.tst.size(); tc++ )
	{
		PrintST( pr.tst[tc], ofile );
	}
	fprintf( ofile, "maximize obj: " );
	PrintImap( pr.obj.lp, ofile );
	fprintf( ofile, ";\n" );
	fputs( footer, ofile );
	return true;
}

int PutProblem2( Problem& pr, FILE *ofile )
{
	char *header = 
		"NAME          unnamed\n"
		"ROWS\n"
		" N  r_n\n";
		//" E  r_a\n";
	fprintf( ofile, header );
	for ( int c = 0; c < pr.tst.size(); c++ )
	{
		fprintf( ofile, " L  r_%d\n", c );
	}
	fprintf( ofile, "COLUMNS\n" );
	for ( int vc = 0; vc < strlen( aa_letters ); vc++ )
	{
		fprintf( ofile, "    var_%-4d  r_n       %g\n", vc, pr.obj.lp[vc] );
		for ( int c = 0; c < pr.tst.size(); c++ )
		{
			if ( pr.tst[c].lp.find( vc ) == pr.tst[c].lp.end() ) continue;
			fprintf( ofile, "    var_%-4d  r_%-6d  %g\n", vc, c, pr.tst[c].lp[vc] );
		}
	}
	
	fprintf( ofile, "RHS\n" );
	for ( int c = 0; c < pr.tst.size(); c++ )
	{
		fprintf( ofile, "    RHS       r_%-6d  %g\n", c, pr.tst[c].rp );
	}
	fprintf( ofile, "BOUNDS\n" );
	for ( int vc = 0; vc < strlen( aa_letters ); vc++ )
	{
	    fprintf( ofile," LO BND       var_%-4d  %g\n", vc, 0. );
	}
	fprintf( ofile, "ENDATA\n" );
	return 1;
}

bool PredictSide( Chain& chain, RotChain& rchain );

void AmberEnergy( Chain& chain, double& Epol, double& Eelt );

void ProcessSet( const char *pdbPath, FILE *ofile )
{
	DIR *pdbdir = opendir( pdbPath );
	Problem pr;
	do
	{
		struct dirent *dp;
		dp = readdir( pdbdir );
		if ( !dp ) break;
		const char *fname = dp->d_name;
		Chain chain;
		if ( !LoadChain2( chain, ( string( pdbPath ) + "/" + string( fname ) ).data() ) ) continue;
		Chain pchain = chain;
		int rcc = 0;
		for ( int rc = 0; rc < chain.residue.size(); rc++ )
		{
			pchain.residue[rcc].atom.resize(4);
			int flag = 0;
			for ( int ac = 0; ac < chain.residue[rc].atom.size(); ac++ )
			{
				Atom& a = chain.residue[rc].atom[ac];
				if ( strcmp( a.name, "N" ) == 0 ) { pchain.residue[rcc].atom[0] = a; flag = flag | 1; }
				if ( strcmp( a.name, "CA" ) == 0 ) { pchain.residue[rcc].atom[1] = a; flag = flag | 2; }
				if ( strcmp( a.name, "C" ) == 0 ) { pchain.residue[rcc].atom[2] = a; flag = flag | 4; }
				if ( strcmp( a.name, "O" ) == 0 ) { pchain.residue[rcc].atom[3] = a; flag = flag | 8; }
			}
			if ( flag == 15 ) rcc++;
			else pchain.residue.erase( pchain.residue.begin() + rcc );
		}
		RotChain rchain;
		BuildSide( rchain, pchain );
		Chain nchain;
		nchain.residue.resize( pchain.residue.size() );
		PredictSide( nchain, rchain );
		Chain hchain;
		BuildSideWithH( hchain, nchain );
		double Epol, Eelt, Ecys;
		AmberEnergy( hchain, Epol, Eelt );
		printf( "%g\n", Eelt );
		ST st;
		st.rp = -Eelt;
		if ( fabs( Eelt ) < 0.0001 ) continue;
		bool bad = false;
		for ( int rc = 0; rc < chain.residue.size(); rc++ )
		{
			char *pn = strchr( aa_letters, chain.residue[rc].name1 );
			if ( !pn || chain.residue[rc].name1 == 'U' ) 
			{
				bad = true;
				break;
			}
			int num = pn - aa_letters;
			add( st.lp, num );
		}
		if ( bad ) continue;
		st.sign = false;
		pr.tst.push_back( st );
	}
	while ( 1 );
	closedir( pdbdir );
	for ( int l = 0; l < strlen( aa_letters ); l++ )
	{
		ST st;
		st.rp = 0;
		st.sign = true;
		st.lp[l] = 1;
		//pr.tst.push_back( st );
		pr.obj.lp[ l ] = aa_frequences[ l ];
	}
	PutProblem2( pr, ofile );
}
/*

int ProcessStructure( const char *wname, const char *sname, char letter, Problem& pr )
{
	char cmd[200];
	sprintf( cmd, "./pdb2seq -p%s.pdb -c%c -otmp.seq", sname, letter );
	if ( system( cmd ) ) return 0;
	sprintf( cmd, "./enum %s tmp.seq tmp.pw", wname );
	if ( system( cmd ) ) return 0;
	imap pmap;
	FILE *ifile = fopen( "tmp.pw", "rt" );
	do
	{
		Line l;
		int code = l.Read( ifile );
		if ( code == eEOF ) break;
		if ( code == eEOREC )
		{
			ST nst;
			nst.lp = pr.tst.back().lp;
			nst.lp -= pmap;
			nst.rp = 0.5;
			pr.ust.push_back( nst );
			pmap.clear();
			continue;
		}
		if ( code != eOK ) return 0;
		if ( l.GetType() == fTag )
		{
			int tag = l.GetInt( fTag );
			add( pmap, tag );
		}
	}
	while ( 1 );
	return 1;
}
	
void UpdateWeights( char *wname, char *oname, Problem& pr )
{
	map<int, double> wmap;
	FILE *wfile = fopen( "tmp.res", "rt" );
	double norm = 0;
	int cnt = 0;
	double step = 10.;
	do
	{
		Line l;
		if ( l.Read( wfile ) == eEOF ) break;
		double w = l.GetDouble( fValue );
		wmap[ l.GetInt( fTag ) ] = w;
		norm += w;
		cnt++;
	}
	while( 1 );
	fclose( wfile );
	
	for ( int ec = pr.est.size() - 1; ec >= 0; ec-- )
	{
		double sum = pr.est[ec].rp;
		imap::iterator it = pr.est[ec].lp.begin();
		for ( it++; it != pr.est[ec].lp.end(); it++ )
		{
			sum -= wmap[ (*it).first ] * (*it).second;
		}
		sum /= ( *pr.est[ec].lp.begin() ).second;
		wmap[ pr.epos[ec] ] = sum;
	}
	
	FILE *ifile = fopen( wname, "rt" );
	FILE *ofile = fopen( oname, "wt" );
	do
	{
		Line l;
		if ( l.Read( ifile ) == eEOF ) break;
		if ( l.GetString( fValue ).size() 
			&& l.GetString( fTag ).size() ) 
			l.PutDouble( fValue, 
				//l.GetDouble( fValue ) 
				//- step / cnt 
				wmap[ l.GetInt( fTag ) ] );
		l.Write( ofile );
	}
	while ( 1 );
	fclose( ifile );
	fclose( ofile );
}
*/

int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	
	FILE *lfile = fopen( "el1.mod", "wt" );
	//MakeHeader( wname, lfile );
	ProcessSet( argv[1], lfile );
	fclose( lfile );
	//system( "glpsol --math tmp.mod" );
	return 0;
}
