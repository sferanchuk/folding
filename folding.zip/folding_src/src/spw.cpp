
// simulate pathway

#include "common.h"

struct Leaf
{
	int type;
	int order;
	int first;
	int size;
	int coil;
	double dist;
};

enum { cBeta, cHydr, cCys };

struct Contact
{
	int beta;
	int cys;
	double hydr;
	Contact() { beta = cys = 0; hydr = 0; }
};

struct Input
{
	vector<Leaf> leaf;
	vector<Contact> contact;
	Contact& GetContact( int n1, int n2 )
	{
		if ( n1 < n2 ) return contact[ n1 * leaf.size() + n2 ];
		else return contact[ n2 * leaf.size() + n1 ];
	}
};

struct Node
{
	int leaf;
	int n1;
	int n2;
};

bool operator==( const Node& n1, const Node& n2 )
{
	return n1.leaf == n2.leaf && ( n1.leaf != -1 || n1.n1 == n2.n1 && n1.n2 == n2.n2 );
}

struct Pathway
{
	Input *input;
	vector<Node> node;
	vector<int> stack;
	
	double energy;
	double prevEnergy;
	double flux;
	double prevFlux;
};

struct Cash
{
	vector<Pathway*> pathway;
	~Cash() { for ( int pc = 0; pc < pathway.size(); pc++ ) delete pathway[pc]; }
};

//------------------------------------------------------------------------------

#include "distr.cpp"

const double energyFactor1 = 8.31 * 300. / 42000.; // RT, kkal/mol

double SelEnergy( double length, double dist )
{
	dist /= 3.5;

	int il = (int)length - 3;
	if ( il < 0 ) return 0;
	if ( il >= 20 ) il = 20;
	int id = (int)( dist * 2 );
	if ( id < 0 ) return 0;
	if ( id >= 40 ) id = 40;
	double v = ldistr[il][id];
	if ( v <= 1e-6 ) return 0;
	return ( log( v ) ) * energyFactor1;
}

const double hydrEnergy = 1.4 / 100; // kkal/mol/A^2
const double HHEnergy = 5;     // kkal/mol/contact
const double lengthFactor = 4; // kkal/mol/residue
const double CysEnergy = 25;   // kkal/mol
const double AlphaFactor = 1;  // kkal/mol/residue
const double BetaFactor = 2;   // kkal/mol/residue
const double DecayFactor = 3;  // kkal/mol/residue

/*
���� ������������� ����������� ���� ��� 
�������������� ������ ���� ��������
��� ���� ������� ���, ������� � ��� ����
����. ��� ���� ����� ������������
(�����HHEnergy - ��� ���� ����� )
����� � ���������� ( �����hydrEnergy )
����� � �������� ( �����CysEnergy )
������ ����� ���������� ( �����lengthFactor -
������������ �HHEnergy )
�������������������( ��� SelEnergy ).
����, ����-��� ����� ��� ����-����
������ ������ AlphaFactor �BetaFactor - ������� ���� ������ ����.
����, ������� ��-���� ����� ��� ����� �����
�� ����� � � ���� DecayFactor.

s.f. �� 2008
*/ 

double CalcContactEnergy( Pathway& p, int node1, int node2 )
{
	double rv = 0;
	int leaf1, leaf2;
	if ( ( leaf1 = p.node[node1].leaf ) != -1 )
	{
		if ( ( leaf2 = p.node[node2].leaf ) != -1 )
		{
			Contact& c = p.input->GetContact( leaf1, leaf2 );
			if ( c.cys ) return CysEnergy;
			if ( c.beta ) return HHEnergy * c.beta; // ??!!
			return hydrEnergy * c.hydr;
		}
		rv += CalcContactEnergy( p, node1, p.node[node2].n1 );
		rv += CalcContactEnergy( p, node1, p.node[node2].n2 );
		return rv;
	}
	rv += CalcContactEnergy( p, p.node[node1].n1, node2 );
	rv += CalcContactEnergy( p, p.node[node1].n2, node2 );
	return rv;
}

double CalcNodeEnergy( Pathway& p, int node )
{
	double rv = 0;
	if ( p.node[node].leaf != -1 )
	{
		return 0;
	}
	int leaf;
	if ( ( leaf = p.node[p.node[node].n1].leaf ) != -1 )
	{
		Leaf& l = p.input->leaf[leaf];
		rv += SelEnergy( l.coil, l.dist );
		rv -= lengthFactor * l.size;
		if ( l.type ) rv += HHEnergy * ( l.size - 3 );
	}
	rv += CalcContactEnergy( p, p.node[node].n1, p.node[node].n2 );
	rv += CalcNodeEnergy( p, p.node[node].n1 );
	rv += CalcNodeEnergy( p, p.node[node].n2 );
	return rv;
}

int CalcEmptyStrands( Pathway& p, int node )
{
	if ( p.node[node].leaf != -1 )
	{
		return 0;
	}
	int n1 = node, n2 = node;
	while ( p.node[n1].leaf == -1 ) n1 = p.node[n1].n1;
	while ( p.node[n2].leaf == -1 ) n2 = p.node[n2].n2;
	int leaf1 = p.node[n1].leaf, leaf2 = p.node[n2].leaf;
	int rv = 0;
	for ( int lc1 = leaf1; lc1 <= leaf2; lc1++ )
	{
		Leaf& l = p.input->leaf[lc1];
		if ( !l.type ) continue;
		bool f = false;
		for ( int lc2 = leaf1; lc2 <= leaf2; lc2++ )
		{
			if ( lc1 == lc2 ) continue;
			if ( p.input->GetContact( lc1, lc2 ).beta ) 
			{
				f = true;
				break;
			}
		}
		if ( !f ) rv += l.size;
	}
	return rv;
}

void CalcFlux( Pathway& p )
{
	if ( p.node.back().leaf != -1 ) return;
	p.energy = 0;
	for ( int sc = 0; sc < p.stack.size(); sc++ )
	{
		p.energy += CalcNodeEnergy( p, p.stack[sc] );
	}
	p.flux = p.prevFlux + p.energy - p.prevEnergy;
	int na = 0, nb = 0;
	int leaf1 = p.node[ p.node.back().n1 ].leaf;
	int leaf2 = p.node[ p.node.back().n2 ].leaf;
	if ( leaf1 != -1 )
	{
		if ( p.input->leaf[ leaf1 ].type ) na += p.input->leaf[ leaf1 ].size;
		else nb += p.input->leaf[ leaf1 ].size;
	}
	if ( leaf2 != -1 )
	{
		if ( p.input->leaf[ leaf2 ].type ) na += p.input->leaf[ leaf2 ].size;
		else nb += p.input->leaf[ leaf2 ].size;
	}
	p.flux -= AlphaFactor * na + BetaFactor * nb;
	int es = 0;
	for ( int sc = 0; sc < p.stack.size(); sc++ )
	{
		es += CalcEmptyStrands( p, p.stack[sc] );
	}
	p.flux -= DecayFactor * es;
	p.prevEnergy = p.energy;
	p.prevFlux = p.flux;
}

void AddToCash( Cash *cash, Pathway *p )
{
	const int maxSize = 1500;
	for ( int pc = 0; pc < cash->pathway.size(); pc++ )
	{
		if ( cash->pathway[pc]->flux < p->flux )
		{
			cash->pathway.insert( cash->pathway.begin() + pc, p );
			if ( cash->pathway.size() > maxSize )
			{
				delete cash->pathway.back();
				cash->pathway.erase( cash->pathway.end() - 1 );
			}
			return;
		}
	}
	if ( cash->pathway.size() >= maxSize )
	{
		delete p;
	}
	else cash->pathway.push_back( p );
}

void PathwayStep( Pathway *p, Cash *cash )
{
	for ( int sc = 0; sc < p->stack.size() - 1; sc++ )
	{
		Pathway *np = new Pathway( *p );
		np->node.resize( np->node.size() + 1 );
		Node& nn = np->node.back();
		nn.leaf = -1;
		nn.n1 = np->stack[sc];
		nn.n2 = np->stack[sc+1];
		if ( np->node[nn.n1].leaf != -1
			&& np->node[nn.n2].leaf != - 1 )
		{ 
			Node n0;
			n0.leaf = nn.n1;
			nn.n1 = np->node.size() - 1;
			np->node.insert( np->node.end() - 1, n0 );
		}
		np->stack.erase( np->stack.begin() + sc );
		np->stack[sc] = np->node.size() - 1;
		CalcFlux( *np );
		AddToCash( cash, np );
	}
}

Cash *Simulate( Input *input )
{
	Pathway *p = new Pathway;
	p->input = input;
	p->node.resize( input->leaf.size() );
	p->stack.resize( input->leaf.size() );
	for ( int lc = 0; lc < input->leaf.size(); lc++ )
	{
		p->node[lc].leaf = lc;
		p->stack[lc] = lc;
	}
	p->energy = p->prevEnergy = p->flux = p->prevFlux = 0;
	Cash *cash = new Cash;
	AddToCash( cash, p );
	for ( int sc = 0; sc < input->leaf.size() - 1; sc++ )
	{
		Cash *nc = new Cash;
		for ( int pc = 0; pc < cash->pathway.size(); pc++ )
		{
			PathwayStep( cash->pathway[pc], nc );
		}
		delete cash;
		cash = nc;
	}
	return cash;
}

int Load( Input& input, char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	Line ll;
	if ( ll.Read( ifile ) != eOK ) return 0;
	if ( ll.GetType() != rHeader ) return 0;
	int size = ll.GetInt( fNumSS );
	input.leaf.resize( size );
	input.contact.resize( size * size );
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF || res == eEOREC ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() == rSS )
		{
			int ss = l.GetInt( fOrder );
			input.leaf[ss].first = l.GetInt( fFirst );
			input.leaf[ss].size = l.GetInt( fSize );
			input.leaf[ss].type = l.GetInt( fType );
			input.leaf[ss].coil = 0;
			input.leaf[ss].dist = 0;
		}
		else if ( l.GetType() == rCoil )
		{
			int ss = l.GetInt( fSS1 );
			if ( ss == -1 ) continue;
			input.leaf[ss].coil = l.GetInt( fSize );
			input.leaf[ss].dist = l.GetDouble( fDistance );
		}
		else if ( l.GetType() == rContact )
		{
			int ss1 = l.GetInt( fSS1 );
			int ss2 = l.GetInt( fSS2 );
			int type = l.GetInt( fType );
			Contact& c = input.GetContact( ss1, ss2 );
			if ( type == cCys ) c.cys = 1;
			else if ( type == cBeta ) c.beta++;
			else if ( type == cHydr ) c.hydr += l.GetDouble( fHSquare1 ) + l.GetDouble( fHSquare2 );
		}
		else continue;
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

void PutLine( Pathway *p, int node, int leaf, int type, int cluster, Line &ll )
{
	Line l( rPWSim );
  	l.PutInt( fOrder, node - p->input->leaf.size() );
  	l.PutInt( fType, type );
  	l.PutInt( fNumSS, leaf );
  	l.PutInt( fCluster, cluster );
	ll.PutLine( l );
}

int SaveNode( Pathway *p, int node, int& cluster, Line& ll )
{
	if ( p->node[node].leaf != -1 ) return cluster;
	int n1 = p->node[node].n1;
	int n2 = p->node[node].n2;
	if ( p->node[n1].leaf != -1 )
	{
		if ( p->node[n2].leaf != -1 )
  		{
  			PutLine( p, node - 1, p->node[n1].leaf, 0, cluster, ll );
  			PutLine( p, node, p->node[n2].leaf, 1, cluster, ll );
  			cluster++;
  			return cluster - 1;
  		}
  		else
  		{
  			int cp = SaveNode( p, n2, cluster, ll );
  			PutLine( p, node, p->node[n1].leaf, 1, cp, ll );
  			return cp;
  		}
  	}
	else if ( p->node[n2].leaf != -1 )
	{
		int cp = cluster;
		SaveNode( p, n1, cluster, ll );
		PutLine( p, node, p->node[n2].leaf, 1, cp, ll );
		return cp;
	}
	else
	{
  		int cp = cluster;
		int cp1 = SaveNode( p, n1, cluster, ll );
		int cp2 = SaveNode( p, n2, cluster, ll );
		Line l( rPWSim );
  		l.PutInt( fOrder, node - p->input->leaf.size() );
  		l.PutInt( fType, 2 );
  		l.PutInt( fCluster, cp1 );
  		l.PutInt( fCluster2, cp2 );
		ll.PutLine( l );
		return cp;
	}
}

int main( int argc, char **argv )
{
	if ( argc < 3 ) return 1;
	Input input;
	if ( !Load( input, argv[1] ) ) return 1;
	Cash *cash = Simulate( &input );
	FILE *ofile = fopen( argv[2], "wt" );
	if ( !ofile ) return 1;
	int cnt = 0;
	vector< Pathway* > good;
	double sum = 0;
	const double realEF = 20;
	for ( int pc = 0; pc < cash->pathway.size(); pc++ )
	{
		int pcc;
		for ( pcc = 0; pcc < pc; pcc++ )
		{
			if ( cash->pathway[pc]->stack == cash->pathway[pcc]->stack 
			//&& cash->pathway[pc]->node == cash->pathway[pcc]->node 
			) break;
		}
		if ( pc != pcc ) continue;
		good.push_back( cash->pathway[pc] );
		sum += exp( good.back()->energy / realEF );
	}
	
	for ( int pc = 0; pc < good.size(); pc++ )
	{
		Line ll( rPathway );
		Pathway *p = good[pc];
		ll.PutDouble( fEnergy, p->energy );
		ll.PutDouble( fFlux, p->flux );
		ll.PutDouble( fValue, exp( p->energy / realEF ) / sum );
		int cluster = 0;
		SaveNode( p, p->node.size() - 1, cluster, ll );
		ll.Write( ofile );
		cnt++;
		if ( cnt >= 10 ) break;
	}
	fclose( ofile );
	delete cash;
	return 0;
}
