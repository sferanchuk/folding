
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};


const int pdbLineSize = 100;

struct pdbLine
{
	char s[ pdbLineSize ];

	char *lineType() { return s; }
	char *atomNumber() { return s + 7; }
	char *atomType() { return s + 13; }
	char *chainName() { return s + 21; }
	char *aaNumber() { return s + 23; }
	char *aaName() { return s + 17; }
	char *x() { return s + 31; }
	char *y() { return s + 39; }
	char *z() { return s + 47; }
};

int main( int argc, char **argv )
{
	char oname[100] = "";
	char iname[100] = "";
	char cletter = ' ';
	if ( argc < 2 )
	{
		printf( "usage: pdb2seq -p<pdb file> -c<chain letter = _> [-o<seq file>]\n" );
		return 1;
	}
	for ( int ac = 1; ac < argc; ac++ )
	{
		if ( strncmp( argv[ac], "-p", 2 ) == 0 )
		{
			strcpy( iname, argv[ac] + 2 );
			if ( !strlen( oname ) )
			{
				strcpy( oname, iname );
				char *p = oname + strlen( oname );
				for ( p--; p > oname && *p != '\\' && *p != '.' && *p != '/'; p-- );
				if ( *p == '.' ) *p = 0;
				strcat( oname, ".seq" );
			}
		}
		else if ( strncmp( argv[ac], "-c", 2 ) == 0 )
		{
			if ( argv[ac][2] == '_' ) cletter = ' ';
			else cletter = argv[ac][2];
		}
		if ( strncmp( argv[ac], "-o", 2 ) == 0 )
		{
			strcpy( oname, argv[ac] + 2 );
		}
	}
	if ( !strlen( iname ) )
	{
		printf( "undefined pdb file\n" );
		return 1;
	}
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) 
	{
		printf( "can't open pdb file %s\n", iname );
		return 1;
	}
	FILE *ofile = fopen( oname, "wt" );
	if ( !ofile ) 
	{
		printf( "can't open seq file %s\n", oname );
		return 1;
	}

	pdbLine line;
	int cc = 0;

	while ( fgets( line.s, pdbLineSize, ifile ) )
	{
		if ( strncmp( line.lineType(), "ATOM", 4 ) != 0 ) 
		{
			continue;
		}
		if ( strncmp( line.atomType(), "CA", 2 ) != 0 ) 
		{
			continue;
		}
		if ( *( line.chainName() ) != cletter )
		{
			continue;
		}
		if ( strncmp( line.lineType(), "MODEL", 5 ) == 0 
			&& atoi( line.lineType() + 6 ) > 1 ) break;

		for ( int ac = 0; ac < 26; ac++ )
		{
			if ( strncmp( a_name[ac], line.aaName(), 3 ) == 0 )
			{
        		fprintf( ofile, "%c", 'A' + ac );
        		break;
        	}
        }
	}
	fclose( ifile );
	fclose( ofile );
	return 0;
}
