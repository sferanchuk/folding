
// create secondary structure file

#include "common.h"

#include <pdb++.h>
#include <radii.h>

struct Atom
{
	Vector coord;
	int number;
	char name[5];
};

enum { aN, aCA, aC, aO };

struct Residue
{
	vector<Atom> atom;
	Vector center;
	int number;
	char icode;
	char name3[5];
	char name1;
	int order;
};

struct Chain
{
	vector<Residue> residue;
	char letter;
	char fname[10];
};

int LoadChain( FILE *ifile, PDB **ppdb, Chain &chain );
void WriteChain( Chain& chain, FILE *cfile, FILE *sfile, char *oname );

//------------------------------------------------------------------------------

static int get_sname( const char *fname, char *sname, int size )
{
   	char buf[256];
   	strcpy( buf, fname );
   	int c = strlen( buf ) - 1;
   	while ( c > 0 && buf[c] != '.' ) c--;
    buf[c] = 0;
    while ( c > 0 && buf[c] != '\\' && buf[c] != '/' ) c--;
   	if ( buf[c] == '\\' || buf[c] == '/' ) c++;
   	strncpy( sname, buf + c, size - 1 );
   	sname[ size - 1 ] = 0;
}

static void make_center( Residue &res )
{
	Vector dir1 = !( res.atom[ aC ].coord - res.atom[ aCA ].coord );
	Vector dir2 = !( res.atom[ aN ].coord - res.atom[ aCA ].coord );
	Vector basis1 = !( dir1 + dir2 );
	Vector basis2 = !( dir1 & dir2 );
	Vector dirc = !( basis1 * cos( 54. * 3.14 / 180 ) + basis2 * cos( 36. * 3.14 / 180 ) );
	res.center = res.atom[ aCA ].coord - dirc * 3.;
}

void add_centers( Chain& chain )
{
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		make_center( chain.residue[rc] );
	}
}

int ProcessPdbFile( const char *fname )
{
	char sname[10] = "";
	get_sname( fname, sname, sizeof( sname ) );

	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	if ( !fgets(buf, 256, ifile ) ) return 0;
	PDB *pdb = new PDB( buf );
	do
	{
		Chain chain;
		strcpy( chain.fname, sname );

		int res =  LoadChain( ifile, &pdb, chain );
		add_centers( chain );
        char oname[13];
        sprintf( oname, "%s%c", sname, ( chain.letter == ' ' ) ? '_' : chain.letter );
        FILE *cfile = fopen( "XYZ", "at" );
        FILE *sfile = fopen( "SEQ", "at" );
        WriteChain( chain, cfile, sfile, oname );
        fclose( cfile );
        fclose( sfile );
		if ( !res ) break;
	}
	while ( 1 );
	delete pdb;
	fclose( ifile );
	return 1;
}

static int convert_resname( char *name3 )
{
	char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

	for ( int ac = 0; ac < 26; ac++ )
	{
		if ( strncmp( a_name[ac], name3, 3 ) == 0 ) return 'A' + ac;
	}
	return 0;
}

int LoadChain( FILE *ifile, PDB **ppdb, Chain &chain )
{
	Residue *r = NULL;

	do
	{
		PDB& pdb = **ppdb;
		if ( pdb.type() == PDB::ATOM ) 
		{
  			PDB::Atom &a = pdb.atom;
  			if ( a.residue.chainId == '\0' ) a.residue.chainId = ' ';
  			if ( a.residue.insertCode == '\0' ) a.residue.insertCode = ' ';
  			
  			if ( r == NULL ) chain.letter = a.residue.chainId;
  			else if ( chain.letter != a.residue.chainId ) 
  			{
  				return 1;
  			}

  			if ( r == NULL || r->number != a.residue.seqNum || r->icode != a.residue.insertCode )
  			{
  				int order = chain.residue.size();
  				chain.residue.resize( order + 1 );
  				r = &( chain.residue.back() );
  				r->order = order;
  				r->number = a.residue.seqNum;
  				r->icode = a.residue.insertCode;
  				strcpy( r->name3, a.residue.name );
  				r->name1 = convert_resname( r->name3 );
  			}
  			r->atom.resize( r->atom.size() + 1 );
  			Atom &at = r->atom.back();
  			at.coord = Vector( a.xyz[0], a.xyz[1], a.xyz[2] );
  			strcpy( at.name, a.name );
  			at.number = a.serialNum;

  		}
		else if ( pdb.type() == PDB::MODEL ) 
		{
			if ( pdb.model.num != 1 ) 
			{
				return 0;
			}
		}

   		char buf[256];
   		if ( !fgets( buf, 256, ifile ) ) 
   		{
   			return 0;
   		}
   		delete *ppdb;
   		*ppdb = new PDB( buf );
   	}
   	while ( 1 );
   	return 1;
}

void WriteChain( Chain& chain, FILE *cfile, FILE *sfile, char *cname )
{
	fprintf( cfile, "%s\n%d\n", cname, chain.residue.size() );
	fprintf( sfile, "%s\n%d\n", cname, chain.residue.size() );
	for ( int cnt = 0; cnt < chain.residue.size(); cnt++ )
	{
		Vector v1 = chain.residue[cnt].atom[aCA].coord;
		Vector v2 = chain.residue[cnt].center;
		fprintf( cfile, " %9.3f %9.3f %9.3f %9.3f %9.3f %9.3f\n",
			v1.x, v1.y, v1.z, v2.x, v2.y, v2.z ),
		fprintf( sfile, "%s\n", chain.residue[cnt].name3 );
	}
}

int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	ProcessPdbFile( argv[1] );
	return 0;
}

