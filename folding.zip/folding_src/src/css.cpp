
// create secondary structure file

#include "common.h"

#include <pdb++.h>
#include <radii.h>
extern "C" {
#include <CalcAccSurf.h>
}

struct Atom
{
	Vector coord;
	int number;
	char name[5];
};

enum { aN, aCA, aC, aO };

struct Residue
{
	vector<Atom> atom;
	Vector center;
	int number;
	char icode;
	char name3[5];
	char name1;
	int order;
};

enum { ssBeta, ssAlpha3, ssAlpha4, ssAlpha5 };

struct SS
{
	int type;
	int first; 
	int size;
	Vector center;
	Vector orientation;
	Vector dir;
	int order;
};

struct Coil
{
	int first;
	int size;
	int ss1;
	int ss2;
	double distance;
	double angle;
	int order;
};

enum { cBeta, cHydr, cCys };

struct Contact
{
	int type;
	int ss1;
	int ss2;
	int res1;
	int res2;
	double distCA;
	double dist;
	double square1;
	double square2;
	double squareh1;
	double squareh2;
	int order;
};

struct Chain
{
	vector<Residue> residue;
	vector<SS> ss;
	vector<Coil> coil;
	vector<Contact> contact;
	char letter;
	char fname[10];
};

int LoadChain( FILE *ifile, PDB **ppdb, Chain &chain, const char *oname );
int LoadSS( Chain& chain, const char *oname );
void AddHydrContacts( Chain& chain );
void AddCoils( Chain& chain );
void WriteChain( Chain& chain, FILE *ofile );

//------------------------------------------------------------------------------

static int get_sname( const char *fname, char *sname, int size )
{
   	char buf[256];
   	strcpy( buf, fname );
   	int c = strlen( buf ) - 1;
   	while ( c > 0 && buf[c] != '.' ) c--;
    buf[c] = 0;
    while ( c > 0 && buf[c] != '\\' && buf[c] != '/' ) c--;
   	if ( buf[c] == '\\' || buf[c] == '/' ) c++;
   	strncpy( sname, buf + c, size - 1 );
   	sname[ size - 1 ] = 0;
}

static void make_center( Residue &res )
{
	Vector dir1 = !( res.atom[ aC ].coord - res.atom[ aCA ].coord );
	Vector dir2 = !( res.atom[ aN ].coord - res.atom[ aCA ].coord );
	Vector basis1 = !( dir1 + dir2 );
	Vector basis2 = !( dir1 & dir2 );
	Vector dirc = !( basis1 * cos( 54. * 3.14 / 180 ) + basis2 * cos( 36. * 3.14 / 180 ) );
	res.center = res.atom[ aCA ].coord - dirc * 3.;
}

void add_centers( Chain& chain )
{
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		make_center( chain.residue[rc] );
	}
}

int ProcessPdbFile( const char *fname )
{
	char sname[10] = "";
	get_sname( fname, sname, sizeof( sname ) );
	char tmpname[20];
	strcpy( tmpname, sname );
	strcat( tmpname, ".tmp" );

	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	if ( !fgets(buf, 256, ifile ) ) return 0;
	PDB *pdb = new PDB( buf );
	do
	{
		Chain chain;
		strcpy( chain.fname, sname );

		int res =  LoadChain( ifile, &pdb, chain, tmpname );
		add_centers( chain );
		if ( !LoadSS( chain, tmpname ) ) break;
        AddHydrContacts( chain );
        AddCoils( chain );
        char oname[13];
        sprintf( oname, "%s%c.ss", sname, ( chain.letter == ' ' ) ? '_' : chain.letter );
        FILE *ofile = fopen( oname, "wt" );
        WriteChain( chain, ofile );
        fclose( ofile );
		if ( !res ) break;
	}
	while ( 1 );
	delete pdb;
	fclose( ifile );
	return 1;
}

static int convert_resname( char *name3 )
{
	char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

	for ( int ac = 0; ac < 26; ac++ )
	{
		if ( strncmp( a_name[ac], name3, 3 ) == 0 ) return 'A' + ac;
	}
	return 0;
}

static bool find_atom( Chain& chain, int number, int& residue, int& atom )
{
	for ( residue = 0; residue < chain.residue.size(); residue++ )
	{
		Residue& r = chain.residue[ residue ];
		if ( r.atom.back().number < number ) continue;
		for ( atom = 0; atom < r.atom.size(); atom++ )
		{
			if ( r.atom[ atom ].number == number ) return true;
		}
	}
	return false;
}

static bool add_cysbridge( Chain& chain, PDB& pdb )
{
   	int r1, a1;
   	if ( !find_atom( chain, pdb.conect.serialNum, r1, a1 ) ) return false;
	if ( chain.residue[r1].atom[a1].name[0] != 'S' ) return false;
	int r2, a2;
   	if ( !( find_atom( chain, pdb.conect.covalent[1], r2, a2 )
			&& chain.residue[r2].atom[a2].name[0] == 'S' ) 
   		|| !( find_atom( chain, pdb.conect.covalent[0], r2, a2 )
			&& chain.residue[r2].atom[a2].name[0] == 'S' ) )
	{
		return false;
	}
	if ( r2 < r1 ) return false;
	Contact ct;
	ct.type = cCys;
	ct.ss1 = -1;
	ct.ss2 = -1;
  	ct.res1 = r1;
	ct.res2 = r2;
	chain.contact.push_back( ct );
	return true;
}

int LoadChain( FILE *ifile, PDB **ppdb, Chain &chain, const char *oname )
{
	FILE *ofile = fopen( oname, "wb" );
	if ( !ofile ) return 0;
	Residue *r = NULL;

	do
	{
		PDB& pdb = **ppdb;
		if ( pdb.type() == PDB::ATOM ) 
		{
  			PDB::Atom &a = pdb.atom;
  			if ( a.residue.chainId == '\0' ) a.residue.chainId = ' ';
  			if ( a.residue.insertCode == '\0' ) a.residue.insertCode = ' ';
  			
  			if ( r == NULL ) chain.letter = a.residue.chainId;
  			else if ( chain.letter != a.residue.chainId ) 
  			{
  				fclose( ofile );
  				return 1;
  			}

  			if ( r == NULL || r->number != a.residue.seqNum || r->icode != a.residue.insertCode )
  			{
  				int order = chain.residue.size();
  				chain.residue.resize( order + 1 );
  				r = &( chain.residue.back() );
  				r->order = order;
  				r->number = a.residue.seqNum;
  				r->icode = a.residue.insertCode;
  				strcpy( r->name3, a.residue.name );
  				r->name1 = convert_resname( r->name3 );
  			}
  			r->atom.resize( r->atom.size() + 1 );
  			Atom &at = r->atom.back();
  			at.coord = Vector( a.xyz[0], a.xyz[1], a.xyz[2] );
  			strcpy( at.name, a.name );
  			at.number = a.serialNum;

  			fprintf( ofile, "%s\n", pdb.chars() );
  		}
		else if ( pdb.type() == PDB::MODEL ) 
		{
			if ( pdb.model.num != 1 ) 
			{
				fclose( ofile );
				return 0;
			}
		}
		else if ( pdb.type() == PDB::CONECT ) 
		{
			add_cysbridge( chain, pdb );
		}

   		char buf[256];
   		if ( !fgets( buf, 256, ifile ) ) 
   		{
   			fclose( ofile );
   			return 0;
   		}
   		delete *ppdb;
   		*ppdb = new PDB( buf );
   	}
   	while ( 1 );
   	return 1;
}

static int find_residue( Chain& chain, PDB::Residue& res )
{
   	for ( int rc = 0; rc < chain.residue.size(); rc++ )
   	{
   		if ( res.seqNum == chain.residue[rc].number
   			&& res.insertCode == chain.residue[rc].icode )
   		{
   			return rc;
   		}
   	}
   	return -1;
}

static Vector res_center( Chain& chain, int res )
{
	return chain.residue[res].atom[aCA].coord;
}

static Vector helix_center( Chain& chain, int start )
{
	Vector c = res_center( chain, start ) * 0.5
		+ res_center( chain, start + 1 )
		+ res_center( chain, start + 2 )
		+ res_center( chain, start + 3 ) * 0.5;
	return c * ( 1. / 3 );
}

static void process_helix( Chain& chain, SS& helix )
{
	Vector c1 = helix_center( chain, helix.first );
	Vector c2 = helix_center( chain, helix.first + helix.size - 4 );
	if ( helix.size == 4 )
	{
		helix.dir = res_center( chain, helix.first + 3 ) - res_center( chain, helix.first );
		helix.center = c1 - helix.dir * 0.5;
	}
	else
	{
		Vector dir = !(c2 - c1);
		Vector o1 = res_center( chain, helix.first ) - c1;
		helix.center = c1 + dir * ( dir * o1 );
		Vector o2 = res_center( chain, helix.first + helix.size - 1 ) - c2;
		helix.dir = c2 + dir * ( dir * o2 ) - helix.center;
	}
	helix.orientation = res_center( chain, helix.first ) - helix.center;
}

static void process_strand( Chain& chain, SS& strand )
{
	Vector c1, c2;
	for ( int i = 0; i < 2; i++ )
	{
		c1 = c1 + res_center( chain, strand.first + i );
		c2 = c2 + res_center( chain, strand.first + i + strand.size - 2 );
	}
	c1 = c1 * 0.5;
	c2 = c2 * 0.5;
	if ( strand.size == 2 )
	{
		Vector dir1 = res_center( chain, strand.first + 1 ) - res_center( chain, strand.first );
		Vector dir2 = chain.residue[ strand.first ].atom[ aC ].coord - res_center( chain, strand.first );
		Vector dir3 = !( dir1 & dir2 );
		strand.dir = dir1 - dir3 * ( dir1.norm() / sqrt( 3. ) );
		strand.center = c1 - strand.dir * 0.5;
	}
	else
	{
		Vector dir = !(c2 - c1);
		Vector o1 = res_center( chain, strand.first ) - c1;
		strand.center = c1 + dir * ( dir * o1 );
		Vector o2 = res_center( chain, strand.first + strand.size - 1 ) - c2;
		strand.dir = c2 + dir * ( dir * o2 ) - strand.center;
	}
	strand.orientation = res_center( chain, strand.first ) - strand.center;
}
		
static int find_ss( Chain& chain, int number )
{
   	for ( int sc = 0; sc < chain.ss.size(); sc++ )
   	{
   		if ( number >= chain.ss[sc].first
   			&& number < chain.ss[sc].first + chain.ss[sc].size )
   		{
   			return sc;
   		}
   	}
   	return -1;
}

int LoadSS( Chain& chain, const char *oname )
{
	char *tmpname = "ss.tmp";
	char command[256];
	sprintf( command, "./ksdssp %s >%s", oname, tmpname );
	if ( system( command ) != 0 ) return 0;
	unlink( oname );
	FILE *ifile = fopen( tmpname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	int prev = -1;
	while ( fgets( buf, 256, ifile ) )
	{
		PDB pdb( buf );
		SS ss;
		int sense, o0, on;
  		if ( pdb.type() == PDB::HELIX ) 
  		{
  			ss.type = pdb.helix.type;
  			int afirst = find_residue( chain, pdb.helix.residues[0] );
  			int alast =  find_residue( chain, pdb.helix.residues[1] );
  			if ( afirst == -1 || alast == -1 ) return 0;
  			ss.first = afirst;
  			ss.size = alast - afirst + 1;
  			process_helix( chain, ss );
  			sense = 0;
  		}
  		else if ( pdb.type() == PDB::SHEET ) 
  		{
  			ss.type = 0;
  			int afirst = find_residue( chain, pdb.sheet.residues[0] );
  			int alast =  find_residue( chain, pdb.sheet.residues[1] );
  			if ( afirst == -1 || alast == -1 ) return 0;
  			ss.first = afirst;
  			ss.size = alast - afirst + 1;
  			process_strand( chain, ss );
  			sense = pdb.sheet.sense;
  			if ( sense != 0 )
  			{
	     		o0 = find_residue( chain, pdb.sheet.atoms[0].residue );
    	 		on = find_residue( chain, pdb.sheet.atoms[1].residue );
     			if ( o0 == -1 || on == -1 ) return 0;
     		}
  		}
  		else continue;
  		int sc;
		bool overlap = false;
  		for ( sc = 0; sc < chain.ss.size(); sc++ ) 
		{
			if ( chain.ss[sc].first + chain.ss[sc].size > ss.first 
				&& chain.ss[sc].first < ss.first
			 	|| ss.first + ss.size > chain.ss[sc].first 
				&& ss.first < chain.ss[sc].first )
			{
				overlap = true;
				int end = max( chain.ss[sc].first + chain.ss[sc].size, ss.size + ss.first );
				chain.ss[sc].first = min( chain.ss[sc].first, ss.first );
				chain.ss[sc].size = end - chain.ss[sc].first;
				break;
			}
			if ( chain.ss[sc].first > ss.first ) break;
		}
  		if ( sc == chain.ss.size() ) chain.ss.push_back( ss );
  		else if ( !overlap ) 
  		{
  			chain.ss.insert( chain.ss.begin() + sc, ss );
  			if ( prev >= sc ) prev++;
  		}
		if ( ss.type )
		{
			int offset = ( ss.type == 5 ) ? 3 : 4;
		    for ( int rc = 0; rc < ss.size - offset; rc++ )
		    {	
				Contact ct;
				ct.res1 = ss.first + rc;
			  	ct.res2 = ss.first + rc + offset;
				ct.type = cBeta;
		  		ct.ss1 = sc;
		  		ct.ss2 = sc;
		  		chain.contact.push_back( ct );
			}
		}
  		if ( sense != 0 )
  		{
  			if ( prev == -1 ) return 0;
  			SS &sj = chain.ss[prev];
  			for ( int rc = ss.first; rc < ss.first + ss.size; rc++ )
  			{
  				int rcc;
  				if ( sense == 1 ) rcc = rc - o0 + on;
  				else rcc = on + o0 - rc;
  				if ( rcc < sj.first || rcc >= sj.first + sj.size ) continue;
  				Contact ct;
  				ct.type = cBeta;
  				ct.ss1 = -1;
  				ct.ss2 = -1;
  				ct.res1 = min( rc, rcc );
  				ct.res2 = max( rc, rcc );
  				chain.contact.push_back( ct );
  			}
  		}
  		prev = sc;
  	}
  	fclose( ifile );
  	unlink( tmpname );
  	for ( int cc = 0; cc < chain.contact.size(); cc++ )
  	{
  		chain.contact[cc].ss1 = find_ss( chain, chain.contact[cc].res1 );
  		chain.contact[cc].ss2 = find_ss( chain, chain.contact[cc].res2 );
  	}
  	return 1;
}

int radius( char *name, double& rv )
{
	if ( name[1] == 'C' )
	{
		rv = RSIDEATOM + RWATER;
		return 1;
	}
	else if ( name[1] == 'S' )
	{
		rv = RSIDEATOM + RWATER;
		return 1;
	}
	else if ( name[1] == 'O' )
	{
		rv = RO + RWATER;
		return 0;
	}
	else if ( name[1] == 'N' )
	{
		rv = RN + RWATER;
		return 0;
	}
	return -1;
}

#define DMAX 15.

double calc_surface( CAS *cas, Residue& r1, Residue& r2, double& s, double& sh )
{
	s = sh = 0;
	double rv = DMAX;
	for ( int a1 = 0; a1 < r1.atom.size(); a1++ )
	{
		Atom &at1 = r1.atom[a1];
		double rad;
		int type = radius( at1.name, rad );
		if ( type == -1 ) continue; 
		bool contact = false;
	    CASResetAtoms( cas );
	    CASSetCenterAtom( cas, at1.coord.x, at1.coord.y, at1.coord.z, rad );
	    for ( int a2 = 0; a2 < r2.atom.size(); a2++ )
	    {
	    	Atom &at2 = r2.atom[a2];
	    	double rad2;
	    	if ( radius( at2.name, rad2 ) == -1 ) continue;
		    double dist = ( at2.coord - at1.coord ).norm();
		    if ( dist < rad + rad2 )
		    {
				CASAddNeigbourAtom( cas, at2.coord.x, at2.coord.y, at2.coord.z, rad2, dist * dist );
				contact = true;
			}
			if ( dist < rv ) rv = dist;
		}
		double res = contact ? rad * rad * 4 * 3.1416 - CASSurface( cas ) : 0;
		s += res;
		if ( type ) sh += res;
	}
	return rv;
}

bool calc_surfaces( CAS *cas, Chain& chain, Contact& ct )
{
	Residue& r1 = chain.residue[ ct.res1 ];
	Residue& r2 = chain.residue[ ct.res2 ];
	calc_surface( cas, r1, r2, ct.square1, ct.squareh1 );
	calc_surface( cas, r2, r1, ct.square2, ct.squareh2 );
	double eps = 0.0001;
	if ( ct.square1 < eps && ct.square2 < eps ) return false;
	return true;
}

void AddHydrContacts( Chain& chain )
{
    CAS *cas= CASCreate(ORDER);
	for ( int s1 = 0; s1 < chain.ss.size(); s1++ )
	{
		for ( int s2 = s1; s2 < chain.ss.size(); s2++ )
		{
			for ( int r1 = chain.ss[s1].first; r1 < chain.ss[s1].first + chain.ss[s1].size; r1++ )
			{
				for ( int r2 = chain.ss[s2].first; r2 < chain.ss[s2].first + chain.ss[s2].size; r2++ )
				{
					if ( s1 == s2 && r1 >= r2 ) continue;
	  				Contact ct;
					//ct.distCA = ( res_center( chain, r2 ) - res_center( chain, r1 ) ).norm();
					ct.dist = ( chain.residue[ r1 ].center - chain.residue[ r2 ].center ).norm();
					if ( ct.dist > 8 ) continue;
					//if ( ct.distCA > DMAX ) continue;
  					ct.res1 = r1;
	  				ct.res2 = r2;
	  				calc_surfaces( cas, chain, ct );
  					ct.type = cHydr;
  					ct.ss1 = s1;
  					ct.ss2 = s2;
  					chain.contact.push_back( ct );
  				}
  			}
  		}
  	}
  	CASDelete( cas );
}

static void add_coil( Chain& chain, int first, int last, int ss1, int ss2 )
{
	//if ( last <= first ) return;
	Coil c;
	c.first = first;
	c.size = last - first + 1;
	c.ss1 = ss1;
	c.ss2 = ss2;
	if ( ss1 != -1 && ss2 != -1 )
	{
		c.distance = ( res_center( chain, first - 1 ) - res_center( chain, last + 1 ) ).norm();
		c.angle = acos( ( chain.ss[ c.ss1 ].dir * chain.ss[ c.ss2 ].dir ) / chain.ss[ c.ss1 ].dir.norm() / chain.ss[ c.ss2 ].dir.norm() );
	}
	else 
	{
		c.distance = 0;
		c.angle = 0;
	}
	c.order = chain.coil.size();
	chain.coil.push_back( c );
}

void AddCoils( Chain& chain )
{
	int prev = 0;
	for ( int sc = 0; sc < chain.ss.size(); sc++ )
	{
		add_coil( chain, prev, chain.ss[sc].first - 1, sc - 1, sc );
		prev = chain.ss[sc].first + chain.ss[sc].size;
	}
	if ( prev < chain.residue.size() )
		add_coil( chain, prev, chain.residue.size() - 1, chain.ss.size() - 1, -1 );
}

static void write_residue( Chain& chain, int rnum, const char *rtype, int ref, FILE *ofile )
{
	Line l( rtype );
	Residue& res = chain.residue[ rnum ];
    double phi = ( rnum > 0 ) ? 
    	dihedral_angle( chain.residue[ rnum - 1 ].atom[ aC ].coord, 
    		res.atom[ aN ].coord,
    		res.atom[ aCA ].coord,
    		res.atom[ aC ].coord 
    	) : 0;
    double psi = ( rnum < chain.residue.size() - 1 ) ? 
    	dihedral_angle(	res.atom[ aN ].coord,
    		res.atom[ aCA ].coord,
    		res.atom[ aC ].coord,
    		chain.residue[ rnum + 1 ].atom[ aN ].coord
 		) : 0;
 	l.PutInt( fRef, ref );
	l.PutInt( fNumber, res.number );
	l.PutString( fICode, string( &( res.icode ), 1 ) );
	l.PutString( fName, res.name3 );
	l.PutString( fLetter, string( &( res.name1 ), 1 ) );
	l.PutInt( fOrder, rnum );
	l.PutVector( "ATOM0", res.atom[ 0 ].coord );
	l.PutVector( "ATOM1", res.atom[ 1 ].coord );
	l.PutVector( "ATOM2", res.atom[ 2 ].coord );
	l.PutVector( "ATOM3", res.atom[ 3 ].coord );
	l.PutDouble( fPhi, phi );
	l.PutDouble( fPsi, psi );
	l.Write( ofile );
}

static void write_ss( Chain& chain, int snum, FILE *ofile )
{
	Line l( rSS );
	SS& ss = chain.ss[snum];
	l.PutInt( fOrder, snum );
	l.PutInt( fType, ss.type );
	l.PutInt( fFirst, ss.first );
	l.PutInt( fSize, ss.size );
	l.PutVector( fCenter, ss.center );
	l.PutVector( fOrientation, ss.orientation );
	l.PutVector( fDir, ss.dir );
	l.Write( ofile );
	for ( int rc = ss.first; rc < ss.first + ss.size; rc++ )
	{
		write_residue( chain, rc, rSSDetail, snum, ofile );
	}
}

static void write_coil( Chain& chain, int cnum, FILE *ofile )
{
	Line l( rCoil );
	Coil& c = chain.coil[cnum];
	Residue& r1 = chain.residue[ c.first ];
	Residue& r2 = chain.residue[ c.first + c.size - 1 ];
	double or1 = dihedral_angle( r1.atom[aN].coord, r1.atom[aCA].coord, r2.atom[aCA].coord, r2.atom[aC].coord );
	double or2 = ( ( r1.atom[aN].coord  - r1.atom[aCA].coord ) * ( r2.atom[aCA].coord - r1.atom[aCA].coord ) ) / c.distance;
	double or3 = ( ( r2.atom[aC].coord  - r2.atom[aCA].coord ) * ( r1.atom[aCA].coord - r2.atom[aCA].coord ) ) / c.distance;
	l.PutInt( fOrder, cnum );
	l.PutInt( fFirst, c.first );
	l.PutInt( fSize, c.size );
	l.PutInt( fSS1, c.ss1 );
	l.PutInt( fSS2, c.ss2 );
	l.PutDouble( fDistance, c.distance );
	l.PutDouble( fAngle, c.angle );
	l.PutDouble( fOrient1, or1 );
	l.PutDouble( fOrient2, or2 );
	l.PutDouble( fOrient3, or3 );
	l.PutVector( fOrientation, r1.atom[aN].coord - r1.atom[aCA].coord );
	l.Write( ofile );
	for ( int rc = c.first; rc < c.first + c.size; rc++ )
	{
		write_residue( chain, rc, rCoilDetail, cnum, ofile );
	}
}

static void write_contact( Chain& chain, int cnum, FILE *ofile )
{
	Line l( rContact );
	Contact& c = chain.contact[cnum];
	l.PutInt( fOrder, cnum );
	l.PutInt( fType, c.type );
	l.PutInt( fSS1, c.ss1 );
	l.PutInt( fSS2, c.ss2 );
	l.PutInt( fRes1, c.res1 );
	l.PutInt( fRes2, c.res2 );
	//l.PutDouble( fValue, ( chain.residue[ c.res1 ].center - chain.residue[ c.res2 ].center ).norm() );
	if ( c.type == cHydr )
	{
		l.PutDouble( fDistance, c.dist );
		/*
		l.PutDouble( fDistance, c.distCA );
		l.PutDouble( fMinDist, c.dist );
		l.PutDouble( fSquare1, c.square1 );
		l.PutDouble( fSquare2, c.square2 );
		*/
		l.PutDouble( fHSquare1, c.squareh1 );
		l.PutDouble( fHSquare2, c.squareh2 );
	}
	l.Write( ofile );
}

void WriteChain( Chain& chain, FILE *ofile )
{
	string seq;
	for ( int rc = 0; rc < chain.residue.size(); rc++ ) seq.append( 1, chain.residue[rc].name1 );

	Line l( rHeader );
	l.PutString( fName, chain.fname );
	l.PutString( fLetter, string( &(chain.letter), 1 ) );
	l.PutInt( fNumRes, chain.residue.size() );
	l.PutInt( fNumSS, chain.ss.size() );
	l.PutInt( fNumContacts, chain.contact.size() );
	l.PutInt( fNumCoils, chain.coil.size() );
	l.PutString( fSeq, seq );
	l.Write( ofile );

	for ( int sc = 0; sc < chain.ss.size(); sc++ )
	{
		write_ss( chain, sc, ofile );
	}
	for ( int cc = 0; cc < chain.coil.size(); cc++ )
	{
		write_coil( chain, cc, ofile );
	}
	for ( int cc = 0; cc < chain.contact.size(); cc++ )
	{
		write_contact( chain, cc, ofile );
	}
}

int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	ProcessPdbFile( argv[1] );
	return 0;
}

