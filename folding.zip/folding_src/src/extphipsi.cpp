
// simulate pathway

#include "common.h"

int main( int argc, char **argv )
{
	FILE *ifile = fopen( argv[1], "rt" );
	if ( !ifile ) return 1;
	double phis[6] = { 0 };
	double psis[6] = { 0 };
	int count[6] = { 0 };
	int psic[6] = { 0 };
	int type = -1;
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF || res == eEOREC ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() == rSS )
		{
			type = l.GetInt( fType );
		}
		else if ( l.GetType() == rSSDetail )
		{
			double phi = l.GetDouble( fPhi );
			double psi = l.GetDouble( fPsi );
			if ( type == -1 ) continue;
			phis[type] += phi;
			psis[type] += psi;
			count[type]++;
		}
		else continue;
	}
	while ( 1 );
	fclose( ifile );
	printf( "0 %g %g\n", phis[0] / count[0], psis[0] / count[0] );
	printf( "1 %g %g\n", phis[1] / count[1], psis[1] / count[1] );
	printf( "5 %g %g\n", phis[5] / count[5], psis[5] / count[5] );
	return 0;
}
