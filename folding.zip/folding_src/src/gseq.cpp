
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "contacts.cpp"

int main( int argc, char **argv )
{
	if ( argc < 4 ) 
	{
		printf( "arguments: letter seq_size seq_file\n" );
		return 1;
	}
	int letter = argv[1][0];
	int size = atoi( argv[2] );
	char *seq = new char[ size + 1 ];
	int norm = 0;
	for ( int lc = 0; lc < 26; lc++ )
	{
		if ( lc + 'A' == letter ) continue;
		norm += cData[0][ lc ];
	}
	srand( time( 0 ) );
	for ( int sc = 0; sc < size; sc++ )
	{
		int dice = rand() % norm;
		int cnt = 0;
		int lc;
		for ( lc = 0; lc < 26; lc++ )
		{
			if ( lc + 'A' == letter ) continue;
			cnt += cData[0][ lc ];
			if ( cnt > dice ) break;
		}
		seq[sc] = lc + 'A';
	}
	int nl = int( double( size * cData[0][ letter - 'A' ] ) / ( norm + cData[0][ letter - 'A' ] ) + 0.5 );
	for ( int cc = 0; cc < nl; cc++ )
	{
		int dice;
		do
		{
			dice = rand() % size;
		}
		while ( seq[ dice ] == letter );
		seq[ dice ] = letter;
	}
	FILE *ofile = fopen( argv[3], "wt" );
	if ( !ofile ) return 1;
	fwrite( seq, size, 1, ofile );
	fclose( ofile );
	return 0;
}

