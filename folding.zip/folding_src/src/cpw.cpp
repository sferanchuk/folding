
#include "common.h"

#include <stdint.h>
#include <unistd.h>
#include <set>
#include <algorithm>

#include "geom-f.h"
#include "counters.h"

using namespace __detail;

const int MaxUnitNum = 30;
const int MaxLinkNum = 10;
const bool MergeClusters = true;
int tagCnt = 0;

const double EnergyGap = 10;//1.3;
const double PrelimGap = 1;//1.3;
const double PostGap = 1;//1.3;
const double energyFactor = 8.31 * 300. / 42000.;

const double contactFactor = 0.057;//0.057;//0.015;
const double letterOffset = -1.45;
const double coilOffset = 0.0;//4.48;
const double linkOffset = 0;
const double ssOffset = 4.30;
double hbondFactor = 0.018;//0.014;//0.03;//0.005;
const double CysBridgeTerm = 0.3;//0.05;
const double PosBiasTerm = 0.05;
double AmberEnergyFactor = 0.017;
const double ssFactor = 0.05;//0.06;
const double lengthFactor = 0.0;//0.0467; // avg( cData[0] / cData[1] / 6.51 ) * 6.51 ( = 0.82)* contactFcator
double lOffsets[3] = { -1.73845, -1.06322, -2.73528 };
const double MinClusterEnergy = -0.8;//-2;//1.5;//-0.4;
double SSPredFactor = 0.01;//0.007;//0.02;
double SurfaceFactor = 0.000336;//0.0006;
const double MinSegmDist = 4.5;//4.5
const double MinCSDist = 3.5;
const double MinCoilDist = 3.5;
const double MinCoilEndsDist = 3;
const double MatchLinkRmsd = 6;//3;
const int tom1_max = 15;
const int MaxNumAlternativeStructures = 1;
const int MaxNumProcessedStructures = 60000;
const int MaxNumStructures = 1200;
const int MaxNumResultStructures = 100;
const int MaxLoopLength = 25;
const int MinLoopLength = 0;
const double big = 1e11;
const double OutputTimeInterval = 100;
const int nJobs = 16;

double *bestEnergies;
int seq_size;

/*
void test_mem( const char *situation )
{
    static int size0 = 0;
    char buf[30];
    snprintf(buf, 30, "/proc/%u/statm", (unsigned)getpid());
    FILE* pf = fopen(buf, "r");
    if ( pf ) 
    {
        unsigned size; //       total program size
	unsigned resident;//   resident set size
        unsigned share;//      shared pages
        unsigned text;//       text (code)
        unsigned lib;//        library
        unsigned data;//       data/stack
        unsigned dt;//         dirty pages (unused in Linux 2.6)
        fscanf(pf, "%u %u %u %u %u %u", &size, &resident, &share, &text, &lib, &data);
        fclose( pf );
        if ( size > size0 )
        {
            size0 = size;
            char *fname = "cpw.memlim";
            FILE *dfile = fopen( fname, "at" );
            if ( !dfile ) dfile = fopen( fname, "wt" );
            fprintf( dfile, "%s %d\n", situation, size );
            fclose( dfile );
        }
    }
}
*/

static double min( double x, double y )
{
    if ( x < y ) return x;
    return y;
}

static int calc_index( int i1, int i2 )
{
	return i1 * ( i1 - 1 ) / 2 + i2;
}

static void reverse_index( int index, int& imin, int& imax )
{
	imax = 1;
	while ( imax * ( imax - 1 ) / 2 + imax - 1 < index ) imax++;
	imin = index - imax * ( imax - 1 ) / 2;
}

static bool bad_energy( int index, double energy )
{
	if ( !(energy == energy) ) return true;
	int imin, imax;
	reverse_index( index, imin, imax );
	for ( int c = imin; c < imax; c++ )
	{
		if ( bestEnergies[ c ] > energy ) 
		{
			//printf( "%d %d %g t\n", imin, imax, energy );
			return true;
		}
	}
	return false;
}

typedef pair<char,int> PotEntry;

struct Potential
{
	double coilOffset;
	double coilEnergy;
	double hbondFactor;
	double lw[ 26 ][ tom1_max ];
	inline double weight( char letter, int nc )
	{
		return lw[ letter - 'A' ][ nc ];
	} 
};

struct SSPred
{
	double p[MaxLoopLength][3];
};

struct Input
{
	Acc< SS > mono;
	map< SS, LastData, Comparer<SS> > last;
	map< int, double > coil;
	map< LinkPKey, double, ComparePLinks > linkAvg;
	SchAcc sch;
	LinkAcc link;
	string seq;
	Potential pot;
	vector<SSPred> sspred;
	set<int> selPos;
	string outName;
	int point;
	int size;
	int level;
};


struct Unit
{
	SS ss;
	Space sp;
	CScheme scheme;
	double distance;
	double angle;
	double nh;
};

struct Energies
{
	double loop;
	double hbond;
	double pred;
	double cys;
	double cont;
	double surf;
	double elt;
	double pol;
	double prev;
	double posbias;
};

struct Position
{
	vector<int> beg;
	double energy;
	Energies en;
	int index;
	_List_node_base *unit;
};

typedef list<Position> PosList;
typedef PosList::iterator PosIt;

struct ZData
{
	double sum;
	double sumsq;
	double count;
	ZData() { memset( this, 0, sizeof( ZData ) ); }
	ZData( const ZData& src ) { memcpy( this, &src, sizeof( ZData ) ); }
};

double zscore( double en, const ZData& d )
{
	if ( !( d.count >= 1 ) ) return 0;
	if ( d.sumsq * d.count < d.sum * d.sum ) return 0;
	return ( en - d.sum / d.count ) * sqrt( d.count / ( d.sumsq - d.sum * d.sum / d.count ) );
}

struct Cluster
{
	vector<Unit> unit;
	vector<int> tag;
	PosList pos_list;
	double energy;
	double link_energy;
	ZData z;
	ZData zprev;
	int index;
	int node;
};

typedef pair< int,int > Connection;
typedef map< Connection, int > ClusterMap;
typedef int64_t ESel;

/*
struct Sel
{
	short _data[ MaxUnitNum ];
	int _size;
	
	inline int size() const { return _size; }
	inline short& operator[] ( int pos ) { return _data[pos]; }
	inline short operator[] ( int pos ) const { return _data[pos]; } 
	inline void resize( int size ) { _size = size; };
	inline void reserve( int ) {}
};
*/
typedef vector<short> Sel;

/*
bool operator< ( const Sel& s1, const Sel& s2 )
{
	if ( s1._size < s2._size ) return true;
	if ( s1._size > s2._size ) return false;
	return memcmp( s1._data, s2._data, s1._size * sizeof( short ) ) < 0;
}
*/
//typedef vector<int> Sel;

static Sel convert_sel( ESel key )
{
	Sel rv;
	for ( int ic = 0; ic < sizeof( ESel ) * 8; ic++ )
	{
		if ( ( 1 << ic ) & key ) rv.push_back( ic );
	}
	return rv;
}

typedef pair<int,bool> DirKey;
typedef pair<DirKey,ESel> StrKey;
typedef pair<int,ESel> OStrKey;
typedef multimap<int,ESel> OStrMap;
typedef pair<int,int> IPair;
typedef set<int> ISet;

struct TreeNode
{
	short cluster;
	short cluster2;
	short unit;
	short type;
};

typedef vector<TreeNode> Tree;

struct StrNode
{
	int node;
	int searched;
	bool processed;
	set<StrKey> deadend;
	map<StrKey,int> dir;
	Cluster cluster;
	Tree tree;
	double nc;
	int len;
	double c_energy;
	int n_beta;
	int n_hbeta;
	OStrMap left;
	OStrMap right;
	StrNode() { nc = 0; len = 0; n_beta = 0; n_hbeta = 0; }
	StrNode( const StrNode& src )
	{
		cluster = src.cluster;
		nc = src.nc;
		len = src.len;
		tree = src.tree;
		n_beta = src.n_beta;
		n_hbeta = src.n_hbeta;
		//node = src.node;
	}
	int maxbeg()
	{
		int rv = 0;
		for ( PosIt it = cluster.pos_list.begin(); it != cluster.pos_list.end(); it++ )
		{
			if ( it->beg[0] > rv ) rv = it->beg[0];
		}
		return rv;
	}
	int minend()
	{
		int rv = seq_size;
		int last = cluster.unit.size() - 1;
		for ( PosIt it = cluster.pos_list.begin(); it != cluster.pos_list.end(); it++ )
		{
			if ( it->beg[last] < rv ) rv = it->beg[last];
		}
		return rv + cluster.unit[last].ss.size;
	}
};

typedef	pair< ClusterMap, StrNode > StrUnit;
typedef list< StrUnit* > Data;
typedef Data::iterator DIt;

struct StrSet
{
	Data data;
	typedef map< ClusterMap, int > Index;
	Index index;
	typedef list< DIt > DItList;
	int point[nJobs];
	static DItList del;
	
	struct PCash
	{
		struct PItCmp
		{
			double criteria( const PosIt o )
			{
				return o->energy;
				//return zscore( o->energy, (*DIt( o->unit ))->second.cluster.z );
			}
			//bool operator() ( PosIt i1, PosIt i2 ) { return (*i1).energy < (*i2).energy; }
			bool operator() ( PosIt i1, PosIt i2 ) { return criteria(i1) < criteria(i2); }
		};
		typedef multiset<PosIt, PItCmp> Set;
		typedef Set::iterator iterator;
		Set set;
		int maxSize;
		PCash() { maxSize = MaxNumAlternativeStructures; }
		void Update( const PosIt o, double gap )
		{
			int imin, imax;
			reverse_index( (*o).index, imin, imax );
			double energy = ( (*o).energy - gap );// / ( imax - imin );
			for ( int c = imin; c < imax; c++ )
			{
				if ( bestEnergies[ c ] < energy )
				{
					bestEnergies[ c ] = energy;
				}
			}
		}
		
		bool Insert( const PosIt o )
		{
			if ( bad_energy( o->index, o->energy ) ) return false;
			if ( !set.size() && maxSize > 0 )
			{
				set.insert( o );
				Update( o, EnergyGap );
				return true;
			}
			const PosIt omax = *( --( set.end() ) );
			PItCmp cmp;
			if ( (*o).energy < (*omax).energy -  EnergyGap ) return false;
			//if ( criteria( o ) < criteria( omax ) -  2 ) return false;
			//if ( cmp( o, omin ) ) return false;
			set.insert( o );
			Update( o, EnergyGap );
			//if ( set.size() > maxSize )
			//int curMaxSize = max( 1, int( MaxNumAlternativeStructures * exp ( - (**(set.rbegin())).energy / energyFactor ) ) );
			int curMaxSize = MaxNumAlternativeStructures;
			while ( (**(set.begin())).energy < (*o).energy -  EnergyGap || set.size() > curMaxSize )
			{
				PosIt it = *(set.begin());
				if ( it == o ) 
				{
					set.erase( set.begin() );
					return false;
				}
				DIt	home = DIt( (*it).unit );
				(*home)->second.cluster.pos_list.erase( it );
				set.erase( set.begin() );
				if ( (*home)->second.cluster.pos_list.empty() )
				{
					del.push_back( home );
				}
			}
			//if ( set.size() == maxSize ) Update( *(set.begin()), 0 );
			return true;
		}
		
		bool Clear( int index )
		{
			while ( set.size() && bad_energy( index, (**(set.begin())).energy ) )
			{
				PosIt it = *(set.begin());
				DIt	home = DIt( (*it).unit );
				(*home)->second.cluster.pos_list.erase( it );
				set.erase( set.begin() );
				if ( (*home)->second.cluster.pos_list.empty() )
				{
					del.push_back( home );
				}
			}
			return set.size() == 0;
		}
		
		void Erase( const PosIt p )
		{
		    iterator it = set.find( p );
		    if ( it != set.end() ) set.erase( it );
		}
		
	};

	typedef map< IPair, PCash > Hash;
	typedef Hash::iterator HashIt;
	Hash hash;
	map<int,ISet> hashIndex;
	int cnt;
}; 

StrSet::DItList StrSet::del;

typedef	pair< const ClusterMap, StrNode > StrCUnit;

static bool match_link( Cluster& cl, LinkEntry& e, const Sel& sel, Input& i )
{
	if ( e.key.ss.size() == 1 ) return true;
	return true;
	VVector v1;
	VVector v2;
	v1.resize( 2 * e.key.ss.size() );
	v2.resize( 2 * e.key.ss.size() );
	v1[0] = v2[0] = cl.unit[ sel[0] ].sp.beg;
	v1[1] = v2[1] = cl.unit[ sel[0] ].sp.end;
	for ( int c = 1; c < e.key.ss.size(); c++ )
	{
		Space sp;
		SS& ss = e.key.ss[c];
		unit_position_s( sp, cl.unit[ sel[0] ].sp, e.o[c], i.last[ss] );
		v1[ 2 * c ] = sp.beg;
		v1[ 2 * c + 1 ] = sp.end;
		v2[ 2 * c ] = cl.unit[ sel[c] ].sp.beg;
		v2[ 2 * c + 1 ] = cl.unit[ sel[c] ].sp.end;
	}
	double sum = FindRmsd( v1.size(), &(v1[0]), &(v2[0]) );
	if ( sum > MatchLinkRmsd ) return false;
	return true;
}

static void process_contact( Unit &u, Cluster& c, Link& link, const Sel& sel, Input& i, int order )
{
	SS& ss = (order) ? link.s.key.ss[0] : link.f.key.ss[0];
	if ( order ) unit_position_s( u.sp, c.unit[ sel[0] ].sp, link.o, i.last[ss] );
	else unit_position_f( u.sp, c.unit[ sel[0] ].sp, link.o, i.last[ss] );
	u.ss = ss;
	u.scheme.resize( ss.size );
	for ( int c = 0; c < ss.size; c++ )
	{
		u.scheme.bb[c].count = 0;
	}
}

static double update_scheme( Unit& us, const CScheme& scheme )
{
	double rv = 0;
	us.scheme.add( scheme );
	for ( int c = 0; c < min( us.ss.size, scheme.s[0].size() ); c++ )
	{
		us.nh += scheme.s[0][c];
		rv += scheme.s[1][c] + scheme.s[0][c];
	}
	return rv;
}

static double update_scheme( Cluster& c, LinkEntry& e, const Sel& sel )
{
	double rv = 0;
	for ( int sc = 0; sc < e.key.ss.size(); sc++ )
	{
		rv += update_scheme( c.unit[ sel[sc] ], e.scheme[sc] );
	}
	return rv;
}

static double init_scheme( Unit& u, Input& i, double& hbond )
{
	CScheme s;
	double hb;
	u.nh = 0;
	if ( i.sch.Find( u.ss, s, hb ) ) 
	{
		hbond += hb;
		
		return update_scheme( u, s );
	}
	return 0;
}
	
static bool find_sel( LinkEntry& e, Cluster& cl, Sel& sel )
{
	int cc = 0;
	if ( sel[cc] >= cl.unit.size() ) return false;
	do
	{
		SS& ss = e.key.ss[cc];
		SS nss = cl.unit[ sel[cc] ].ss;
		if ( ss.size == nss.size && ss.type == nss.type )
		{
			cc++;
			if ( cc >= e.key.ss.size() ) return true;
			continue;
		}
		sel[cc]++;
		while ( sel[cc] >= cl.unit.size() )
		{
			cc--;			
			if ( cc < 0 ) return false;
			sel[cc]++;
			sel[ cc + 1 ] = sel[cc] + 1;
		}
	}
	while ( 1 );
}

static displacement *make_link_displ( const Unit& u1, const Unit &u2 )
{
	Vector v1[3], v2[3];
	
	v1[0] = u1.sp.beg;
	v1[1] = u1.sp.beg + u1.sp.orientation;
	v1[2] = u1.sp.end;
	v2[0] = u2.sp.beg;
	v2[1] = u2.sp.beg + u2.sp.orientation;
	v2[2] = u2.sp.end;
	return FindDisplacement( 3, v2, v1 );
}

static double segm_distance( Vector& center1, Vector& center2, Vector& end1, Vector& end2 )
{
	Vector dir1 = !( end1 - center1 );
	Vector dir2 = !( end2 - center2 );
	double t2 = ( ( center1 - center2 ) * ( dir2 - dir1 * ( dir1 * dir2 ) ) 
		/ ( 1. - ( dir1 * dir2 ) * ( dir1 * dir2 ) ) );
	if ( !( t2 > -big && t2 < big ) ) return 0;
	double t1 = t2 * ( dir1 * dir2) - ( center1 - center2 ) * dir1;
	if ( t1 < 0 ) t1 = 0;
	if ( t2 < 0 ) t2 = 0;
	if ( t1 > ( end1 - center1 ).norm() ) t1 = ( end1 - center1 ).norm();
	if ( t2 > ( end2 - center2 ).norm() ) t2 = ( end2 - center2 ).norm();
	Vector point1 = center1 + dir1 * t1;
	Vector point2 = center2 + dir2 * t2;
	return ( point2 - point1 ).norm();
}

static bool match_cluster( Cluster& cl, Unit& u, const Sel &sel )
{
	int cs = 0;
	for ( int uc = 0; uc < cl.unit.size(); uc++ )
	{
		if ( sel.size() > cs && uc == sel[cs] )
		{
			cs++;
			continue;
		}
		Unit& cu = cl.unit[uc];
		if ( segm_distance( cu.sp.beg, u.sp.beg, cu.sp.end, u.sp.end ) < MinSegmDist ) return false;
	}
	return true;
}

static bool match_coil( Cluster& cl, Vector& beg, Vector& end )
{
	int cs = 0;
	for ( int uc = 0; uc < cl.unit.size(); uc++ )
	{
		Unit& cu = cl.unit[uc];
		if ( uc > 0 )
		{
			if ( segm_distance( cl.unit[uc-1].sp.end, beg, cu.sp.beg, end ) < MinCoilDist ) 
				return false;
		}
		if ( uc == 0 && ( end - cu.sp.beg ).norm() < 1 ) continue;
		if ( uc == cl.unit.size() - 1 && ( beg - cu.sp.end ).norm() < 1 ) continue;
		if ( segm_distance( cu.sp.beg, beg, cu.sp.end, end ) < MinCSDist ) return false;
	}
	return true;
}

static double get_distance_stat( Input& i, int dist )
{
	if ( i.coil.find( dist ) == i.coil.end() ) return 0;
	return (*(i.coil.find( dist ) ) ).second;
}

static Vector last_last( const Unit &u1, Input& i )
{
	SS ss;
	ss.size = u1.ss.size;
	ss.type = u1.ss.type;
	LastData last = i.last[ss];
	Vector point1 = u1.sp.end + ( !(u1.sp.orientation) * cos( last.angle ) + 
		!(u1.sp.orientation & ( u1.sp.beg - u1.sp.end) ) * sin( last.angle ) ) * last.last;
	return point1;
}

static bool match_distance( StrNode& str, Unit& nu, bool flag, Input& i )
{
	double distance;
	if ( flag ) 
	{
		Unit& last = str.cluster.unit.back();
		last.distance = distance 
			= ( last_last( last, i ) - nu.sp.beg - nu.sp.orientation ).norm();
		last.angle = acos( ( ( last.sp.end - last.sp.beg ) * ( nu.sp.end - nu.sp.beg ) ) 
			/ ( last.sp.end - last.sp.beg ).norm()
			/ ( nu.sp.end - nu.sp.beg ).norm() );
	}
	else 
	{
		Unit& first = str.cluster.unit[0];
		nu.distance = distance = ( last_last( nu, i ) - first.sp.beg - first.sp.orientation ).norm();
		nu.angle = acos( ( ( first.sp.end - first.sp.beg ) * ( nu.sp.end - nu.sp.beg ) ) 
			/ ( first.sp.end - first.sp.beg ).norm()
			/ ( nu.sp.end - nu.sp.beg ).norm() );
	}
	if ( distance < MinCoilEndsDist ) return false;
	//str.c_energy += log( res );
	return true;
}

static bool move_cluster( Unit& um, Cluster& cl, Cluster& cl0, const Sel& sel, const Sel& nsel )
{
	displacement *displ = make_link_displ( cl.unit[ nsel[0] ], um );
	int cs = 0;
	int size0 = cl0.unit.size();
	for ( int uc = 0; uc < cl.unit.size(); uc++ )
	{
		Unit& u = cl.unit[uc];
		Vector or_a = u.sp.beg + u.sp.orientation;
		u.sp.beg = displ->Move( u.sp.beg );
		u.sp.orientation = displ->Move( or_a ) - u.sp.beg;
		u.sp.end = displ->Move( u.sp.end );
		bool f1 = true;
		if ( cs < nsel.size() && uc == nsel[cs] )
		{
			cs++;
			f1 = false;
		}
		int ucs = 0;
		for ( int ucc = 0; ucc < cl0.unit.size(); ucc++ )
		{
			bool f2 = ( ucc < size0 );
			if ( ucs < sel.size() && ucc == sel[ ucs ] )
			{
				ucs++;
				f2 = false;
			}
			Unit& cu = cl0.unit[ucc];
			if ( segm_distance( cu.sp.beg, u.sp.beg, cu.sp.end, u.sp.end ) < MinSegmDist && ( f1 || f2 ) ) 
			{
				delete displ;
				return false;
			}
			if ( ucc > 0 && f2 &&
				segm_distance( cl0.unit[ ucc - 1 ].sp.end, u.sp.beg, cu.sp.beg, u.sp.end ) < MinCSDist ) 
			{
				delete displ;
				return false;
			}
		}
		if ( !match_coil( cl0, cl0.unit.back().sp.end, u.sp.beg ) )
		{
			delete displ;
			return false;
		}
		cl0.unit.push_back( u );
	}
	delete displ;
	return true;
}

static void first_tree_node( StrNode& n )
{
	for ( int tc = 0; tc < n.tree.size(); tc++ ) if ( n.tree[tc].type != 2 ) n.tree[tc].unit++;
	n.tree.resize( n.tree.size() + 1 );
	n.tree.back().unit = 0;
	n.tree.back().cluster = 0;
	n.tree.back().type = 1;
}

static void last_tree_node( StrNode& n )
{
	n.tree.resize( n.tree.size() + 1 );
	n.tree.back().unit = n.cluster.unit.size() - 1;
	n.tree.back().cluster = 0;
	n.tree.back().type = 1;
}

static void merge_trees( StrNode& n, StrNode& right )
{
	short int maxc = 0;
	short int maxu = 0;
	int cursize = n.tree.size();
	for ( int tc = 0; tc < cursize; tc++ ) 
	{
		maxc = max( maxc, n.tree[tc].cluster );
		if ( n.tree[tc].type != 2 ) maxu = max( maxu, n.tree[tc].unit );
	}
	n.tree.resize( n.tree.size() + right.tree.size() + 1 );
	for ( int tc = cursize; tc < n.tree.size() - 1; tc++ )
	{
		n.tree[tc].type = right.tree[ tc - cursize ].type;
		n.tree[tc].cluster = maxc + 1 + right.tree[ tc - cursize ].cluster;
		if ( n.tree[tc].type == 2 )
		{
			n.tree[tc].cluster2 = maxc + 1 + right.tree[ tc - cursize ].cluster2;
		}
		else
		{
			n.tree[tc].unit = maxu + 1 + right.tree[ tc - cursize ].unit;
		}
	}
	n.tree.back().cluster = 0;
	n.tree.back().cluster2 = maxc + 1;
	n.tree.back().type = 2;
}

/*
struct Matrix
{
	int n1;
	int n2;
	double *data;
	Matrix( int N1, int N2 ) 
	{ 
		n1 = N1; 
		n2 = N2; 
		data = new double[ n1 * n2 ];
		memset( data, 0, n1 * n2 * sizeof( double ) );
	}
	~Matrix() { delete data; }
	double& at( int i1, int i2 ) { return data[ i1 * n2 + i2 ]; }
};

static void contact_weights( Matrix& w, Cluster& p, string& seq, Potential& pot )
{
	for ( int uc = 0; uc < p.unit.size(); uc++ )
	{
		for ( int sc = 0; sc < seq.size(); sc++ )
		{
			if ( sc + p.unit[uc].ss.size > seq.size() )
			{
				w.at( uc, sc ) = -big;
				continue;
			}
			w.at( uc, sc ) = 0;
			for ( int scc = 0; scc < p.unit[uc].ss.size; scc++ )
			{
				w.at( uc, sc ) += pot.weight( seq[ sc + scc ], min( int(p.unit[uc].scheme[scc]), tom1_max - 1 ) );
			}
		}
	}
}
*/

#include "coils.cpp"
#include "letters.cpp"
#include "contacts.cpp"

int cSum[ maxLength ] = { 0 };

double SelEnergy( int length, double dist, double angle )
{
	int cd = int( dist );
	int ca = int ( angle * maxAngle / 3.1416 );
	double bad = -big;
	if ( length < 0 || length >= maxLength ) return bad;
	if ( cd < 0 || cd >= maxDist ) return bad;
	if ( ca < 0 || ca >= maxAngle ) return bad;
	int res = coilData[ length ][ cd ][ ca ];
	if ( res == 0 ) return bad;
	return log( res ) - cOffsets[ length ];// - log( cSum[ length ] );
}

double LoopEnergy( int beg, int length, Unit& u, Input& i )
{
	double cv = 0;
	//return SelEnergy( length, u.distance, u.angle ) * i.pot.coilEnergy + i.pot.coilOffset;
	return ( SelEnergy( length, u.distance, u.angle ) ) * energyFactor - coilOffset + cv; // + length * lengthFactor;
}

double CysEnergy( Cluster& cl, Position& pos, Input& i )
{
	double rv = 0;
	for ( int uc1 = 0; uc1 < cl.unit.size(); uc1++ )
	{
		for ( int sc1 = 0; sc1 < cl.unit[uc1].ss.size; sc1++ )
		{
			if ( i.seq[ pos.beg[uc1] + sc1 ] != 'C' ) continue;
			Vector v1 = cl.unit[uc1].sp.beg + ( cl.unit[uc1].sp.end - cl.unit[uc1].sp.end ) * ( double( sc1 ) / ( cl.unit[uc1].ss.size - 1 )   );
			for ( int uc2 = 0; uc2 < uc1; uc2++ )
			{
				for ( int sc2 = 0; sc2 < cl.unit[uc2].ss.size; sc2++ )
				{
					if ( i.seq[ pos.beg[uc2] + sc2 ] != 'C' ) continue;
					Vector v2 = cl.unit[uc2].sp.beg + ( cl.unit[uc2].sp.end - cl.unit[uc2].sp.end ) * ( double( sc2 ) / ( cl.unit[uc2].ss.size - 1 )   );
					if ( (v1 - v2).norm() < 7 ) rv += CysBridgeTerm;
				}
			}
		}
	}
	return rv;
}

/*
static void loop_weights( Matrix& w, Cluster& p, string& seq, Potential& pot )
{
	for ( int uc = 0; uc < p.unit.size() - 1; uc++ )
	{
		for ( int sc = 0; sc < seq.size(); sc++ )
		{
			if ( sc > 20 )
			{
				w.at( uc, sc ) = -big;
				continue; 
			}
			w.at( uc, sc ) = SelEnergy( sc, p.unit[uc].distance ) * pot.energyFactor + sc * pot.lengthFactor;
		}
	}
}

int Dynamic( Cluster& p, string& seq, Potential& pot )
{
	Matrix w1( p.unit.size(), seq.size() );
	Matrix w2( p.unit.size(), seq.size() );
	
	contact_weights( w1, p, seq, pot );
	loop_weights( w2, p, seq, pot );
	
	Matrix m1( p.unit.size(), seq.size() );
	for ( int sc = 0; sc < seq.size(); sc++ ) m1.at( 0, sc ) = w1.at( 0, sc );
	for ( int uc = 1; uc < p.unit.size(); uc++ )
	{
		for ( int sc = 0; sc < seq.size(); sc++ )
		{
			double bweight = -big;
			for ( int scc = 0; scc < sc - p.unit[ uc - 1 ].ss.size; scc++ )
			{
				double cweight = m1.at( uc - 1, scc ) + w2.at( uc - 1, sc - scc - p.unit[ uc - 1 ].ss.size );
				if ( cweight > bweight )
				{
					bweight = cweight;
				}
			}
			m1.at( uc, sc ) = bweight + w1.at( uc, sc );
		}
	}
	double bweight = -big;
	int bc = -1;
	int uc = p.unit.size() - 1;
	for ( int sc = 0; sc < seq.size(); sc++ )
	{
		if ( m1.at( uc, sc ) > bweight )
		{
			bweight = m1.at( uc, sc );
			bc = sc;
		}
	}
	p.energy = p.link_energy * pot.hbondFactor;
	if ( bc == -1 ) return 0;
	p.unit[uc].beg = bc;
	p.energy += bweight;
	for ( uc--; uc >= 0; uc-- )
	{
		int sc = p.unit[ uc + 1 ].beg;
		bweight = -big;
		bc = -1;
		for ( int scc = 0; scc < sc - p.unit[ uc ].ss.size; scc++ )
		{
			double cweight = m1.at( uc, scc ) + w2.at( uc, sc - scc - p.unit[ uc ].ss.size );
			if ( cweight > bweight )
			{
				bc = scc;
				bweight = cweight;
			}
		}
		if ( bc == -1 ) return 0;
		p.unit[uc].beg = bc;
	}
	int end = p.unit.back().beg + p.unit.back().ss.size;
	p.index = ( end ) * seq.size() + p.unit[0].beg;
	
	//p.energy += ( seq.size() - end + p.unit[0].beg ) * pot.lengthFactor;
	//p.energy -= seq.size() * pot.lengthFactor;
	//p.energy += WeightAverage * ( end - p.unit[0].beg );
	
	return 1;
}
*/

double lw[26] = { 0 };

double SegmEnergy( const Unit& u, int beg, Input& i )
{
	//lw[ 'L' - 'A' ] = 0.1;//0.1;
	//lw[ 'K' - 'A' ] = -0.1;//0.1;
	double rv = 0;
	int ctypes[] = { 2, 1, 1, 1, 1, 1, 1, 1 };
	/*
	if ( i.sspred.size() && u.ss.size <= MaxLoopLength ) 
		rv = SSPredFactor * i.sspred[ beg ].p[ u.ss.size - 1 ][ ctypes[ u.ss.type ] ];
	*/
	for ( int c = 0; c < u.ss.size; c++ )
	{
		int ord = i.seq[ beg + c ] - 'A';
		if ( ord < 0 || ord >= 26 ) continue;
		//rv += i.pot.weight( i.seq[ beg + c ], min( int( u.scheme[c] ), tom1_max - 1 ) );
		rv += //( log( lData[ lTypes[ u.ss.type ] ][ ord  ] ) - log( cData[ 0 ][ ord ] ) - letterOffset ) * energyFactor * 0 +
			lw[ord] * u.scheme.s[1][c];
			/*+ ( log( cData[ 1 ][ ord ] ) - log( cData[ 0 ][ ord ]  )- contactOffset ) * u.scheme[c]*/
	}
	//rv += ( log( i.last[ u.ss ].weight ) - ssOffset ) * energyFactor;
	//rv -= u.ss.size * lengthFactor;
	//rv -= 3 * lengthFactor;
	rv -= 3 * lengthFactor;
	return rv;
}

#include "build.cpp"

int recalc_parallel( Cluster& cl, vector<PosIt>& posVect, Input& i )
{
    int c;
    int size = posVect.size();
#ifdef GCC41
#pragma omp parallel for default(none) shared( size ) private( c )
#else
#pragma omp parallel for default(none) shared( cl, posVect, i, size ) private( c )
#endif
    for ( c = 0; c < size; c++ )
    {
		posVect[c]->energy = RealEnergy( cl.unit, posVect[c]->beg, posVect[c]->en, i );
    }
}    

void recalc_sequential( Cluster& cl, Input& i )
{
    vector<PosIt> posVect;
    for ( PosIt it = cl.pos_list.begin(); it != cl.pos_list.end(); )
    {
	if ( (*it).energy < cl.energy - PrelimGap ) it = cl.pos_list.erase( it );
	else if ( cl.unit.size() > 1 )
	{
	    posVect.push_back( it );
	    it++;
	}
	else it++;
    }
    if ( cl.unit.size() == 1 ) return;
    recalc_parallel( cl, posVect, i );
    ZData zcur;
    double max_energy = MinClusterEnergy;
    for ( int pc = 0; pc < posVect.size(); pc++ )
    {
	PosIt it = posVect[pc];
	double& en = it->energy;
    en +=  ( it->en.hbond = cl.link_energy * i.pot.hbondFactor );
	en += it->en.loop + it->en.pred;
	en -= cl.unit.size() * 3 * lengthFactor;
	zcur.sum += en;
	zcur.sumsq += en * en;
	zcur.count++;
	if ( en > max_energy ) max_energy = en;
	if ( en  < MinClusterEnergy ) cl.pos_list.erase( it );
    }
    if ( cl.unit.size() == 2 ) cl.z = zcur;
    else
    {
	cl.z.sum = cl.z.sum * zcur.sum / cl.zprev.sum;
	cl.z.sumsq = cl.z.sumsq * zcur.sumsq / cl.zprev.sumsq;
	cl.z.count = cl.z.count * zcur.count / cl.zprev.count;
    }
    cl.energy = max_energy;
    for ( PosIt it = cl.pos_list.begin(); it != cl.pos_list.end(); )
    {
	if ( (*it).energy < cl.energy - PostGap ) it = cl.pos_list.erase( it );
	else it++;
    }
}

void debug_en_msg( double v, const char *s )
{
	//if ( !( v == v ) ) printf( "%s\n", s );
}
    
int RecalcEnergy( Cluster& cl, Input& i )
{
	int ctypes[] = { 2, 1, 1, 1, 1, 1, 1, 1 };
	cl.energy = MinClusterEnergy;
	for ( PosIt it = cl.pos_list.begin(); it != cl.pos_list.end(); it++ )
	{
		it->en.pred = 0;
		if ( i.sspred.size() ) for ( int uc = 0; uc < cl.unit.size(); uc++ )
		{
			if ( i.sspred.size() && cl.unit[uc].ss.size <= MaxLoopLength ) 
			{
				it->en.pred += SSPredFactor * 
					i.sspred[ it->beg[uc] ].p[ cl.unit[uc].ss.size - 1 ][ ctypes[ cl.unit[uc].ss.type ] ];
			}
			if ( uc < cl.unit.size() - 1 )
			{
				int length = it->beg[ uc + 1 ] - it->beg[uc] - cl.unit[uc].ss.size;
				if ( length > 0 && length <= MaxLoopLength ) 
					it->en.pred += SSPredFactor * i.sspred[ it->beg[uc] + cl.unit[uc].ss.size ].p[ length - 1 ][ 0 ];
			}
		}
		it->energy += it->en.pred;
		if ( cl.energy < it->energy ) cl.energy = it->energy;
	}
	/*
	double max_energy = MinClusterEnergy;
	ZData zcur;
	for ( PosIt it = cl.pos_list.begin(); it != cl.pos_list.end(); )
	{
		if ( (*it).energy < cl.energy - PrelimGap ) it = cl.pos_list.erase( it );
		//else if ( cl.unit.size() > 1 && (*it).energy < cl.energy - 0.5 ) it = cl.pos_list.erase( it );
		else if ( cl.unit.size() > 1 )
		{
			double en = RealEnergy( cl.unit, it->beg, i );
			en +=  cl.link_energy * i.pot.hbondFactor;
			en += it->loop_energy + it->pred_energy;
			en -= cl.unit.size() * 3 * lengthFactor;
			it->energy = en;
			zcur.sum += en;
			zcur.sumsq += en * en;
			zcur.count++;
			if ( en > max_energy ) max_energy = en;
			if ( en  < MinClusterEnergy ) it = cl.pos_list.erase( it );
			else it++;
		}
		else it++;
	}
	if ( cl.unit.size() == 2 ) cl.z = zcur;
	else
	{
		cl.z.sum = cl.z.sum * zcur.sum / cl.zprev.sum;
		cl.z.sumsq = cl.z.sumsq * zcur.sumsq / cl.zprev.sumsq;
		cl.z.count = cl.z.count * zcur.count / cl.zprev.count;
	}
	//if ( cl.unit.size() <= 2 ) return ( cl.pos_list.size() > 0 );
	cl.energy = max_energy;
	for ( PosIt it = cl.pos_list.begin(); it != cl.pos_list.end(); )
	{
		if ( (*it).energy < cl.energy - PostGap ) it = cl.pos_list.erase( it );
		else it++;
	}
	*/
	recalc_sequential( cl, i );
	for ( PosIt it = cl.pos_list.begin(); it != cl.pos_list.end(); it++ )
	{
		if ( !( it->energy == it->energy ) )
		{
			debug_en_msg( it->en.loop, "loop" );
			debug_en_msg( it->en.hbond, "hbond" );
			debug_en_msg( it->en.pred, "pred" );
			debug_en_msg( it->en.cys, "cys" );
			debug_en_msg( it->en.cont, "cont" );
			debug_en_msg( it->en.surf, "surf" );
			debug_en_msg( it->en.elt, "elt" );
			debug_en_msg( it->en.pol, "pol" );
			debug_en_msg( it->en.prev, "prev" );
		}
	}
	return ( cl.pos_list.size() > 0 );
}

int ProcessPosition( Cluster& cl, Input& i, int flag )
{
	memset( &(cl.zprev), 0, sizeof( ZData ) );
	if ( cl.unit.size() == 2 )
	{
		cl.energy = MinClusterEnergy;
		for ( int sc1 = 0; sc1 < int( i.seq.size() ) - cl.unit[1].ss.size - cl.unit[0].ss.size - MinLoopLength; sc1++ )
		{
			Energies en;
			double ien =  en.hbond = cl.link_energy * i.pot.hbondFactor;
			double e1 = ien + SegmEnergy( cl.unit[0], sc1, i );
			int end1 = sc1 + cl.unit[0].ss.size;
			for ( int sc2 = end1 + MinLoopLength; 
				sc2 < int( i.seq.size() ) - cl.unit[1].ss.size && sc2 < end1 + MaxLoopLength; sc2++ )
			{
				double le = en.loop = LoopEnergy( end1, sc2 - end1, cl.unit[0], i );
				double e2 = e1 + ( en.cont = SegmEnergy( cl.unit[1], sc2, i ) ) + le;
				if ( e2 < cl.energy - EnergyGap ) continue;
				if ( cl.energy < e2 ) cl.energy = e2;
				Position pos;
				pos.beg.resize( 2 );
				pos.beg[0] = sc1;
				pos.beg[1] = sc2;
				pos.energy = e2;
				pos.en = en;
				pos.index = calc_index( sc2 + cl.unit[1].ss.size, sc1 );
				pos.energy += ( pos.en.cys = CysEnergy( cl, pos, i ) );
				if ( bad_energy( pos.index, pos.energy )  ) continue;
				cl.pos_list.push_back( pos );
			}
		}
	}
	else if ( flag == 1 )
	{
		PosList prev = cl.pos_list;
		cl.pos_list.clear();
		cl.energy = MinClusterEnergy;
		for ( PosIt it = prev.begin(); it != prev.end(); it++ )
		{
			Energies en;
			cl.zprev.sum += it->energy;
			cl.zprev.sumsq += it->energy * it->energy;
			cl.zprev.count++;
			int end = (*it).beg.back() + cl.unit[ cl.unit.size() - 2 ].ss.size;
			double ien =  en.hbond = cl.link_energy * i.pot.hbondFactor;
			double ile = 0;
			for ( int cc = 0; cc < (*it).beg.size(); cc++ )
			{
				ien += SegmEnergy( cl.unit[cc], (*it).beg[cc], i );
				if ( cc > 0 ) 
					ile += LoopEnergy( (*it).beg[ cc - 1 ] + cl.unit[ cc - 1 ].ss.size,
						(*it).beg[cc] - (*it).beg[ cc - 1 ] - cl.unit[ cc - 1 ].ss.size, cl.unit[ cc - 1 ], i );
			}
			en.cont = ien - en.hbond;
			for ( int sc = end + MinLoopLength; 
				sc < int( i.seq.size() ) - cl.unit.back().ss.size && sc < end + MaxLoopLength; sc++ )
			{
				double le = ile + LoopEnergy( end, sc - end, cl.unit[ cl.unit.size() - 2 ], i );
				double cen = ien + SegmEnergy( cl.unit.back(), sc, i ) + le;
				if ( cen < cl.energy - EnergyGap ) continue;
				if ( cl.energy < cen ) cl.energy = cen;
				Position pos = *it;
				pos.beg.push_back( sc );
				pos.energy = cen;
				pos.en = en;
				pos.en.prev = it->energy;
				pos.en.loop = le;
				pos.index = calc_index( sc + cl.unit.back().ss.size, pos.beg[0] );
				pos.energy += ( pos.en.cys = CysEnergy( cl, pos, i ) );
				if ( bad_energy( pos.index, pos.energy )  ) continue;
				cl.pos_list.push_back( pos );
			}
		}
	}
	else if ( flag == 0 )
	{
		PosList prev = cl.pos_list;
		cl.pos_list.clear();
		cl.energy = MinClusterEnergy;
		for ( PosIt it = prev.begin(); it != prev.end(); it++ )
		{
			Energies en;
			cl.zprev.sum += it->energy;
			cl.zprev.sumsq += it->energy * it->energy;
			cl.zprev.count++;
			int beg = (*it).beg[0] - cl.unit[0].ss.size;
			double ien = en.hbond = cl.link_energy * i.pot.hbondFactor;
			double ile = 0;
			for ( int cc = 0; cc < (*it).beg.size(); cc++ )
			{
				ien += SegmEnergy( cl.unit[ cc + 1 ], (*it).beg[cc], i );
				if ( cc > 0 ) 
					ile += LoopEnergy( (*it).beg[ cc - 1 ] + cl.unit[ cc ].ss.size,
					(*it).beg[cc] - (*it).beg[ cc - 1 ] - cl.unit[ cc ].ss.size, cl.unit[ cc ], i );
			}
			en.cont = ien - en.hbond;
			for ( int sc = beg - MinLoopLength;
				sc >= 0 && sc > beg - MaxLoopLength; sc-- )
			{
				double le = ile + LoopEnergy( sc, beg - sc, cl.unit[ 0 ], i );
				double cen = ien + SegmEnergy( cl.unit[0], sc, i ) + le;
				if ( cen < cl.energy - EnergyGap ) continue;
				if ( cl.energy < cen ) cl.energy = cen;
				Position pos = *it;
				pos.beg.insert( pos.beg.begin(), sc );
				pos.energy = cen;
				pos.en = en;
				pos.en.prev = it->energy;
				pos.en.loop = le;
				pos.index = calc_index( pos.beg.back() + cl.unit.back().ss.size, sc );
				pos.energy += ( pos.en.cys = CysEnergy( cl, pos, i ) );
				if ( bad_energy( pos.index, pos.energy )  ) continue;
				cl.pos_list.push_back( pos );
			}
		}
	}
	return RecalcEnergy( cl, i );
}

int MergePositions( Cluster& cl, PosList& right, Input& i )
{
	if ( cl.unit.size() == 2 )
	{
		return ProcessPosition( cl, i, 1 );
	}
	else if ( !cl.pos_list.size() && !right.size() )
	{
		return 0;
	}
	else if ( !right.size() && cl.unit.size() - cl.pos_list.front().beg.size() == 1 )
	{
		return ProcessPosition( cl, i, 1 );
	}
	else if ( !cl.pos_list.size() && cl.unit.size() - right.front().beg.size() == 1 )
	{
		cl.pos_list = right;
		return ProcessPosition( cl, i, 0 );
	}
	else if ( !cl.pos_list.size() || !right.size() )
	{
		return 0;
	}
	
	PosList prev = cl.pos_list;
	cl.pos_list.clear();
	cl.energy = MinClusterEnergy;
	ZData z1;
	for ( PosIt it = prev.begin(); it != prev.end(); it++ )
	{
		it->en.prev = it->energy;
		double& ien = (*it).energy;
		z1.sum += ien;
		z1.sumsq += ien * ien;
		z1.count++;
		ien = 0;
		for ( int cc = 0; cc < (*it).beg.size(); cc++ )
		{
			ien += SegmEnergy( cl.unit[ cc ], (*it).beg[cc], i );
			//if ( cc > 0 ) 
			//	ien += LoopEnergy( (*it).beg[ cc - 1 ] + cl.unit[ cc - 1 ].ss.size,
			//	(*it).beg[cc] - (*it).beg[ cc - 1 ] - cl.unit[ cc - 1 ].ss.size, cl.unit[ cc - 1 ], i );
		}
		it->en.cont = ien;
	}
	ZData z2;
	for ( PosIt it = right.begin(); it != right.end(); it++ )
	{
		it->en.prev = it->energy;
		double& ien = (*it).energy;
		z2.sum += ien;
		z2.sumsq += ien * ien;
		z2.count++;
		ien = 0;
		for ( int cc = 0; cc < (*it).beg.size(); cc++ )
		{
			int ncc = cc + cl.unit.size() - (*it).beg.size();
			ien += SegmEnergy( cl.unit[ ncc ], (*it).beg[cc], i );
			//if ( cc > 0 ) 
			//	ien += LoopEnergy( (*it).beg[ cc - 1 ] + cl.unit[ ncc - 1 ].ss.size,
			//	(*it).beg[cc] - (*it).beg[ cc - 1 ] - cl.unit[ ncc - 1 ].ss.size, cl.unit[ ncc - 1 ], i );
		}
		it->en.cont = ien;
	}
	cl.zprev.sumsq = ( z1.sumsq / z1.count + z2.sumsq / z2.count ) * ( z1.count * z2.count ) + 2 * z1.sum * z2.sum;
	cl.zprev.sum = ( z1.sum / z1.count + z2.sum / z2.count ) * ( z1.count * z2.count );
	cl.zprev.count = z1.count * z2.count;
	for ( PosIt it = prev.begin(); it != prev.end(); it++ )
	{
		int end = (*it).beg.back() + cl.unit[ (*it).beg.size() - 1 ].ss.size;
		for ( PosIt it1 = right.begin(); it1 != right.end(); it1++ )
		{
			int beg = (*it1).beg[0];
			if ( beg - end < MinLoopLength ) continue;
			if ( beg - end > MaxLoopLength ) continue;
			double le = (*it).en.loop + (*it1).en.loop + LoopEnergy( end, beg - end, cl.unit[ (*it).beg.size() - 1 ], i );
			double en = (*it).energy + (*it1).energy + le;
			Position pos = *it;
			en += ( pos.en.hbond = cl.link_energy * i.pot.hbondFactor );
			if ( en < cl.energy - EnergyGap ) continue;
			if ( cl.energy < en ) cl.energy = en;
			for ( int bc = 0; bc < (*it1).beg.size(); bc++ ) pos.beg.push_back( (*it1).beg[bc] );
			pos.energy = en;
			pos.en.prev = it->en.prev + it1->en.prev;
			pos.en.cont += it1->en.cont;
			pos.en.loop = le;
			pos.index = calc_index( pos.beg.back() + cl.unit.back().ss.size, pos.beg[0] );
			pos.energy += ( pos.en.cys = CysEnergy( cl, pos, i ) );
			if ( bad_energy( pos.index, pos.energy )  ) continue;
			cl.pos_list.push_back( pos );
		}
	}
	return RecalcEnergy( cl, i );
}

int CutPosition( Cluster& cl, Input& i, int flag )
{
	cl.energy = MinClusterEnergy;
	ZData& z = cl.zprev;
	for ( PosIt it = cl.pos_list.begin(); it != cl.pos_list.end(); it++ )
	{
		double& ien = (*it).energy;
		z.sum += ien;
		z.sumsq += ien * ien;
		z.count++;
		ien = 0;
		if ( flag == 1 ) it->beg.erase( it->beg.begin() + it->beg.size() - 1 );
		else if ( flag == 0 ) it->beg.erase( it->beg.begin() );
		it->index = calc_index( it->beg.back() + cl.unit.back().ss.size, it->beg[0] );
		double le = 0;
		for ( int cc = 0; cc < (*it).beg.size(); cc++ )
		{
			ien += SegmEnergy( cl.unit[ cc ], (*it).beg[cc], i );
			if ( cc > 0 ) 
				le += LoopEnergy( (*it).beg[ cc - 1 ] + cl.unit[ cc - 1 ].ss.size,
				(*it).beg[cc] - (*it).beg[ cc - 1 ] - cl.unit[ cc - 1 ].ss.size, cl.unit[ cc - 1 ], i );
		}
		ien += le;
		it->en.loop = le;
	}
	return RecalcEnergy( cl, i );
}

static double diameter( StrNode& node )
{
	double rv = 0;
	for ( int uc = 0; uc < node.cluster.unit.size(); uc++ )
	{
		Unit& u1 = node.cluster.unit[uc];
		for ( int ucc = 0; ucc < uc; ucc++ )
		{
			Unit& u2 = node.cluster.unit[ucc];
			double d;
			d = ( u1.sp.beg - u2.sp.beg ).norm(); if ( d > rv ) rv = d;
			d = ( u1.sp.beg - u2.sp.end ).norm(); if ( d > rv ) rv = d;
			d = ( u1.sp.end - u2.sp.end ).norm(); if ( d > rv ) rv = d;
			d = ( u1.sp.end - u2.sp.beg ).norm(); if ( d > rv ) rv = d;
		}
	}
	return rv;
}

bool vol_measure( StrNode& node )
{
	return true // 0.2 * node.nc + node.c_energy - node.len > -2.* 8.//pow( node.len, 0.66 ) 
		&& node.len < 100
		&& diameter( node ) < 10. * pow( node.len * 1.3, 0.333 );
}

inline bool cmp_ostrkey( const OStrKey& k1, const OStrKey& k2 )
{
	return k1.first < k2.first;
}

static int AddUnit( void *list, StrUnit *unit );

void make_dirs( StrUnit& str, Input& i, bool start = false )
{
	Cluster& ccl = str.second.cluster;
	ESel ssize = 1 << ccl.unit.size();
	for ( ESel cs = 0; cs < ssize; cs++ )
	{
		ESel esel = cs;
		Sel sel;
		sel.reserve( ccl.unit.size() );
		LinkKey key;
		key.ss.reserve( ccl.unit.size() );
		for ( int uc = 0; uc < ccl.unit.size(); uc++ )
		{
			if ( !( cs & ( 1 << uc ) ) ) continue;
			sel.resize( key.ss.size() + 1 );
			if ( sel.size() > MaxLinkNum ) break;
			sel[ key.ss.size() ] = uc;
			key.ss.resize( key.ss.size() + 1 );
			key.ss.back().size = ccl.unit[uc].ss.size;
			key.ss.back().type = ccl.unit[uc].ss.type;
		}
		if ( sel.size() > MaxLinkNum ) continue;
		LinkAcc::Map::iterator it;
		it = i.link.mapf.find( key );
		if ( it != i.link.mapf.end() ) 
		for ( LinkList::iterator it1 = (*it).second.begin(); it1 != (*it).second.end(); it1++ )
		{
			Link& link = *it1;
			//StrKey strKey( DirKey( link.tag, false ), sel );
			//if ( str.second.deadend.find( strKey ) != str.second.deadend.end() ) continue;
			//if ( str.second.dir.find( strKey ) != str.second.dir.end() ) continue;
			if ( !match_link( ccl, link.f, sel, i ) ) continue;
			if ( !MergeClusters && link.s.key.ss.size() > 1 ) continue;
			//str.second.left.insert( OStrKey( strKey.first.first, strKey.second ) );
			str.second.left.insert( OStrKey( link.tag, esel ) );
		}
		it = i.link.maps.find( key );
		if ( it != i.link.maps.end() ) 
		for ( LinkList::iterator it1 = (*it).second.begin(); it1 != (*it).second.end(); it1++ )
		{
			Link& link = *it1;
			//StrKey strKey( DirKey( link.tag, true ), sel );
			//if ( str.second.deadend.find( strKey ) != str.second.deadend.end() ) continue;
			//if ( str.second.dir.find( strKey ) != str.second.dir.end() ) continue;
			if ( !match_link( ccl, link.s, sel, i ) ) continue;
			if ( !MergeClusters && link.f.key.ss.size() > 1 ) continue;
			//str.second.right.insert( OStrKey( strKey.first.first, strKey.second ) );
			str.second.right.insert( OStrKey( link.tag, esel ) );
		}
		if ( !start ) for ( int dc = -1; dc <= 1; dc += 2 )
		for ( int sc = 0; sc < key.ss.size(); sc++ )
		{
		if ( key.ss[sc].size + dc < 3 ) continue;
		LinkKey mkey = key;
		mkey.ss[sc].size += dc;
		LinkAcc::Map::iterator it;
		it = i.link.mapf.find( mkey );
		if ( it != i.link.mapf.end() ) 
		for ( LinkList::iterator it1 = (*it).second.begin(); it1 != (*it).second.end(); it1++ )
		{
			Link& link = *it1;
			//StrKey strKey( DirKey( link.tag, false ), sel );
			//if ( str.second.deadend.find( strKey ) != str.second.deadend.end() ) continue;
			//if ( str.second.dir.find( strKey ) != str.second.dir.end() ) continue;
			if ( !match_link( ccl, link.f, sel, i ) ) continue;
			if ( !MergeClusters && link.s.key.ss.size() > 1 ) continue;
			//str.second.left.insert( OStrKey( strKey.first.first, strKey.second ) );
			str.second.left.insert( OStrKey( link.tag, esel ) );
		}
		it = i.link.maps.find( mkey );
		if ( it != i.link.maps.end() ) 
		for ( LinkList::iterator it1 = (*it).second.begin(); it1 != (*it).second.end(); it1++ )
		{
			Link& link = *it1;
			//StrKey strKey( DirKey( link.tag, true ), sel );
			//if ( str.second.deadend.find( strKey ) != str.second.deadend.end() ) continue;
			//if ( str.second.dir.find( strKey ) != str.second.dir.end() ) continue;
			if ( !match_link( ccl, link.s, sel, i ) ) continue;
			if ( !MergeClusters && link.f.key.ss.size() > 1 ) continue;
			//str.second.right.insert( OStrKey( strKey.first.first, strKey.second ) );
			str.second.right.insert( OStrKey( link.tag, esel ) );
		}
		}
	}
	//Dynamic( str.second.cluster, i.seq, i.pot );
	//str.second.cluster.energy -= sqr( diameter( str.second ) ) * 0.004;
	str.second.searched = 0;
	str.second.processed = false;
}
 
static double link_energy( const Link& link, Input& i )
{
    return link.weight - i.linkAvg[ LinkPKey( link.f.key,link.s.key ) ];
}

static void make_link( StrSet& strSet, StrUnit *puLeft, StrUnit *puRight, 
	const StrKey& kLeft, const StrKey& kRight, Input& i )
{
	if ( puLeft->second.minend() > puRight->second.maxbeg() ) return;
	StrUnit &uLeft = *puLeft;
	StrUnit &uRight = *puRight;
	StrUnit *pnstr = new StrUnit( uLeft );
	StrUnit &nstr = *pnstr;
	//nstr.second.dir.clear();
	//nstr.second.right.clear();
	//nstr.second.left.clear();
	int diff = uLeft.second.cluster.unit.size();
	if ( diff + uRight.second.cluster.unit.size() > MaxUnitNum ) 
	{
		delete pnstr;
		return;
	}
	/*
	for ( ClusterMap::const_iterator c_it = uRight.first.begin(); c_it != uRight.first.end(); c_it++ )
	{
		nstr.first[ Connection( (*c_it).first.first + diff, (*c_it).first.second + diff ) ] 
			= (*c_it).second;
	}
	*/
	Link &link = *( i.link.index[ kLeft.first.first ] );
	const Sel sLeft = convert_sel( kLeft.second );
	const Sel sRight = convert_sel( kRight.second );
	/*
	for ( int cl = 0; cl < sLeft.size(); cl++ )
	{
		for ( int cr = 0; cr < sRight.size(); cr++ )
		{
			nstr.first[ Connection( sLeft[cl], sRight[cr] + diff ) ] = link.tag;
		}
	}
	*/
	/*
	StrSet::Index::iterator s_it = strSet.index.find( nstr.first );
	if ( s_it != strSet.index.end() )
	{
		uLeft.second.dir[ kLeft ] = (*s_it).second;
		uRight.second.dir[ kRight ] = (*s_it).second;
		return;
	}
	*/
	Cluster ncl = uRight.second.cluster;
	nstr.second.nc += uRight.second.nc;
	nstr.second.nc += update_scheme( nstr.second.cluster, link.f, sLeft );
	nstr.second.nc += update_scheme( ncl, link.s, sRight );
	nstr.second.len += uRight.second.len;
	nstr.second.c_energy += uRight.second.c_energy;
	nstr.second.cluster.link_energy += link.hbond + uRight.second.cluster.link_energy;  
	nstr.second.cluster.link_energy += link_energy( link, i );
	nstr.second.n_hbeta += int( link.hbond ) + uRight.second.n_hbeta;  
	nstr.second.n_beta += uRight.second.n_hbeta;  
	Unit nu;
	process_contact( nu, nstr.second.cluster, link, sLeft, i, 1 );
	if ( !match_distance( nstr.second, nu, true, i ) 
		|| !vol_measure( nstr.second ) ) 
	{
		delete pnstr;
		return;
	}
	if ( !move_cluster( 
		nu, 
		ncl,
		nstr.second.cluster, 
		sLeft,
		sRight ) ) 
	{
		//uLeft.second.deadend.insert( kLeft );
		//uRight.second.deadend.insert( kRight );
		delete pnstr;
		return;
	}
	ZData& z1 = nstr.second.cluster.z;
	ZData& z2 = ncl.z;
	z1.sumsq = ( z1.sumsq / z1.count + z2.sumsq / z2.count ) * ( z1.count * z2.count ) + 2 * z1.sum * z2.sum;
	z1.sum = ( z1.sum / z1.count + z2.sum / z2.count ) * ( z1.count * z2.count );
	z1.count *= z2.count;
	if ( !MergePositions( nstr.second.cluster, ncl.pos_list, i ) )
	{
		delete pnstr;
		return;
	}
	merge_trees( nstr.second, uRight.second );
	make_dirs( nstr, i );
	AddUnit( &strSet, pnstr );
	//uLeft.second.dir[ kLeft ] = nstr.second.node;
	//uRight.second.dir[ kRight ] = nstr.second.node;
}

/*
void Reduce( StrSet& strSet, StrUnit *pstr, Input& i )
{
	if ( pstr->second.cluster.unit.size() <= 2 ) return;
	if ( pstr->second.tree.back().type != 1 || 
		pstr->second.tree.back().unit != pstr->second.cluster.unit.size() - 1 )
	{
		StrUnit *pnstr = new StrUnit( *pstr );
		StrUnit &nstr = *pnstr;
		nstr.second.len -= nstr.second.cluster.unit.back().ss.size;
		nstr.second.cluster.link_energy -= nstr.second.cluster.unit.back().nh;
		//nstr.second.n_hbeta += int( link.hbond );
		//if ( link.s.key.ss[0].type == 0 ) nstr.second.n_beta ++;//= link.s.key.ss[0].size;
		//if ( link.s.key.ss[0].type ) nstr.second.nc += link.s.key.ss[0].size - 3;
		Cluster& nccl = nstr.second.cluster;
		nccl.unit.erase( nccl.unit.begin() + nccl.unit.size() - 1 );
		if ( !CutPosition( nccl, i, 1 ) )
		{
			delete pnstr;
		}
		else
		{
			TreeNode ntn;
			ntn.cluster = 0;
			ntn.unit = nccl.unit.size();
			ntn.type = 3;
			nstr.second.tree.push_back( ntn );
			make_dirs( nstr, i );
			AddUnit( &strSet, pnstr );
		}
	}
	if ( pstr->second.tree.back().type != 1 || 
		pstr->second.tree.back().unit != 0 )
	{
		StrUnit *pnstr = new StrUnit( *pstr );
		StrUnit &nstr = *pnstr;
		nstr.second.len -= nstr.second.cluster.unit[0].ss.size;
		nstr.second.cluster.link_energy -= nstr.second.cluster.unit[0].nh;
		//nstr.second.n_hbeta += int( link.hbond );
		//if ( link.s.key.ss[0].type == 0 ) nstr.second.n_beta ++;//= link.s.key.ss[0].size;
		//if ( link.s.key.ss[0].type ) nstr.second.nc += link.s.key.ss[0].size - 3;
		Cluster& nccl = nstr.second.cluster;
		nccl.unit.erase( nccl.unit.begin() );
		if ( !CutPosition( nccl, i, 0 ) )
		{
			delete pnstr;
		}
		else
		{
			TreeNode ntn;
			ntn.cluster = 0;
			ntn.unit = 0;
			ntn.type = 3;
			nstr.second.tree.push_back( ntn );
			make_dirs( nstr, i );
			AddUnit( &strSet, pnstr );
		}
	}
}
*/
		
void EnumStep( StrSet& strSet, StrUnit *pstr, int last, Input& i )
{
	StrUnit& str = *pstr;
	str.second.processed = true;
	Cluster& ccl = str.second.cluster;
	multimap<int,ESel>& left = str.second.left;
	multimap<int,ESel>& right = str.second.right;
	
	for ( multimap<int,ESel>::iterator l_it = left.begin(); l_it != left.end(); l_it++ )
	{
		Link &link = *( i.link.index[ (*l_it).first ] );
		Sel sel = convert_sel( (*l_it).second );
		if ( link.s.key.ss.size() == 1 )
		{
			if ( str.second.cluster.unit.size() + 1 >= MaxUnitNum ) continue;
			StrUnit *pnstr = new StrUnit( str );
			StrUnit &nstr = *pnstr;
			nstr.second.len += link.s.key.ss[0].size;
			nstr.second.cluster.link_energy += link.hbond;
			nstr.second.cluster.link_energy += link_energy( link, i );
			nstr.second.n_hbeta += int( link.hbond );
			if ( link.s.key.ss[0].type == 0 ) nstr.second.n_beta ++;
			if ( link.s.key.ss[0].type ) nstr.second.nc += link.s.key.ss[0].size - 3;
			Unit nu;
			process_contact( nu, ccl, link, sel, i, 1 );
			if ( !match_cluster( ccl, nu, sel ) 
				|| !match_coil( ccl, ccl.unit.back().sp.end, nu.sp.beg ) )
			{
				delete pnstr;
				continue;
			}
			Cluster& nccl = nstr.second.cluster;
			nstr.second.nc += update_scheme( nccl, link.f, sel );
			nstr.second.nc += update_scheme( nu, link.s.scheme[0] ) + init_scheme( nu, i, nccl.link_energy );
			if ( !match_distance( nstr.second, nu, true, i ) 
				|| !vol_measure( nstr.second ) ) 
			{
				delete pnstr;
				continue;    
			}
			nccl.unit.push_back( nu );
			if ( !ProcessPosition( nccl, i, 1 ) )
			{
				delete pnstr;
				continue;
			}
			first_tree_node( nstr.second );
			make_dirs( nstr, i );
			AddUnit( &strSet, pnstr );
		}
	}
	for ( multimap<int,ESel>::iterator r_it = right.begin(); r_it != right.end(); r_it++ )
	{
		Link &link = *( i.link.index[ (*r_it).first ] );
		Sel sel = convert_sel( (*r_it).second );
		if ( link.f.key.ss.size() == 1 )
		{
			if ( str.second.cluster.unit.size() + 1 >= MaxUnitNum ) continue;
			StrUnit *pnstr = new StrUnit;
			StrUnit &nstr = *pnstr;
			nstr.second.tree = str.second.tree;
			nstr.second.cluster = str.second.cluster;
			nstr.second.len = str.second.len + link.f.key.ss[0].size;
			nstr.second.nc = str.second.nc;
			nstr.second.c_energy = str.second.c_energy;
			nstr.second.n_hbeta = str.second.n_hbeta;
			nstr.second.n_beta = str.second.n_beta;
			nstr.second.cluster.link_energy += link.hbond;
			nstr.second.cluster.link_energy += link_energy( link, i );
			if ( link.f.key.ss[0].type ) nstr.second.nc += link.f.key.ss[0].size - 3;
			nstr.second.n_hbeta += int( link.hbond );
			if ( link.f.key.ss[0].type == 0 ) nstr.second.n_beta ++;
			Unit nu;
			process_contact( nu, ccl, link, sel, i, 0 );
			if ( !match_cluster( ccl, nu, sel ) 
				|| !match_coil( ccl, nu.sp.end, ccl.unit[0].sp.beg ) )
			{
				delete pnstr;
				continue;
			}
			Cluster& nccl = nstr.second.cluster;
			nstr.second.nc += update_scheme( nccl, link.s, sel );
			nstr.second.nc += update_scheme( nu, link.f.scheme[0] ) + init_scheme( nu, i, nccl.link_energy );
			if ( !match_distance( nstr.second, nu, false, i ) 
				|| !vol_measure( nstr.second ) ) 
			{
				delete pnstr;
				continue;
			}
			nccl.unit.insert( nccl.unit.begin(), nu );
			if ( !ProcessPosition( nccl, i, 0 ) )
			{
				delete pnstr;
				continue;
			}
			last_tree_node( nstr.second );
			make_dirs( nstr, i );
			AddUnit( &strSet, pnstr );
		}
	}
	int lastc = 0;
	if ( MergeClusters ) for ( DIt s_it = strSet.data.begin(); s_it != strSet.data.end() && lastc < last; s_it++, lastc++ )
	{
		StrUnit *pcstr = *s_it;
		StrUnit& cstr = *pcstr;
		cstr.second.processed = true;
		set<OStrKey> intersect;
		insert_iterator< set<OStrKey> > ii( intersect, intersect.begin() );
		set_intersection( left.begin(), 
			left.end(), 
			cstr.second.right.begin(), 
			cstr.second.right.end(),
			ii, cmp_ostrkey );
		for ( set<OStrKey>::iterator k_it = intersect.begin(); k_it != intersect.end(); k_it++ )
		{
			StrKey kLeft( DirKey( (*k_it).first, false ), (*k_it).second );
			for ( multimap<int,ESel>::iterator m_it = cstr.second.right.lower_bound( (*k_it).first );
				m_it != cstr.second.right.upper_bound( (*k_it).first ); m_it++ )
			{
				StrKey kRight( DirKey( (*m_it).first, true ), (*m_it).second );
				make_link( strSet, pstr, pcstr, kLeft, kRight, i );
			}
		}
		intersect.clear();
		set_intersection( right.begin(), 
			right.end(), 
			cstr.second.left.begin(), 
			cstr.second.left.end(),
			ii, cmp_ostrkey );
		for ( set<OStrKey>::iterator k_it = intersect.begin(); k_it != intersect.end(); k_it++ )
		{
			StrKey kRight( DirKey( (*k_it).first, true ), (*k_it).second );
			for ( multimap<int,ESel>::iterator m_it = cstr.second.left.lower_bound( (*k_it).first );
				m_it != cstr.second.left.upper_bound( (*k_it).first ); m_it++ )
			{
				StrKey kLeft( DirKey( (*m_it).first, false ), (*m_it).second );
				make_link( strSet, pcstr, pstr, kLeft, kRight, i );
			}
		}
		if ( pcstr != pstr ) cstr.second.processed = false;
	}
	str.second.searched = 1;
	str.second.processed = false;
}

void AddMono( StrSet& strSet, Input& i )
{
	SS ss;
	double value;
	int tag;
	i.mono.Begin();
	int d_cnt = 0;
	while( i.mono.Next( ss, value, tag ) )
	{
		Space space;
		space.beg = Vector( 0, 0, 0 );
		space.orientation = Vector( 0, -1, 0 ) * i.last[ss].last;
		space.end = space.beg + Vector( 0, 0, 1 ) * i.last[ss].dist;
		StrUnit *pu = new StrUnit;
		StrUnit& u = *pu;
		u.first[ Connection( 0, 0 ) ] = tag;
		u.second.cluster.unit.resize( 1 );
		u.second.cluster.unit[0].ss = ss;
		u.second.cluster.unit[0].sp = space;
		u.second.cluster.unit[0].scheme.resize( ss.size );
		u.second.cluster.link_energy = 0;//log( value ) * energyFactor / hbondFactor;
		u.second.cluster.energy = 0;
		/*
		for ( int c = 0; c < ss.size; c++ )
		{
			u.second.cluster.unit[0].scheme[c] = 0;
		}
		*/
		u.second.nc += init_scheme( u.second.cluster.unit[0], i, u.second.cluster.link_energy );
		u.second.len = ss.size;
		u.second.c_energy = 0;
		if ( ss.type != 0 ) u.second.n_beta = 1;
		if ( ss.type ) u.second.nc += ss.size - 3;
		u.second.nc = 0;
		int node = strSet.data.size();
		u.second.node = node;
		u.second.tree.resize( 1 );
		u.second.tree[0].unit = 0;
		u.second.tree[0].type = 0;
		u.second.tree[0].cluster = 0;
		make_dirs( u, i, true );
		//strSet.index[ u.first ] = node;
		strSet.data.push_back( pu );
		if ( u.second.cluster.link_energy > 0 ) d_cnt++;
	}
}
		
static void load_orientation( Orientation& o, Line& l )
{
	o.dist = l.GetDouble( fDistance );
	o.angle = l.GetDouble( fAngle );
	o.orient1 = l.GetDouble( fOrient1 );
	o.orient2 = l.GetDouble( fOrient2 );
	o.offset1 = l.GetDouble( fOffset1 );
	o.offset2 = l.GetDouble( fOffset2 );
}

static void load_relvector( RelVector& rv, Line& l )
{
	rv.dist = l.GetDouble( fDistance );
	rv.angle = l.GetDouble( fAngle );
	rv.last = l.GetDouble( fLast );
}

static void load_link_head( Link& link, Line& l )
{
	int size1 = l.GetInt( fNumSS1 );
	link.f.key.ss.resize( size1 );
	link.f.o.resize( size1 );
	link.f.scheme.resize( size1 );
	int size2 = l.GetInt( fNumSS2 );
	link.s.key.ss.resize( size2 );
	link.s.o.resize( size2 );
	link.s.scheme.resize( size2 );
	link.hbond = l.GetInt( fHBond );
	link.tag = l.GetInt( fTag );
	link.weight = log( l.GetDouble( fValue ) ) * energyFactor / hbondFactor;
	//link.hbond += ( log( link.weight ) - linkOffset ) * energyFactor / hbondFactor;
}

static int load_link_detail( Link& link, Line& l )
{
	int rect = l.GetInt( fRecType );
	int order = l.GetInt( fOrder );
	if ( rect == 0 ) 
	{
		link.f.key.ss[order].size = l.GetInt( fSize );

		link.f.key.ss[order].type = l.GetInt( fType );
		link.f.scheme[order].resize( link.f.key.ss[order].size );
		Line ll;
		if ( l.GetFirst( ll ) ) do
		{
			if ( ll.GetType() == rScheme ) 
				link.f.scheme[ order ].s[ ll.GetInt( fType ) ][ ll.GetInt( fOrder ) ] = ll.GetDouble( fValue );
			else if ( ll.GetType() == rBackbone ) 
			{
				load_relvector( link.f.scheme[ order ].bb[ ll.GetInt( fOrder ) ].atom[ ll.GetInt( fAtom ) ], ll );
				link.f.scheme[ order ].bb[ ll.GetInt( fOrder ) ].count = 1;
			}
		}
		while ( l.GetNext( ll ) );
		if ( order > 0 ) load_orientation( link.f.o[order], l );
	}
	else
	{
		link.s.key.ss[order].size = l.GetInt( fSize );
		link.s.key.ss[order].type = l.GetInt( fType );
		link.s.scheme[order].resize( link.s.key.ss[order].size );
		Line ll;
		if ( l.GetFirst( ll ) ) do
		{
			if ( ll.GetType() == rScheme ) 
				link.s.scheme[ order ].s[ ll.GetInt( fType ) ][ ll.GetInt( fOrder ) ] = ll.GetDouble( fValue );
			else if ( ll.GetType() == rBackbone ) 
			{
				load_relvector( link.s.scheme[ order ].bb[ ll.GetInt( fOrder ) ].atom[ ll.GetInt( fAtom ) ], ll );
				link.s.scheme[ order ].bb[ ll.GetInt( fOrder ) ].count = 1;
			}
		}
		while ( l.GetNext( ll ) );
		if ( order > 0 ) load_orientation( link.s.o[order], l );
		else load_orientation( link.o, l );
	}
	return ( rect == 1 && order == link.s.key.ss.size() - 1 );
}

bool LoadWeights( Input& i, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return false;
	map < LinkPKey, int, ComparePLinks > linkCount;

	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;

		if ( res != eOK ) return false;
		if ( l.GetType() == rMono )
		{
			SS ss;
			ss.type = l.GetInt( fType );
			ss.size = l.GetInt( fSize );
			double weight = l.GetDouble( fValue );
			i.mono.Add( ss, weight, l.GetInt( fTag ) );
		}
		else if ( l.GetType() == rLink )
		{
			Link link;
			load_link_head( link, l );
			Line l2;
			if ( l.GetFirst( l2 ) ) do
			{
				load_link_detail( link, l2 );
			}
			while ( l.GetNext( l2 ) );
			i.link.Count( link );
			if ( i.linkAvg.find( LinkPKey( link.f.key, link.s.key ) ) == i.linkAvg.end() ) 
			{
			    i.linkAvg[ LinkPKey( link.f.key, link.s.key ) ] = 0;
			    linkCount[ LinkPKey( link.f.key, link.s.key ) ] = 0;
			}
			//i.linkAvg[ LinkPKey( link.f.key, link.s.key ) ] += link.weight;
			double& m = i.linkAvg[ LinkPKey( link.f.key, link.s.key ) ];
			if ( m < link.weight ) m = link.weight;
			linkCount[ LinkPKey( link.f.key, link.s.key ) ]++;
		}
		else if ( l.GetType() == rLast )
		{
			SS ss;
			LastData last;
			ss.type = l.GetInt( fType );
			ss.size = l.GetInt( fSize );
			last.dist = l.GetDouble( fDistance );
			last.angle = l.GetDouble( fAngle );
			last.last = l.GetDouble( fLast );
			last.weight = l.GetDouble( fValue );
			i.last[ss] = last;
		}
		else if ( l.GetType() == rSS )
		{
			SS ss;
			ss.size = l.GetInt( fSize );
			ss.type = l.GetInt( fType );
			double hbond = l.GetDouble( fHBond );
			Line ll;
			CScheme sch;
			sch.resize( ss.size );
			if ( l.GetFirst( ll ) ) do
			{
				sch.s[ ll.GetInt( fType ) ][ ll.GetInt( fOrder ) ] = ll.GetDouble( fValue );
				sch.bb[ ll.GetInt( fOrder ) ].count = 0;
			}
			while ( l.GetNext( ll ) );
			i.sch.Count( ss, sch, 1, hbond );
		}
		else if ( l.GetType() == rCoil )
		{
					i.coil[ l.GetInt( fDistance ) ] = l.GetDouble( fValue );
		} 
	}
	while ( 1 );
	fclose( ifile );
	/*
	for ( map<LinkPKey,int,ComparePLinks>::iterator it = linkCount.begin(); it != linkCount.end(); it++ )
	{
	    i.linkAvg[ it->first ] /= it->second;
	}
	*/
	return true;
}

int LoadSequence( Input& i, const char *fname )
{ 
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	do
	{
		int c = getc( ifile );
		if ( c == EOF ) break;
		if ( c >= 'A' && c <= 'Z' ) i.seq.push_back( c );
	}
	while ( 1 );
	fclose( ifile );
	seq_size = i.seq.size();
	bestEnergies = new double[ seq_size ];
	for ( int c = 0; c < seq_size; c++ ) bestEnergies[c] = MinClusterEnergy;
	return 1;
}

int LoadPot( Input& i, const char *pname )
{
	Potential& pot = i.pot;
	pot.hbondFactor = hbondFactor;
	
	/*
	int letter = 0;
	while ( letter < 26 && lw[letter] == 0 ) letter++;
	if ( letter < 26 )
	{
		int cnt = 0;
		for ( int sc = 0; sc < i.seq.size(); sc++ ) if ( i.seq[sc] == letter + 'A' ) cnt++;
		double value = -( lw[letter] * cnt ) / i.seq.size();
		for ( int lc = 0; lc < 26; lc++ )
		{
			if ( lc == letter ) continue;
			lw[lc] = value;
		}
	}
	*/
	for ( int letter = 0; letter < 26; letter++ )
	{
		if ( cData[0][letter] == 0 ) continue;
		lw[letter] = log( cData[1][letter] / cData[0][letter] / 6.51 ) * contactFactor;
	}
	/*
	for ( int lc = 0; lc < maxLength; lc++ )
	{
		for ( int dc = 0; dc < maxDist; dc++ )
		{
			for ( int ac = 0; ac < maxAngle; ac++ )
			{
				cSum[lc] += coilData[lc][dc][ac];
			}
		}
	}
	*/
	
	return 1;
	
	
	FILE *ifile = fopen( pname, "rt" );
	if ( !ifile ) return 0;
	double zero[ 26 ] = { 0 };
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		//if ( l.GetType() == rPotGap ) EnergyGap = l.GetDouble( fValue );
		if ( l.GetType() == rCoilEnergy ) pot.coilEnergy = l.GetDouble( fValue );
		if ( l.GetType() == rCoilOffset ) pot.coilOffset = l.GetDouble( fValue );
		if ( l.GetType() == rHBondFactor ) pot.hbondFactor = l.GetDouble( fValue );
		if ( l.GetType() == rPotential )
		{
			int ord = *((l.GetString( fLetter )).data()) - 'A';
			//if ( l.GetInt( fNumContacts ) == 0 ) zero[ ord ] = l.GetDouble( fValue );
			pot.lw[ ord ][ l.GetInt( fNumContacts ) ] = l.GetDouble( fValue ) - zero[ ord ];
		}
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

int LoadSSPred( Input& i, const char *pname )
{
	i.sspred.resize( i.seq.size() );
	FILE *ifile = fopen( pname, "rt" );
	if ( !ifile ) return 0;
	double zero[ 26 ] = { 0 };
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		int pos = l.GetInt( fFirst );
		if ( pos > i.sspred.size() ) return 0;
		i.sspred[pos].p[ l.GetInt( fSize ) - 1 ][ l.GetInt( fType ) ] 
		    = l.GetDouble( fValue ) * l.GetInt( fSize );
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

int LoadSelPos( Input& i, const char *pname )
{
	FILE *ifile = fopen( pname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	while ( fgets( buf, 256, ifile ) )
	{
		i.selPos.insert( atoi( buf ) );
	}
	fclose( ifile );
	return 1;
}

static string print_scheme( const Unit& u )
{
	string rv;
	for ( int c = 0; c < u.ss.size; c++ )
	{
		rv.append( 1, 'A' + int( u.scheme.s[1][c] ) );
	}
	return rv;
}

static Input *debug_ptr_to_input;

PosList::const_iterator SavePathway( const StrNode& node, int order, FILE *ofile )
{
	const Cluster& p = node.cluster;
	Line lh( rStruct );
	lh.PutInt( fOrder, order );
	double energy = -big;
	PosList::const_iterator best;
	for ( PosList::const_iterator it = p.pos_list.begin(); it != p.pos_list.end(); it++ )
	{
		if ( (*it).energy > energy )
		{
			best = it;
			energy = (*it).energy;
		}
	}
	if ( energy == -big ) return p.pos_list.end();
	lh.PutDouble( fEnergy, p.energy );
	lh.PutDouble( "HB", p.link_energy );
	lh.PutDouble( "EHBOND", best->en.hbond );
	lh.PutDouble( "ELOOP", best->en.loop );
	lh.PutDouble( "EPRED", best->en.pred );
	lh.PutDouble( "ECYS", best->en.cys );
	lh.PutDouble( "ESURF", best->en.surf );
	lh.PutDouble( "ECONT", best->en.cont );
	lh.PutDouble( "EELT", best->en.elt );
	lh.PutDouble( "EPOL", best->en.pol );
	lh.PutDouble( "EPOSBIAS", best->en.posbias );
	lh.PutDouble( "ZSCORE", zscore( best->energy, p.z ) );
	for ( int uc = 0; uc < p.unit.size(); uc++ )
	{
		const Unit &u = p.unit[uc];
		Line l( rSS );
		l.PutInt( fOrder, order );
		l.PutInt( fCluster, 0 );
		l.PutInt( fOrder, uc );
		l.PutInt( fFirst, (*best).beg[uc] );
		l.PutInt( fSize, u.ss.size );
		l.PutInt( fType, u.ss.type );
		l.PutVector( fCenter, u.sp.beg );
		l.PutVector( fDir, u.sp.end - u.sp.beg );
		l.PutVector( fOrientation, u.sp.orientation );
		l.PutDouble( "UEN", SegmEnergy( u, (*best).beg[uc], *debug_ptr_to_input ) );
		l.PutString( "USCH", print_scheme( u ) );
		lh.PutLine( l );
	}
	for ( int tc = 0; tc < node.tree.size(); tc++ )
	{
		Line l( rPWSim );
		l.PutInt( fOrder, tc );
		l.PutInt( fType, node.tree[tc].type );
		l.PutInt( fCluster, node.tree[tc].cluster );
		if ( node.tree[tc].type == 2 )
		{
			l.PutInt( fCluster2, node.tree[tc].cluster2 );
		}
		else
		{
			l.PutInt( fNumSS, node.tree[tc].unit );
		}
		lh.PutLine( l );
	}
	lh.Write( ofile );
	return best;
}

/*
void SavePathway( const StrNode& node, FILE *ofile, Input& i )
{
	Line lh( rPathway );
	lh.PutInt( fOrder, node.node );
	lh.PutInt( fSize, node.cluster.unit.size() );
	//lh.PutDouble( fEnergy, p.energy );
	//lh.Write( ofile );
	const Cluster &cl = node.cluster;
	for ( int uc = 0; uc < cl.unit.size(); uc++ )
	{
		const Unit &u = cl.unit[uc];
		double distance = 0;
		if ( uc < cl.unit.size() - 1 )
		{
			distance = ( last_last( u, i ) - cl.unit[ uc + 1 ].sp.beg - cl.unit[ uc + 1 ].sp.orientation ).norm();
		}
		Line l( rUnit );
		l.PutInt( fPathway, node.node );
		l.PutInt( fOrder, uc );
		l.PutInt( fSize, u.ss.size );
		l.PutInt( fType, u.ss.type );
		l.PutVector( fCenter, u.sp.beg );
		l.PutVector( fDir, u.sp.end - u.sp.beg );
		l.PutVector( fOrientation, u.sp.orientation );
		l.PutDouble( fDistance, distance );
		//l.Write( ofile );
		for ( int lc = 0; lc < u.ss.size; lc++ )
		{
			Line ll( rLetter );
			ll.PutInt( fPathway, node.node );
			ll.PutInt( fUnit, uc );
			ll.PutInt( fOrder, lc );
			ll.PutDouble( fScheme, u.scheme[lc] );
			l.PutLine( ll );
		}
		lh.PutLine( l );
	}
	lh.Write( ofile );
}
*/

int add_unit( StrSet *set, StrUnit *unit )
{
	if ( !set->data.size() ) set->cnt = 0;
	int rv = 1;
	unit->second.node = set->cnt++;
	//int length = unit.second.cluster.unit.back().beg + unit.second.cluster.unit.back().ss.size - unit.second.cluster.unit[0].beg;
	if ( unit->second.cluster.energy  < MinClusterEnergy )//0.4 * pow( (double)length, 0.66 ) ) 
	{
		delete unit;
		return 0;
	}

	/*
	StrSet::HashIt hit = set->hash.find( unit.second.cluster.index );
	if ( hit != set->hash.end() && (*((*hit).second)).second.cluster.energy >= unit.second.cluster.energy ) return rv;
	*/
	
	DIt dit = set->data.insert( set->data.end(), unit );
	bool success = false;
	int betaKey = 0;//unit->second.n_beta == 0 ? 0 : 1;
	//int( sqrt( 2 * unit->second.n_beta - unit->second.n_hbeta ) );
	for ( PosIt it = unit->second.cluster.pos_list.begin(); it != unit->second.cluster.pos_list.end(); )
	{
		(*it).unit = dit._M_node;
		if ( set->hash[ IPair( (*it).index, betaKey  ) ].Insert( it ) )
		{	
			set->hashIndex[ (*it).index ].insert( betaKey );
			int imin, imax;
			reverse_index( (*it).index, imin, imax );
			for ( int c1 = imin; c1 <= imax; c1++ )
			{
				for ( int c2 = imin; c2 < c1; c2++ )
				{
					int nindex = calc_index( c1, c2 );
					if ( set->hashIndex.find( nindex ) == set->hashIndex.end() ) continue;
					for ( ISet::iterator m_it = set->hashIndex[nindex].begin();
						m_it != set->hashIndex[nindex].end(); m_it++ )
					{
						if ( set->hash[ IPair( nindex, *m_it ) ].Clear( nindex ) )
						{
							set->hash.erase( set->hash.find( IPair( nindex, *m_it ) ) );
							set->hashIndex[ nindex ].erase( m_it );
						}
					}
				}
			}
			it++;
			success = true;
		}
		else it = unit->second.cluster.pos_list.erase( it );
	}
	if ( !success ) 
	{
		set->del.push_back( dit );
		rv = 0;
	}
	else if ( set->data.size() > MaxNumStructures )
	{
	    double worst_energy = 100000;
	    DIt ws;
	    for ( DIt wit = set->data.begin(); wit != set->data.end(); wit++ )
	    {
		bool toDel = false;
		for ( StrSet::DItList::iterator delIt = set->del.begin(); delIt != set->del.end(); delIt++ )
		{
		    if ( *delIt == wit )
		    {
			toDel = true;
			break;
		    }
		}
		if ( toDel ) continue;
		if ( (*wit)->second.cluster.energy < worst_energy )
		{
		    worst_energy = (*wit)->second.cluster.energy;
		    ws = wit;
		}
	    } 
	    for ( PosIt it = (*ws)->second.cluster.pos_list.begin(); it != (*ws)->second.cluster.pos_list.end(); it++ )
	    {
		set->hash[ IPair( (*it).index, 0  ) ].Erase( it );
		//it = (*ws)->second.cluster.pos_list.erase( it );
	    }
	    set->del.push_back( ws );
	    if ( ws == dit ) rv = 0;
	}
	StrSet::DItList::iterator delIt = set->del.begin();
	while ( delIt != set->del.end() )
	{
		DIt del = *delIt;
		if ( (*del)->second.processed ) 
		{
			delIt++;
			continue;
		};
		int cpoint = 0;
		for ( DIt wit = set->data.begin(); wit != set->data.end() && wit != del; wit++, cpoint++ );
		for ( int pc = 0; pc < nJobs; pc++ )
		{
		    if ( set->point[pc] == cpoint )
		    {
			memmove( set->point + pc, set->point + pc + 1, ( nJobs - pc - 1 ) * sizeof( int ) );
			set->point[ nJobs - 1 ] = -1;
		    }
		    if ( set->point[pc] > cpoint ) set->point[pc]--;
		}
		//StrSet::Index::iterator idel = set->index.find( (*del).first );
		//if ( idel != set->index.end() ) set->index.erase( idel );
		delete *del;
		set->data.erase( del );
		delIt = set->del.erase( delIt );
	}
	return rv;
}

bool operator< ( const StrNode& n1, const StrNode& n2 ) { return n1.cluster.energy < n2.cluster.energy; }

struct PCash
{
	typedef set<StrNode> Set;
	typedef Set::reverse_iterator iterator;
	Set theSet;
	int maxSize;
	
	PCash( int theMaxSize ) 
	{ 
		maxSize = theMaxSize; 
	}
	
	bool Insert( const StrNode& o )
	{
		if ( !theSet.size() && maxSize > 0 )
		{
			theSet.insert( o );
			return true;
		}
		const StrNode& omin = *( theSet.begin() );
		if ( o < omin && theSet.size() >= maxSize ) return false;
		theSet.insert( o );
		if ( theSet.size() > maxSize )
		{
			theSet.erase( theSet.begin() );
		}
		return true;
	}
};

static void write_loopy_cmd( const Cluster& ccl, Input& i, int number )
{
    char fname[40];
    char pdbname[30];
    char loopyname[40];
    char chmodcmd[60];
    sprintf( fname, "%s-loops%d.sh", i.outName.data(), number );
    sprintf( pdbname, "%s%d.pdb", i.outName.data(), number );
    sprintf( loopyname, "%s%d_loopy.pdb", i.outName.data(), number );
    FILE *ofile = fopen( fname, "wt" );
    fprintf( ofile, "#/bin/bash\n" );
    for ( int uc = 0; uc < ccl.unit.size() - 1; uc++ )
    {
		int beg = ccl.pos_list.begin()->beg[uc] + ccl.unit[uc].ss.size - 1;
		int end = ccl.pos_list.begin()->beg[uc+1];
		int cgap = ( uc == 0 ) ? 0 : end - beg - 1;
		for ( int gc = 0; gc < 3; gc++, beg--, end++ )
		{
			int coffset = ( uc == 0 ) ? 0 : ccl.pos_list.begin()->beg[0];
        	fprintf( ofile, "loopy -obj %d-%d -res %*.*s %s\n", beg - coffset, end - coffset - cgap, 
				end - beg + 1, end - beg + 1, i.seq.data() + beg, pdbname );
			fprintf( ofile, "if [ -f %s ]\nthen\nmv %s %s\nelse\n", loopyname, loopyname, pdbname );
		}
		fprintf( ofile, "echo \"bad loops\"\nrm %s\nexit 1\nfi\nfi\nfi\n", pdbname );
    }
    
    fclose( ofile );
    sprintf( chmodcmd, "chmod +x %s", fname );
    system( chmodcmd );
}

void save_result( StrSet *res, Input& i )
{
	PCash cash( MaxNumResultStructures );
	for ( DIt it = (*res).data.begin(); it != (*res).data.end(); it++ ) 
	{
		if ( !(**it).second.cluster.pos_list.size() ) continue;
		cash.Insert( (**it).second );
		/*
		int index = (**it).second.cluster.pos_list.begin()->index;
		double energy = (**it).second.cluster.pos_list.begin()->energy;
		if ( bad_energy( index, energy ) )
		{
			printf( "e %d %g %g\n", index, energy, (**((*res).hash[index].set.begin())).energy );
		}
		*/
	}
	FILE *ofile = fopen( ( i.outName + ".pw" ).data(), "wt" );
	if ( !ofile ) return;
	Line lh( rHeader );
	lh.PutString( fSeq, i.seq );
	lh.PutInt( "LEVEL", i.level );
	lh.PutInt( "POINT", i.point );
	lh.PutInt( "SIZE", i.size );
	lh.Write( ofile );
	int cnt = 1;
	debug_ptr_to_input = &i;
	if ( (*res).data.size() ) for ( PCash::iterator cit = cash.theSet.rbegin(); cit != cash.theSet.rend(); cnt++, cit++ )
	{
		PosList::const_iterator pit = SavePathway( *cit, cnt, ofile );
		if ( cnt < 10 && pit != cit->cluster.pos_list.end() )
		{
		    char extbuf[30];
		    sprintf( extbuf, "%s%d.pdb", i.outName.data(), cnt );
		    SaveModel( cit->cluster.unit, pit->beg, i, extbuf );
		    write_loopy_cmd( cit->cluster, i, cnt );
		}
	}
	fclose( ofile );
}

struct CInput
{
	string wname;
	string sname;
	string oname;
	string spname;
	string cnname;
	string posname;
	double MaxTime;
	int letter;
	double weight;
};

int ParseInput( CInput& I, int argc, char **argv )
{
	I.MaxTime = 0;
	I.letter = 0;
	I.weight = 0;
	int cnt = 0;
	for ( int ac = 1; ac < argc; ac++ )
	{
		if ( ( strcmp( argv[ac], "-t" ) == 0 ) && ac + 1 < argc )
		{
			I.MaxTime = atof( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-sp" ) == 0 ) && ac + 1 < argc )
		{
			I.spname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-checkns" ) == 0 ) && ac + 1 < argc )
		{
			I.cnname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-selpos" ) == 0 ) && ac + 1 < argc )
		{
			I.posname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-hb" ) == 0 ) && ac + 1 < argc )
		{
			hbondFactor = atof( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-sf" ) == 0 ) && ac + 1 < argc )
		{
			SurfaceFactor = atof( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-af" ) == 0 ) && ac + 1 < argc )
		{
			AmberEnergyFactor = atof( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-ss" ) == 0 ) && ac + 1 < argc )
		{
			SSPredFactor = atof( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-l" ) == 0 ) && ac + 2 < argc )
		{
			I.letter = argv[ac+1][0];
			I.weight = atof( argv[ac+2] );
			ac += 2;
		}
		else if ( cnt == 0 )
		{
			I.wname = argv[ac];
			cnt++;
		}
		else if ( cnt == 1 )
		{
			I.sname = argv[ac];
			cnt++;
		}
		else if ( cnt == 2 )
		{
			I.oname = argv[ac];
			cnt++;
		}
	}
	if ( !I.wname.size() )
	{
		printf( "No input file\n" );
		return 0;
	}
	if ( !I.sname.size() )
	{
		printf( "No sequence file\n" );
		return 0;
	}
	if ( !I.oname.size() )
	{
		printf( "Undefined output file\n" );
		return 0;
	}
	return 1;
}

static StrUnit *next_unit( StrSet* set, int& rv, int& level )
{
	DIt s_it = set->data.begin();
	rv = -1;
	int minsize = MaxUnitNum;
	for ( int c = 0; s_it != set->data.end(); s_it++, c++ )
	{
		StrUnit *str = *s_it;
		if ( str->second.searched ) continue;
		if ( str->second.cluster.unit.size() < minsize )
		{
			minsize = str->second.cluster.unit.size();
			rv = c;
		}
	}
	level = minsize;
	s_it = set->data.begin();
	for ( int c = 0; s_it != set->data.end(); s_it++, c++ )
	{
		StrUnit *str = *s_it;
		if ( c == rv )
		{
			return str;
			break;
		}
	}
	return 0;
}

void InitParachute();

#ifndef SMPI


static int AddUnit( void *list, StrUnit *unit )
{
	StrSet *strSet = ( StrSet* )list;
	add_unit( strSet, unit );
	return strSet->cnt - 1;
}

StrSet *Enumerate( Input& i )
{
	StrSet *cur = new StrSet;
	for ( int jc = 0; jc < nJobs; jc++ ) cur->point[jc] = -1;
	AddMono( *cur, i );
	DIt pstart = (*cur).data.begin();
	int size = (*cur).data.size();
	int offset = size;
	
	int term_cnt = 0;
	static const char *term_chr = "|/-\\";
	int cnt = 0;
	
	do
	{  
		/*
		if ( cur->hash.size() > calc_index( i.seq.size(), 0 ) )
		{
			printf( "hash size too big\n" );
		}
		for ( DIt it = cur->data.begin(); it != cur->data.end(); )
		{
			if ( it->second.cluster.pos_list.size() == 0 && it->second.cluster.unit.size() > 1 )
			{
				printf( "empty position\n" );
				it = cur->data.erase( it );
				continue;
			}
			if ( it->second.cluster.pos_list.size() > 0 )
			{
				if ( cur->hash[ it->second.cluster.pos_list.begin()->index ].set.size() > MaxNumAlternativeStructures )
				{
					printf( "big set %d\n", it->second.cluster.pos_list.begin()->index );
				}
				if ( *( cur->hash[ it->second.cluster.pos_list.begin()->index ].set.begin() ) 
					!= it->second.cluster.pos_list.begin() )
				{
					printf( "wrong position at %d\n", it->second.cluster.pos_list.begin()->index );
				}
			}
			it++;
		}
		*/
		
		int pos;
		StrUnit *str = next_unit( cur, pos, i.level );
		if ( !str ) break;
		EnumStep( *cur, str, pos, i );
		i.point = pos;
		i.size = (*cur).data.size();
		printf( "\x1B[13D%6d %6d", pos, (*cur).data.size() );
		fflush( stdout );
		cnt++;
		if ( cnt % 10 == 0 ) save_result( cur, i );
		if ( MaxNumProcessedStructures > 0 && cnt > MaxNumProcessedStructures ) return cur;
		/*
		pstart = s_it;
		size = (*cur).data.size() - offset;
		offset += size;
		if ( cnt > max_cnt ) break;
		*/
		//printf( "\x1B[D*/" );
		//fflush( stdout );
		
	}
	while ( 1 );
	return cur;
}

int main( int argc, char **argv )
{
	if ( argc < 4 ) return 1;
	InitParachute();
	Input i;
	CInput I;
	ParseInput( I, argc, argv );
	//if ( I.MaxTime > 0 ) MaxTime = I.MaxTime;
	if ( I.letter > 0 ) 
	{
		lw[ I.letter - 'A' ] = I.weight;
	}
	if ( !LoadWeights( i, I.wname.data() ) ) return 1;
	if ( !LoadPot( i, 0 ) ) return 1;
	if ( !LoadSequence( i, I.sname.data() ) ) return 1;
	if ( I.spname.size() ) if ( !LoadSSPred( i, I.spname.data() ) ) return 1;
	if ( I.posname.size() ) if ( !LoadSelPos( i, I.posname.data() ) ) return 1;
	i.outName = I.oname.data();
	StrSet *res = Enumerate( i );
	save_result( res, i );
	printf( "\n" );
	return 0;
}  

#else
//#undef SEEK_SET
//#undef SEEK_CUR
//#undef SEEK_END
#include <mpi.h>
#include <unistd.h>


static double prev_time = 0;
static double wtime()
{
				double t = MPI_Wtime();
				double rv = t - prev_time;
				prev_time = t;
				return rv;
}

struct Buffer
{
	std::vector<char> data;
	int point;
	void Write( const void *ptr, int size )
	{
		data.resize( data.size() + size );
		char *p = &( *(data.end() - size) );
		memcpy( p, ptr, size );
	}
	void Read( void *ptr, int size )
	{
		memcpy( ptr, &( *(data.begin() + point) ), size );
		point += size;
	}
};

static void write_sel( Buffer& b, const ESel& sel )
{
	//int size = sel.size();
	//b.Write( &size, sizeof( int ) );
	/*
	for ( int c = 0; c < size; c++ )
	{
		b.Write( &( sel[c] ), sizeof( int ) );
	}
	*/
	//b.Write( sel._data, size * sizeof( short ) );
	b.Write( &sel, sizeof( ESel ) );
}

static void read_sel( Buffer& b, ESel& sel )
{
	//int size;
	//b.Read( &size, sizeof( int ) );
	//sel.resize( size );
	/*
	for ( int c = 0; c < size; c++ )
	{
		b.Read( &( sel[c] ), sizeof( int ) );
	}
	*/
	//b.Read( sel._data, size * sizeof( short ) );
	b.Read( &sel, sizeof( ESel ) );
}

void WriteUnit( Buffer& b, StrUnit& unit )
{
	/*
	ClusterMap& cm = unit.first;
	int csize = cm.size();
	b.Write( &csize, sizeof( int ) );
	for ( ClusterMap::iterator c_it = cm.begin(); c_it != cm.end(); c_it++ )
	{
		b.Write( &( (*c_it).first.first ), sizeof( int ) );
		b.Write( &( (*c_it).first.second ), sizeof( int ) );
		b.Write( &( (*c_it).second ), sizeof( int ) );
	}
	*/
	StrNode& n = unit.second;
	/*
	b.Write( &(n.node), sizeof( int ) );
	int de_size = n.deadend.size();
	b.Write( &de_size, sizeof( int ) );
	for ( set< StrKey >::iterator de_it = n.deadend.begin(); de_it != n.deadend.end(); de_it++ )
	{
		b.Write( &( (*de_it).first.first ), sizeof( int ) );
		b.Write( &( (*de_it).first.second ), sizeof( bool ) );
		write_sel( b, (*de_it).second );
	}
	*/
	Cluster& c = n.cluster;
	int clsize = c.unit.size();
	b.Write( &clsize, sizeof( int ) );
	b.Write( &(c.index), sizeof( int ) );
	b.Write( &(c.energy), sizeof( double ) );
	b.Write( &(c.link_energy), sizeof( double ) );
	b.Write( &(c.z), sizeof( ZData ) );
	for ( int uc = 0; uc < clsize; uc++ )
	{
		Unit& u = c.unit[uc];
		b.Write( &( u.ss ), sizeof( SS ) );
		b.Write( &( u.sp ), sizeof( Space ) );
		for ( int pc = 0; pc < u.ss.size; pc++ )
		{
			b.Write( &( u.scheme.s[0][pc] ), sizeof( double ) );
			b.Write( &( u.scheme.s[1][pc] ), sizeof( double ) );
			b.Write( &( u.scheme.s[2][pc] ), sizeof( double ) );
			b.Write( &( u.scheme.bb[pc] ), sizeof( Backbone ) );
		}
		b.Write( &( u.distance ), sizeof( double ) );
		b.Write( &( u.angle ), sizeof( double ) );
		b.Write( &( u.nh ), sizeof( double ) );
	}
	int psize = c.pos_list.size();
	b.Write( &psize, sizeof( int ) );
	for ( PosIt it = c.pos_list.begin(); it != c.pos_list.end(); it++ )
	{
		Position& p = *it;
		b.Write( &( p.energy ), sizeof( double ) );
		b.Write( &( p.en ), sizeof( Energies ) );
		b.Write( &( p.index ), sizeof( int ) );
		for ( int pc = 0; pc < c.unit.size(); pc++ )
			b.Write( &( p.beg[pc] ), sizeof( int ) );
	}
	int tsize = n.tree.size();
	b.Write( &( tsize ), sizeof( int ) );
	for ( int pc = 0; pc < tsize; pc++ )
		b.Write( &(n.tree[pc]), sizeof( TreeNode ) );
	b.Write( &( n.nc ), sizeof( double ) );
	b.Write( &( n.len ), sizeof( int ) );
	b.Write( &( n.n_beta ), sizeof( int ) );
	b.Write( &( n.n_hbeta ), sizeof( int ) );
	b.Write( &( n.c_energy ), sizeof( double ) );
	b.Write( &( n.searched ), sizeof( int ) );
	int ml_size = n.left.size();
	b.Write( &ml_size, sizeof( int ) );
	for ( multimap< int, ESel >::iterator m_it = n.left.begin(); m_it != n.left.end(); m_it++ )
	{
		b.Write( &( (*m_it).first ), sizeof( int ) );
		write_sel( b, (*m_it).second );
	}
	int mr_size = n.right.size();
	b.Write( &mr_size, sizeof( int ) );
	for ( multimap< int, ESel >::iterator m_it = n.right.begin(); m_it != n.right.end(); m_it++ )
	{
		b.Write( &( (*m_it).first ), sizeof( int ) );
		write_sel( b, (*m_it).second );
	}
}

	
void WriteSet( Buffer& b, StrSet& s )
{
	int size = s.data.size();
	b.Write( &size, sizeof( int ) );
	for ( DIt it = s.data.begin(); it != s.data.end(); it++ ) 
	{
		WriteUnit( b, **it );
	}
}

void ReadUnit( Buffer& b, StrUnit& su )
{
	/*
	ClusterMap& cm = su.first;
	int csize;
	b.Read( &csize, sizeof( int ) );
	for ( int csc = 0; csc < csize; csc++ )
	{
		int n1, n2, t;
		b.Read( &n1, sizeof( int ) );
		b.Read( &n2, sizeof( int ) );
		b.Read( &t, sizeof( int ) );
		cm[ Connection( n1, n2 ) ] = t;
	}
	*/
	StrNode& n = su.second;
	/*
	b.Read( &(n.node), sizeof( int ) );
	int de_size;
	b.Read( &de_size, sizeof( int ) );
	for ( int dc = 0; dc < de_size; dc++ )
	{
		StrKey k;
		b.Read( &( k.first.first ), sizeof( int ) );
		b.Read( &( k.first.second ), sizeof( bool ) );
		read_sel( b, k.second );
	}
	*/
	Cluster& c = n.cluster;
	int clsize;;
	b.Read( &clsize, sizeof( int ) );
	b.Read( &( c.index ), sizeof( int ) );
	b.Read( &( c.energy ), sizeof( double ) );
	b.Read( &( c.link_energy ), sizeof( double ) );
	b.Read( &( c.z ), sizeof( ZData ) );
	c.unit.resize( clsize );
	for ( int uc = 0; uc < clsize; uc++ )
	{
		Unit& u = c.unit[uc];
		b.Read( &( u.ss ), sizeof( SS ) );
		b.Read( &( u.sp ), sizeof( Space ) );
		u.scheme.resize( u.ss.size );
		for ( int pc = 0; pc < u.ss.size; pc++ )
		{
			b.Read( &( u.scheme.s[0][pc] ), sizeof( double ) );
			b.Read( &( u.scheme.s[1][pc] ), sizeof( double ) );
			b.Read( &( u.scheme.s[2][pc] ), sizeof( double ) );
			b.Read( &( u.scheme.bb[pc] ), sizeof( Backbone ) );
		}
		b.Read( &( u.distance ), sizeof( double ) );
		b.Read( &( u.angle ), sizeof( double ) );
		b.Read( &( u.nh ), sizeof( double ) );
	}
	int psize;
	b.Read( &psize, sizeof( int ) );
	for ( int pc = 0; pc < psize; pc++ )
	{
		Position p;
		p.beg.resize( c.unit.size() );
		b.Read( &( p.energy ), sizeof( double ) );
		b.Read( &( p.en ), sizeof( Energies ) );
		b.Read( &( p.index ), sizeof( int ) );
		for ( int pc = 0; pc < c.unit.size(); pc++ )
			b.Read( &( p.beg[pc] ), sizeof( int ) );
		c.pos_list.push_back( p );
	}
	int tsize;
	b.Read( &( tsize ), sizeof( int ) );
	n.tree.resize( tsize );
	for ( int pc = 0; pc < tsize; pc++ )
		b.Read( &(n.tree[pc]), sizeof( TreeNode ) );
	b.Read( &( n.nc ), sizeof( double ) );
	b.Read( &( n.len ), sizeof( int ) );
	b.Read( &( n.n_beta ), sizeof( int ) );
	b.Read( &( n.n_hbeta ), sizeof( int ) );
	b.Read( &( n.c_energy ), sizeof( double ) );
	b.Read( &( n.searched ), sizeof( int ) );
	n.processed = false;
	int ml_size;
	n.left.clear();
	b.Read( &ml_size, sizeof( int ) );
	for ( int mc = 0; mc < ml_size; mc++ )
	{
		int node;
		ESel sel;
		b.Read( &( node ), sizeof( int ) );
		read_sel( b, sel );
		n.left.insert( OStrKey( node, sel ) );
	}
	int mr_size;
	n.right.clear();
	b.Read( &mr_size, sizeof( int ) );
	for ( int mc = 0; mc < mr_size; mc++ )
	{
		int node;
		ESel sel;
		b.Read( &( node ), sizeof( int ) );
		read_sel( b, sel );
		n.right.insert( OStrKey( node, sel ) );
	}
}

void ReadSet( Buffer& b, StrSet& s )
{
	int size;
	b.Read( &size, sizeof( int ) );
	for ( int sc = 0; sc < size; sc++ ) 
	{
		StrUnit *su = new StrUnit;
		ReadUnit( b, *su );
		//s.index[ su.first ] = su.second.node;
		if ( su->second.cluster.energy <= MinClusterEnergy )
		{
			printf( "!!! %g\n", su->second.cluster.energy );
		}
		if ( su->second.cluster.unit.size() > 1 ) add_unit( &s, su );
		else s.data.push_back( su );
	}
}


enum { z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19 };
int NumNodes;
int ServNode = 0;
double MaxTime = 0;

void SendBuffer( Buffer& b, int process )
{
	int size = b.data.size();
	MPI_Send( &size, 1, MPI_INT, process, z1, MPI_COMM_WORLD );
	MPI_Send( &( b.data[0] ), size, MPI_BYTE, process, z2, MPI_COMM_WORLD );
}

void ReceiveBuffer( Buffer& b, int process )
{
	MPI_Status status;
	int size;
	MPI_Recv( &size, 1, MPI_INT, process, z1, MPI_COMM_WORLD, &status );
	b.data.resize( size );
	MPI_Recv( &( b.data[0] ), size, MPI_BYTE, process, z2, MPI_COMM_WORLD, &status );
	b.point = 0;
}

void Wait()
{
	//for ( int i = 1; i < 1000; i++ ) sin( 4. );
	sleep( 5 );
}

static int AddUnit( void *list, StrUnit* unit )
{
	StrSet *strSet = ( StrSet* )list;
	if ( !add_unit( strSet, unit ) ) return strSet->cnt - 1;
	Buffer b;
	WriteUnit( b, *unit );
	int signal = 1;
	MPI_Send( &signal, 1, MPI_INT, ServNode, z3, MPI_COMM_WORLD );
	SendBuffer( b, 0 );
	MPI_Status status;
	int node;
	MPI_Recv( &node, 1, MPI_INT, ServNode, z4, MPI_COMM_WORLD, &status );
	return node;
}

void Client( Input& i )
{
	int nPoint;
	do
	{
		MPI_Status status;
		int signal = 2;
		MPI_Send( &signal, 1, MPI_INT, ServNode, z3, MPI_COMM_WORLD );
		int command;
		MPI_Recv( &command, 1, MPI_INT, ServNode, z5, MPI_COMM_WORLD, &status );
		if ( command == 0 ) 
		{
			printf( "ending process...\n" );
			break;
		}
		if ( command == 1 ) 
		{
			Wait();
			continue;
		}
		Buffer b;
		StrSet set;
		set.del.clear();
		ReceiveBuffer( b, ServNode );
		MPI_Recv( &nPoint, 1, MPI_INT, ServNode, z6, MPI_COMM_WORLD, &status );
		MPI_Recv( set.point, nPoint, MPI_INT, ServNode, z6, MPI_COMM_WORLD, &status );
		ReadSet( b, set );
		if ( b.point != b.data.size() ) printf( "set mismatch\n" );
		for ( int pc = 0; pc < nPoint && set.point[pc] != -1; pc++ )
		{
			DIt s_it = set.data.begin();
			int size = set.data.size();
			for ( int c = 0; c < size;  s_it++, c++ )
			{
				if ( c < set.point[pc] ) continue;
				StrUnit *str = *s_it;
				EnumStep( set, str, set.point[pc], i );
				break;
			}
		}
		for ( DIt s_it = set.data.begin(); s_it != set.data.end(); s_it++ ) delete *s_it;
	}
	while ( 1 );
}

#define dump1( a ) fprintf( dfile, a ); fflush( dfile );
#define dump2( a, b ) fprintf( dfile, a, b ); fflush( dfile );
#define dump3( a, b, c ) fprintf( dfile, a, b, c ); fflush( dfile );

void Server( Input& i )
{
	double ltime = 0;
	double ctime = 0;
	//FILE *dfile = fopen( "cpw.log", "wt" );
	
	wtime();
	
	StrSet set;
	AddMono( set, i );
	
	int point[ nJobs ];
	int nPoint = nJobs;
	for ( int sc = 0; sc < nJobs; sc++ ) point[sc] = sc;
	bool *flags = new bool[ NumNodes ];
	for ( int fc = 0; fc < NumNodes; fc++ ) flags[fc] = false;
	do
	{
		ltime += wtime();
		if ( ltime > OutputTimeInterval )
		{
			ctime += ltime;
			ltime = 0;
			i.point = point[0];
			i.size = set.data.size();
			save_result( &set, i );
			if ( MaxTime > 0 && ctime > MaxTime ) break;
			printf( "level %d point %4d size %4d\n", i.level, point[0], set.data.size() );
			fflush( stdout );
		}

		int signal = 0;
		MPI_Status status;
		MPI_Recv( &signal, 1, MPI_INT, MPI_ANY_SOURCE, z3, MPI_COMM_WORLD, &status );
		int process = status.MPI_SOURCE;
		if ( signal == 1 )
		{
			Buffer b;
			ReceiveBuffer( b, process );
			StrUnit *u = new StrUnit;
			ReadUnit( b, *u );
			if ( b.point != b.data.size() ) printf( "unit mismatch\n" );
			/*
			StrSet::Index::iterator s_it = set.index.find( u.first );
			int node;
			if ( s_it != set.index.end() )
			{
				node = (*s_it).second;
			}
			else
			{
			*/
			int node = add_unit( &set, u );
			//}
			MPI_Send( &node, 1, MPI_INT, process, z4, MPI_COMM_WORLD );
		}
		else if ( signal == 2 )
		{
			int command = 2;
			StrUnit *cstr;
			nPoint = 0;
			while ( nPoint < nJobs && ( cstr = next_unit( &set, point[nPoint], i.level ) ) != 0 )
			{
				cstr->second.searched = 1;
				nPoint++;
			}
			if ( nPoint == 0 )
			{
				command = 1;
				MPI_Send( &command, 1, MPI_INT, process, z5, MPI_COMM_WORLD );
				flags[process] = false;
			}
			else
			{
				MPI_Send( &command, 1, MPI_INT, process, z5, MPI_COMM_WORLD );
				flags[process] = true;
				Buffer b;
				WriteSet( b, set );
				SendBuffer( b, process );
				MPI_Send( &nPoint, 1, MPI_INT, process, z6, MPI_COMM_WORLD );
				MPI_Send( point, nPoint, MPI_INT, process, z6, MPI_COMM_WORLD );
				//printf( "point %d size %d process %d\n", point, set.data.size(), process ); 
				//if ( best ) best->second.searched = true; 
			}
		}
		bool eflag = ( nPoint == 0 );
		for ( int pc = 0; pc < NumNodes; pc++ ) if ( flags[pc] ) eflag = false;
		if ( eflag ) break;
	}
	while ( 1 );
	printf( "exiting...\n" );
	save_result( &set, i );
	/*
	FILE *ofile = fopen( cpw, "wt" );
	for ( StrSet::Data::iterator it = set.data.begin(); it != set.data.end(); it++ ) 
	{
	SavePathway( (*it).second, ofile, i );
	}
	fclose( ofile );
	*/
	MPI_Abort( MPI_COMM_WORLD, 0 );
}

bool AssignServNode( int np, int numNodes, const char *cnName )
{
	int process = np;
	MPI_Request request;
	MPI_Status status;
	int flag = 0;
    MPI_Irecv( &process, 1, MPI_INT, MPI_ANY_SOURCE, z7, MPI_COMM_WORLD, &request);
	if ( access( cnName, R_OK ) == 0 )
	{
		sleep( 3 * np );
		MPI_Test( &request, &flag, &status );
		if ( !flag )
		{
			printf( "assigning server node %d\n", process );
			MPI_Request_free( &request );
			MPI_Request *sreq = new MPI_Request[ numNodes - 1 ];
			MPI_Status *sstat = new MPI_Status[ numNodes - 1 ];
			int rc;
			for ( int pc = 0; pc < numNodes; pc++ )
			{
				if ( pc == np ) continue;
				MPI_Isend( &process, 1, MPI_INT, pc, z7, MPI_COMM_WORLD, sreq + rc++ );
			}
			MPI_Waitall( rc, sreq, sstat );
			delete sreq;
			delete sstat;
			ServNode = process;
			return true;
		}
	}
	MPI_Wait( &request, &status );
	ServNode = process;
	return false;
}

int main( int argc, char **argv )
{
	int np;
	InitParachute();
	MPI_Init( &argc, &argv );
	MPI_Comm_rank( MPI_COMM_WORLD, &np );
	MPI_Comm_size( MPI_COMM_WORLD, &NumNodes );
	CInput I;
	ParseInput( I, argc, argv );
	if ( I.cnname.size() ) AssignServNode( np, NumNodes, I.cnname.data() );
	if ( I.MaxTime > 0 ) MaxTime = I.MaxTime;
	if ( I.letter > 0 ) 
	{
		lw[ I.letter - 'A' ] = I.weight;
	}
	Input i;
	if ( np == ServNode ) 
	{
	    printf( "loading sse combinations file..." );
	    fflush( stdout );
	}
	if ( !LoadWeights( i, I.wname.data() ) ) 
	{
	    if ( np == ServNode )
	    {
		printf( "can't load from %s, exiting.\n", I.wname.data() );
		fflush( stdout );
	    }
	    return 1;
	}
	if ( !LoadPot( i, 0 ) ) return 1;
	if ( np == ServNode ) 
	{
	    printf( "done\nloading sequence..." );
	    fflush( stdout );
	}
	if ( !LoadSequence( i, I.sname.data() ) ) 
	{
	    if ( np == ServNode )
	    {
		printf( "can't load from %s, exiting.\n", I.sname.data() );
		fflush( stdout );
	    }
	    return 1;
	}
	if ( I.spname.size() ) 
	{
	    if ( np == ServNode ) 
	    {
		printf( "done\nloading secondary structure..." );
		fflush( stdout );
	    }
	    if ( !LoadSSPred( i, I.spname.data() ) ) 
	    {
	        if ( np == ServNode )
	        {
		    printf( "can't load from %s, exiting.\n", I.spname.data() );
		    fflush( stdout );
	        }
		return 1;
	    }
	    printf( "(%d elements loaded)", i.sspred.size() ); 
	}
	if ( I.posname.size() ) 
	{
	    if ( np == ServNode ) 
	    {
		printf( "done\nloading selected positions..." );
		fflush( stdout );
	    }
	    if ( !LoadSelPos( i, I.posname.data() ) ) 
	    {
	        if ( np == ServNode )
	        {
		    printf( "can't load from %s, exiting.\n", I.posname.data() );
		    fflush( stdout );
	        }
		return 1;
	    }
	    printf( "(%d positions loaded)", i.selPos.size() );
	}
        if ( np == ServNode )
	{
	    printf( "done\n" );
	    fflush( stdout );
	}
	i.outName = I.oname;
	if ( np == ServNode ) Server( i );
	else Client( i );
	return 1;
}

#endif
