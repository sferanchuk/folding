
#include <stdio.h>
#include <math.h>

int main()
{
	printf( "double power3[360] = { " );
	for ( int cnt = 0; cnt < 360; cnt++ ) 
	{
		printf( " %g ", pow( cnt / 1000. + 0.0005, -3 ) );
		if ( cnt < 359 ) printf( "," );
	}
	printf( "};\n" );
	printf( "double power6[360] = { " );
	for ( int cnt = 0; cnt < 360; cnt++ ) 
	{
		printf( " %g ", pow( cnt / 1000. + 0.0005, -6 ) );
		if ( cnt < 359 ) printf( "," );
	}
	printf( "};\n" );
}
