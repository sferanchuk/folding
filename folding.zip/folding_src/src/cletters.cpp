
#include "common.h"

#include <map>
#include <list>
#include <set>

const int tom1_max = 15;
static char *tom1_ord = "ARNDCQEGHILKMFPSTWYV";
int type_ord[10] = { 0,1,1,1,1,2,2,2,2,2 };
int data[ 3 ][ 26 ] = { { 0 } };


int Process( const char *iname )
{
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) return 0;
	do
	{
		Line ll;
		int res = ll.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		Line l;
		if ( ll.GetFirst( l ) ) do
		{
			if ( l.GetType() == rSS )
			{
				int type = type_ord[ l.GetInt( fType ) ];
				Line l2;
				if ( l.GetFirst( l2 ) ) do
				{
					if ( l2.GetType() == rLetter ) 
					{
						char letter = *( l2.GetString( fLetter ).data() );
						data[ type ][ letter - 'A' ]++;
					}
				}
				while ( l.GetNext( l2 ) );
			}
		}
		while ( ll.GetNext( l ) );
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

int main( int argc, char **argv )
{
	if ( argc < 2 ) 
	{
		return 1;
	}
	if ( !Process( argv[1] ) )
	{
		return 1;
	}
	printf( "\nint lData[ 26 ][ 3 ] = {\n" );
	for ( int tc = 0; tc < 3; tc++ )
	{
		printf( " { " );
		for ( int lc = 0; lc < 26; lc++ )
		{
			printf( " %6d ", data[ tc ][ lc ] );
			if ( lc < 25 ) printf( " , " );
			else printf( " } " );
		}
		if ( tc < 2 ) printf( " , " );
		else printf( " }; " );
		printf( "\n" );
	}
	return 0;
}
	
