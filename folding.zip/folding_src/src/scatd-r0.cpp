
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <string>
#include <list>
using namespace std;

#include "common.h"

#include "nvector.h"

#include "nvector.tcc"

#include "chain.h"
#include "resrad.cpp"
#include "ff.cpp"
#include "power.cpp"

extern char ParachuteMsg[];

const double minSqDist = 0.0;
const int maxRot = 64;
const int maxDynSize = 5000000;

//double radii[] = { 1.65, 1.76, 1.4, 1.87, 1.87, 1.87, 1.65, 1.65, 1.65, 1.4, 2.0, 1.65, 1.87, 1.5 };
double radii[] = { 1.3, 1.6, 1.3, 1.6, 1.6, 1.6, 1.3, 1.3, 1.3, 1.3, 1.7, 1.3, 1.6, 1.3 };

struct cdouble
{
	double v;
	cdouble( double V ) { v = V; }
	cdouble() { v = 0; }
	double operator()() { return v; }
	void operator+=( double V ) { v += V; }
	void clear() { v = 0; };
	bool empty() { return v == 0; }
};
//typedef map <int, double> RotDir;
typedef nvector<cdouble> RotDir;
//typedef map <int, RotDir> RotConf;
typedef nvector<RotDir> RotConf;
//typedef map <int, RotConf> RotRes;
typedef nvector<RotConf> RotRes;
typedef map <int, RotRes> RotSet;
typedef pair<int,int> Redundant;
typedef multimap<int,int> RedundantSet;
typedef vector<int> VInt;
typedef map <VInt, VInt> ConfSet;

struct RotTree
{
	int res;
	int res1;
	//RotRes rres;
	set<int> core;
	vector<RotTree*> child;
	ConfSet maximums;
	~RotTree() { for ( int c = 0; c < child.size(); c++ ) delete child[c]; }
};

inline double vdw_energy( double sqdist, int n1, int n2 )
{
	int dindex = int( sqdist * 10 );
	if ( n1 == 10 && n2 == 10 ) return - 10;
	FFLJ& lj = ffield[ n1 ].pot[ n2 ];
	double en = -lj.c6 * power3[ dindex ] + lj.c12 * power6[ dindex ];
	if ( en < 4. ) return en * 2.5;
	return 10;
}

inline double sqri( double x ) { return x * x; }

bool calc_scwrl( const Residue& r1, const Residue& r2, int b1, int e1, int b2, int e2, double& value )
{
	char buf[20];
	bool rv = true;
	value = 0;
	FFAA *aa1 = ffaa + r1.name1 - 'A';;
	FFAA *aa2 = ffaa + r2.name1 - 'A';
	for ( int ac1 = b1; ac1 < e1; ac1++ )
	{
		const Atom& a1 = r1.atom[ac1];
		FFAtom *at1 = aa1->atom + ac1;
		for ( int ac2 = b2; ac2 < e2; ac2++ )
		{
			const Atom& a2 = r2.atom[ac2];
			if ( r1.number == r2.number + 1 && ac1 == aN && ac2 == aC ) continue;
			FFAtom *at2 = aa2->atom + ac2;
			double srad = radii[ at1->number ] + radii[ at2->number ];
			double srad2 = 20.25;
			double sqdist;
			sqdist =  sqri( a1.coord.x - a2.coord.x );
			if ( sqdist > srad2 ) continue;
			sqdist += sqri( a1.coord.y - a2.coord.y );
			if ( sqdist > srad2 ) continue;
			sqdist += sqri( a1.coord.z - a2.coord.z );
			if ( sqdist < minSqDist ) return false;
			if ( sqdist > srad2 ) continue;
			if ( !( sqdist == sqdist ) || sqdist == INFINITY ) return false;
			value += vdw_energy( sqdist, at1->number, at2->number );
		}
	}
	return rv;
}
/*
bool CalcRotSet( RotChain& rchain, RotSet& rset )
{
	double rv = 0;
	for ( int rc1 = 0; rc1 < rchain.residue.size(); rc1++ )
	{
		for ( int rc2 = 0; rc2 < rc1; rc2++ )
		{
			if ( ( rchain.residue[rc1].r[0].atom[0].coord - rchain.residue[rc2].r[0].atom[0].coord ).norm() > 12 ) continue;
			double e1;
			if ( !calc_scwrl( rchain.residue[rc1].r[0], rchain.residue[rc2].r[0], 0, 4, 0, 4, e1 ) ) return false;
			int size1 = rchain.residue[rc1].r[0].atom.size();
			int size2 = rchain.residue[rc2].r[0].atom.size();
			bool good1 = false;
			for ( int tc1 = 0; tc1 < rchain.residue[rc1].r.size(); tc1++ )
			{
				double e2;
				bool good2 = false;
				bool good3 = calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[0], 4, size1, 0, 4, e2 );
				for ( int tc2 = 0; tc2 < rchain.residue[rc2].r.size(); tc2++ )
				{
					double en, en3;
					good2 = calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[tc2], 0, 4,	
					4, size2, en3 ) 
					&& calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[tc2], 4, size1, 4, size2, en ) 
					|| good2;
					//en += e2;
					if ( en > 0.001 
						&& rchain.residue[rc1].r.size() > 1 
						&& rchain.residue[rc2].r.size() > 1
						)
					{
						rset[rc1][rc2][tc1][tc2] = en;
						rset[rc2][rc1][tc2][tc1] = en;
					}
				}
				good1 = good1 || ( good2 && good3 );
			}
			if ( !good1 ) return false;
		}
	}
	return true;
}
*/

static bool close_residues( const Residue& r1, const Residue& r2 )
{
	if ( ( r1.atom[1].coord - r2.atom[1].coord ).norm() 
		< resRad[ r1.name1 - 'A' ] + resRad[ r2.name1 - 'A' ] ) return true;
	return false;
}

bool CalcRotSetSeq( RotChain& rchain, RotSet& rset, RotConf& conf )
{
    bool rv = true;
    for ( int rc1 = 0; rc1 < rchain.residue.size(); rc1++ )
    {
	const Residue& r0 = rchain.residue[rc1].r[0];
	double e1, e2, e3, en = 0;
	int size1, size2;
        int rsize1 = rchain.residue[rc1].r.size();
        for ( int tc = 0; tc < rchain.residue[rc1].r.size(); tc++ )
	{
	    if ( rchain.residue[rc1].r[tc].freq != 0  )
			conf[rc1][tc] = - 2. * log( rchain.residue[rc1].r[tc].freq );
	    else conf[rc1][tc] = 20;
	}
        for ( int rc2 = 0; rc2 < rc1; rc2++ )
	{
		if ( !close_residues( rchain.residue[rc1].r[0], rchain.residue[rc2].r[0] ) ) continue;
		//if ( !calc_scwrl( rchain.residue[rc1].r[0], rchain.residue[rc2].r[0], 0, 4, 0, 4, e1 ) ) rv = false;
		size1 = rchain.residue[rc1].r[0].atom.size();
		size2 = rchain.residue[rc2].r[0].atom.size();
		int rsize2 = rchain.residue[rc2].r.size();
		if ( rsize2 == 1 ) continue;
		bool pairf = false;
		RotRes::iterator rres1;
		RotRes::iterator rres2;
		bool good1 = false;
		for ( int tc1 = 0; tc1 < rsize1; tc1++ )
		{
		    bool good2 = 
			calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[0], 4, size1, 0, 4, e2 );
		    conf[ rc1 ][ tc1 ] += e2;
		    bool good3 = false;
		    for ( int tc2 = 0; tc2 < rsize2; tc2++ )
		    {
			good3 |= 
			    calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[tc2], 0, 4, 4, size2, e3 )
			    && calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[tc2], 4, size1, 4, size2, en );
			conf[ rc2 ][ tc2 ] += e3;
			if ( en < 0.01 ) continue;
			if ( rsize1 == 1 && rsize2 == 1 ) continue;
			else if ( rsize1 == 1 ) conf[ rc2 ][ tc2 ] += en;
			else if ( rsize2 == 1 ) conf[ rc1 ][ tc1 ] += en;
			else
			{
       			rset[rc1][rc2][tc1][tc2] = en;
				rset[rc2][rc1][tc2][tc1] = en;
				/*
			    if ( !pairf )
			    {
				rres1 = rset[rc1].find(rc2);
				rres2 = rset[rc2].find(rc1);
				pairf = true;
			    }
			    else
			    {
				rres1->second[tc1][tc2] = en;
				rres2->second[tc2][tc1] = en;
			    }
				*/
			}
		    }
		    good1 |= good2 && good3;
		}
		if ( !good1 ) 
		{
			printf( "Error calculaing rotamers for residues %d and %d\n", rc1, rc2 );
			rv = false;
		}
	    }
   }
   return rv;
}

bool SeqRotSet( const RotChain& rchain, int rc1, double *rot, double *dir, const int *index, int indexSize )
{
	bool rv = true;
	int rotsize = rchain.residue[rc1].r.size() * rchain.residue.size() * maxRot;
	//*rot = new double[ rotsize ];
	//memset( *rot, 0, rotsize * sizeof( double ) );
	int dirsize = rchain.residue.size() * maxRot;
	//*dir = new double[ dirsize ];
	//memset( *dir, 0, dirsize * sizeof( double ) );
	const Residue& r0 = rchain.residue[rc1].r[0];
	double e1, e2, e3, en;
	int tc1, tc2, size1, size2, rsize1, rsize2, rc2;
//#pragma omp parallel for default(none) \
//     shared(rv,dirsize,rotsize,dir,rot,rc1) private(rc2,tc1,tc2,size1,size2,e1,e2,e3,en)
	for ( rc2 = 0; rc2 < rc1; rc2++ )
	{
		if ( !close_residues( rchain.residue[rc1].r[0], rchain.residue[rc2].r[0] ) ) continue;
		if ( !calc_scwrl( rchain.residue[rc1].r[0], rchain.residue[rc2].r[0], 0, 4, 0, 4, e1 ) ) rv = false;
		size1 = rchain.residue[rc1].r[0].atom.size();
		size2 = rchain.residue[rc2].r[0].atom.size();
		rsize1 = rchain.residue[rc1].r.size();
		rsize2 = rchain.residue[rc2].r.size();

		for ( int tc1 = 0; tc1 < rsize1; tc1++ )
		{
			calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[0], 4, size1, 0, 4, e2 );
			dir[ rc1 * maxRot + tc1 ] += e2;
			for ( int tc2 = 0; tc2 < rsize2; tc2++ )
			{
				calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[tc2], 0, 4, 4, size2, e3 );
				dir[ rc2 * maxRot + tc2 ] += e3;
				calc_scwrl( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[tc2], 4, size1, 4, size2, en );
				if ( en < 0.01 ) continue;
				if ( rsize1 == 1 && rsize2 == 1 ) continue;
				else if ( rsize1 == 1 ) dir[ rc2 * maxRot + tc2 ] += en;
				else if ( rsize2 == 1 ) dir[ rc1 * maxRot + tc1 ] += en;
				else
				{
				    rot[ 
					index[ rc1 * maxRot + tc1 ] * indexSize
					+ index[ rc2 * maxRot + tc2 ] ] += en;
				}
			}
		}
	}
	return rv;
}

/*
bool ParallelRotSet( const RotChain& rchain, double *rot, double *dir, int *index, int indexSize )
{
    bool rv = true;
    int rc1;
#pragma omp parallel for default(none) \
     shared(rv, rot, dir, index, indexSize )  private(rc1)
    for ( rc1 = 0; rc1 < rchain.residue.size(); rc1++ )
    {
	if ( !SeqRotSet( rchain, rc1, rot, dir, index, indexSize ) ) rv = false;
    }
    return rv;
}

bool CalcRotSetOmp( RotChain& rchain, RotSet& rset, RotConf& conf )
{
	double *rot;
	double *dir;
	int *rotIndex;
	int indexSize = 0;
	int dirsize = rchain.residue.size() * maxRot;
	dir = new double[ dirsize ];
	memset( dir, 0, dirsize * sizeof( double ) );
	rotIndex = new int[ dirsize ];
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
	    if ( rchain.residue[rc].r.size() == 1 ) continue;
	    for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
	    {
		rotIndex[ rc * maxRot + tc ] = indexSize++;
	    }
	}
	int rotsize = indexSize * indexSize;
	rot = new double[ rotsize ];
	memset( rot, 0, rotsize * sizeof( double ) );
	bool rv = ParallelRotSet( rchain, rot, dir, rotIndex, indexSize );
	for ( int rc1 = 0; rc1 < rchain.residue.size(); rc1++ )
	{
	    int rsize1 = rchain.residue[rc1].r.size();
	    for ( int tc1 = 0; tc1 < rsize1; tc1++ )
	    {
		conf[rc1][tc1] = dir[ rc1 * maxRot + tc1 ];
	    }
	    if ( rsize1 == 1 ) continue;
	    for ( int rc2 = 0; rc2 < rc1; rc2++ )
	    {
		int rsize2 = rchain.residue[rc2].r.size();
		if ( rsize2 == 1 ) continue;
		bool pairf = false;
		RotRes::iterator rres1;
		RotRes::iterator rres2;
		for ( int tc1 = 0; tc1 < rsize1; tc1++ )
		{
		    for ( int tc2 = 0; tc2 < rsize2; tc2++ )
		    {
			int ind = rotIndex[ rc1 * maxRot + tc1 ] * indexSize 
			    + rotIndex[ rc2 * maxRot + tc2 ];
			if ( rot[ind] == 0 ) continue;
			if ( !pairf )
			{
        			rset[rc1][rc2][tc1][tc2] = rot[ind];
				rset[rc2][rc1][tc2][tc1] = rot[ind];
				rres1 = rset[rc1].find(rc2);
				rres2 = rset[rc2].find(rc1);
				pairf = true;
			}
			else
			{
				rres1->second[tc1][tc2] = rot[ind];
				rres2->second[tc2][tc1] = rot[ind];
			}
		    }
		}
	    }
	}
	delete rot;
	delete dir;
	delete rotIndex;
	return rv;
}
*/
/*
#include <ANN/ANN.h>

struct AnnPoint
{
	int rot;
	int atom;
};

struct AnnRes
{
	vector< AnnPoint > plist;
	ANNpointArray points;
	ANNkd_tree *tree;
};

const int maxPoint = 300;
const double maxDist = 3.2 * 3.2;

static void conv_point( ANNpoint p, const Vector& v )
{
	p[0] = v.x;
	p[1] = v.y;
	p[2] = v.z;
}

static int calc_scwrl_energy( int resname, int anum, double rad2, double sqdist, double& rv )
{
	FFAA *aa = ffaa + resname - 'A';
	FFAtom *at = aa->atom + anum;
	double srad = radii[ at->number ] + rad2;
	double srad2 = srad * srad;
	if ( sqdist < minSqDist )
	{
		rv = 10;
		return -1;
	}
	if ( sqdist > srad2 )
	{
		rv = 0;
		return 0;
	}
	if ( sqdist < 0.68128 * srad2 )
	{
		rv = 10;
		return 1;
	}
	rv = 57.272 * ( 1. - sqrt( sqdist ) / srad );
	return 1;
}
	

bool ParallelRotSetAnn( const RotChain& rchain, int rc, const vector<AnnRes>& annres, double **rot, double **dir )
{
	double eps = 0;
	bool rv = true;
	int rotsize = rchain.residue[rc].r.size() * rchain.residue.size() * maxRot;
	//*rot = new double[ rotsize ];
	//memset( *rot, 0, rotsize * sizeof( double ) );
	int dirsize = rchain.residue.size() * maxRot;
	//*dir = new double[ dirsize ];
	//memset( *dir, 0, dirsize * sizeof( double ) );
	const Residue& r0 = rchain.residue[rc].r[0];
	FFAA *aa = ffaa + r0.name1 - 'A';
	ANNidxArray idx;
	ANNdistArray sqdists;
	ANNpoint ap;
	int ac,pc,tc,rc1,np,res;
	FFAtom *at;
	double rad,mRad,en;
#pragma omp parallel for default(none) \
     shared(rv,dirsize,rotsize,eps,dir,rot,aa,radii,rc) private(rc1,idx,sqdists,at,ac,pc,tc,res,rad,mRad,ap,en,np)
	for ( rc1 = 0; rc1 < rc; rc1++ )
	{
		if ( ( rchain.residue[rc].r[0].atom[0].coord - rchain.residue[rc1].r[0].atom[0].coord ).norm() < 12 ) 
		{
			idx = new ANNidx[ maxPoint ];
			sqdists = new ANNdist[ maxPoint ];
			ap = annAllocPt(3);
			for ( ac = 0; ac < 5 && ac < r0.atom.size(); ac++ )
			{
				at = aa->atom + ac;
				rad = radii[ at->number ];
				mRad = rad + 1.6;
				conv_point( ap, r0.atom[ac].coord );
				printf( "%d %p \n", rc1, annres[rc1].tree );
				np = annres[rc1].tree->annkFRSearch( ap, mRad * mRad, maxPoint, idx, sqdists, eps );
				for ( pc = 0; pc < np; pc++ )
				{
					const AnnPoint& point = annres[rc1].plist[ idx[ pc ] ];
					if ( rc1 == rc - 1 && point.atom == 2 && ac == 0 ) continue;
					res = calc_scwrl_energy( r0.name1, ac, rad, sqdists[pc], en );
					if ( res == 0 ) continue;
					if ( point.rot == -1  ) 
					{
						if ( res == -1 ) rv = false;
						continue;
					}
					(*dir)[ rc1 * maxRot + point.rot ] += en;
				}
			}
			for ( tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
			{
				const Residue& r = rchain.residue[rc].r[tc];
				for ( ac = 5; ac < r.atom.size(); ac++ )
				{
					at = aa->atom + ac;
					rad = radii[ at->number ];
					mRad = rad + 1.6;
					conv_point( ap, r.atom[ac].coord );
					np = annres[rc1].tree->annkFRSearch( ap, mRad * mRad, maxPoint, idx, sqdists, eps );
					for ( pc = 0; pc < np; pc++ )
					{
						const AnnPoint& point = annres[rc1].plist[ idx[ pc ] ];
						res = calc_scwrl_energy( 
							rchain.residue[ rc1 ].r[0].name1, 
							point.atom, rad, sqdists[pc], en );
						if ( res == 0 ) continue;
						if ( point.rot == -1 ) 
						{
							(*dir)[ rc * maxRot + tc] += en;
							continue;
						}
						if ( rchain.residue[rc].r.size() == 1 || rchain.residue[ rc1 ].r.size() == 1 )
						{
							if ( res == -1 ) rv = false;
							continue;
						}
						(*rot)[ tc * dirsize + rc1 * maxRot + point.rot ] += en;
					}
				}
			}
			delete [] idx;
			delete [] sqdists;
			annDeallocPt( ap );
		}
	}
	return rv;
}

bool CalcRotSetAnn( RotChain& rchain, RotSet& rset, RotConf& conf )
{
	vector<AnnRes> annres;
	annres.resize( rchain.residue.size() );
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
		Residue& r0 = rchain.residue[rc].r[0];
		for ( int ac = 0; ac < 5 && ac < r0.atom.size(); ac++ )
		{
			AnnPoint p;
			p.rot = -1;
			p.atom = ac;
			annres[rc].plist.push_back( p );
		}
		for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
		{
			Residue& r = rchain.residue[rc].r[tc];
			for ( int ac = 5; ac < r.atom.size(); ac++ )
			{
				AnnPoint p;
				p.rot = tc;
				p.atom = ac;
				annres[rc].plist.push_back( p );
			}
			conf[rc][tc] = 0;
		}
	}
	bool rv = true;
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
		int pcnt = 0;
		annres[rc].points = annAllocPts( annres[rc].plist.size(), 3);
		Residue& r0 = rchain.residue[rc].r[0];
		for ( int ac = 0; ac < 5 && ac < r0.atom.size(); ac++ )
		{
			conv_point( annres[rc].points[pcnt++], r0.atom[ac].coord );
		}
		for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
		{
			Residue& r = rchain.residue[rc].r[tc];
			for ( int ac = 5; ac < r.atom.size(); ac++ )
			{
				conv_point( annres[rc].points[pcnt++], r.atom[ac].coord );
			}
		}
		annres[rc].tree = new ANNkd_tree( annres[rc].points, annres[rc].plist.size(), 3 );			
	}
	
	
	ANNidxArray idx = new ANNidx[ maxPoint ];
	ANNdistArray sqdists = new ANNdist[ maxPoint ];
	ANNpoint ap = annAllocPt(3);
	double eps = 0;
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
		Residue& r0 = rchain.residue[rc].r[0];
		FFAA *aa = ffaa + r0.name1 - 'A';
		for ( int rc1 = 0; rc1 < rc; rc1++ )
		{
			if ( ( rchain.residue[rc].r[0].atom[0].coord - rchain.residue[rc1].r[0].atom[0].coord ).norm() > 12 ) continue;
			bool pairf = false;
			RotRes::iterator rres1;
			RotRes::iterator rres2;
			RotDir& dir = conf[rc];
			RotDir& dir1 = conf[rc1];
			for ( int ac = 0; ac < 5 && ac < r0.atom.size(); ac++ )
			{
				FFAtom *at = aa->atom + ac;
				double rad = radii[ at->number ];
				double mRad = rad + 1.6;
				conv_point( ap, r0.atom[ac].coord );
				
				int np = annres[rc1].tree->annkFRSearch( ap, mRad * mRad, maxPoint, idx, sqdists, eps );
				for ( int pc = 0; pc < np; pc++ )
				{
					AnnPoint& point = annres[rc1].plist[ idx[ pc ] ];
					if ( rc1 == rc - 1 && point.atom == 2 && ac == 0 ) continue;
					double en;
					int res = calc_scwrl_energy( r0.name1, ac, rad, sqdists[pc], en );
					if ( res == 0 ) continue;
					if ( point.rot == -1  ) 
					{
						if ( res == -1 ) rv = false;
						continue;
					}
					dir1[point.rot] += en;
				}
			}
			for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
			{
				Residue& r = rchain.residue[rc].r[tc];
				for ( int ac = 5; ac < r.atom.size(); ac++ )
				{
					FFAtom *at = aa->atom + ac;
					double rad = radii[ at->number ];
					double mRad = rad + 1.6;
					conv_point( ap, r.atom[ac].coord );
					int np = annres[rc1].tree->annkFRSearch( ap, mRad * mRad, maxPoint, idx, sqdists, eps );
					for ( int pc = 0; pc < np; pc++ )
					{
						AnnPoint& point = annres[rc1].plist[ idx[ pc ] ];
						double en;
						int res = calc_scwrl_energy( 
							rchain.residue[ rc1 ].r[0].name1, 
							point.atom, rad, sqdists[pc], en );
						if ( res == 0 ) continue;
						if ( point.rot == -1 ) 
						{
							dir[tc] += en;
							continue;
						}
						if ( rchain.residue[rc].r.size() == 1 || rchain.residue[ rc1 ].r.size() == 1 )
						{
							if ( res == -1 ) rv = false;
							continue;
						}
						//if ( en < 0.001 ) continue;
						if ( !pairf )
						{
							rset[rc1][rc][point.rot][tc] = 0;
							rset[rc][rc1][tc][point.rot] = 0;
							rres1 = rset[rc1].find(rc);
							rres2 = rset[rc].find(rc1);
							pairf = true;
						}
						else
						{
							if ( rres1->second.find( point.rot ) == rres1->second.end() 
								|| rres1->second[point.rot].find( tc ) == rres1->second[point.rot].end() )
							{
								rres1->second[point.rot][tc] = 0;
								rres2->second[tc][point.rot] = 0;
							}
						}
						rres1->second[point.rot][tc] += en;
						rres2->second[tc][point.rot] += en;
					}
				}
			}
		}
	}
	delete [] idx;
	delete [] sqdists;
	for ( int rc = 0; rc < rchain.residue.size(); rc++ ) delete annres[rc].tree;
	annClose();
	return rv;
}
*/
/*

typedef map<int, RotDir> PState;

bool PredictSide( Chain& chain, RotChain& rchain )
{
	RotSet rset;
	if ( !CalcRotSet( rchain, rset ) ) return false;
	PState state;
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
		int res = rchain.residue[rc].r[0].name1 - 'A';
		for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
		{
			state[rc][tc] = rotamerFrequences[res][tc];
		}
	}
	for ( int ic = 0; ic < 5; ic++ )
	{
		PState nstate = state;
		for ( int rc = 0; rc < rchain.residue.size(); rc++ )
		{
			int res = rchain.residue[rc].r[0].name1 - 'A';
			double ssum = 0;
			for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
			{
				double& v = nstate[rc][tc];
				double pr = rotamerFrequences[res][tc];
				for ( int rc1 = 0; rc1 < rchain.residue.size(); rc1++ )
				{
					if ( rset[rc].find(rc1) == rset[rc].end() ) continue;
					if ( rset[rc][rc1].find(tc) == rset[rc][rc1].end() ) continue;
					RotDir& dir = rset[rc][rc1][tc];
					double sum = 0;
					for ( RotDir::iterator it = dir.begin(); it != dir.end(); it++ )
					{
						sum += it->second * state[rc1][it->first];
					}
					pr *= ( 1. - exp( -sum * 0.2 ) );
				}
				v = pr;
				if ( v < 0 ) v = 0;
				ssum += v;
			}
			for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
			{
				nstate[rc][tc] /= ssum;
			}
		}
		state = nstate;
	}
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
		int best = 0;
		double bv = 0;
		for ( int tc = 0; tc < rchain.residue[rc].r.size(); tc++ )
		{
			if ( state[rc][tc] > bv )
			{
				bv = state[rc][tc];
				best = tc;
			}
		}
		chain.residue[rc] = rchain.residue[rc].r[best];
	}
	return true;
}
*/

struct DeadEnd
{
	int res1;
	int res2;
	int r1;
	int r2;
};

int DeadEndElimination( RotSet& rset, RotConf& conf )
{
	vector<DeadEnd> deadend;
	int rv = 0;
	for ( RotSet::iterator it1 = rset.begin(); it1 != rset.end(); it1++ )
	{
		RotConf csum;
		for ( RotRes::niterator it2 = it1->second.nbegin(); it2 != it1->second.nend(); it1->second.incr( it2 ) )
		{
			for ( RotConf::niterator it3 = it2.second().nbegin(); it3 != it2.second().nend(); it2.second().incr( it3 ) )
			{
				for ( RotConf::niterator it3m = it2.second().nbegin(); it3m != it2.second().nend(); it2.second().incr( it3m ) )
				{
					if ( it3 == it3m ) continue;
					if ( csum.find( it3.first ) == csum.nend()
						|| csum[ it3.first ].find( it3m.first ) == csum[it3.first].nend() )
					{
						double diff = conf[it1->first][it3.first].v - conf[it1->first][it3m.first].v;
						if ( it3.first < it3m.first )
						{
							csum[it3.first][it3m.first] = diff;
							csum[it3m.first][it3.first] = -diff;
						}
						else
						{
							csum[it3.first][it3m.first] = diff;
							csum[it3m.first][it3.first] = -diff;
						}
					}
					double emin = 1000000;
					double emax = -1000000;
					for ( RotDir::niterator it4 = it3.second().nbegin(); it4 != it3.second().nend(); it3.second().incr(it4) )
					{
						RotDir::niterator it4m = it3m.second().find( it4.first );
						double ec = (it4.second()).v;
						if ( it4m != it3m.second().nend() ) ec -= (it4m.second()).v;
						if ( ec < emin ) emin = ec;
						if ( ec > emax ) emax = ec;
					}
					if ( it3.first < it3m.first )
					{
						csum[it3.first][it3m.first] += emin;
						csum[it3m.first][it3.first] += emax;
					}
					else
					{
						csum[it3.first][it3m.first] += emin;
						csum[it3m.first][it3.first] += emax;
					}
				}
			}
		}
		set<int> sskip;
		for ( RotConf::niterator im1 = csum.nbegin(); im1 != csum.nend(); csum.incr( im1 ))
		{
			bool fflag = false;
			if ( sskip.find( im1.first ) != sskip.end() ) continue;
			for ( RotDir::niterator im2 = im1.second().nbegin(); im2 != im1.second().nend(); im1.second().incr( im2 ) )
			{
				if ( im2.second().v < 0 ) continue;
				sskip.insert( im2.first );
				fflag = true;
				break;
			}
			if ( !fflag ) continue;
			for ( RotRes::niterator it2 = it1->second.nbegin(); it2 != it1->second.nend(); it1->second.incr( it2 ) )
			{
				RotConf::niterator it3 = it2.second().find( im1.first );
				if ( it3 != it2.second().nend() )
				{
					DeadEnd de;
					de.res1 = it1->first;
					de.res2 = it2.first;
					de.r1 = im1.first;
					de.r2 = 0;
					//it2.second().erase( it3 );
					deadend.push_back( de );
				}
			}
		}
	}
			
			/*
			for ( RotConf::iterator it3 = it2->second.begin(); it3 != it2->second.end(); it3++ )
			{
				RotDir emin;
				for ( RotDir::iterator it4 = it3->second.begin(); it4 != it3->second.end(); it4++ )
				{
					double ecur = it4->second;
					for ( RotRes::iterator it5 = it1->second.begin(); it5 != it1->second.end(); it5++ )
					{
						for ( RotConf::iterator it6 = it5->second.begin(); it6 != it5->second.end(); it6++ )
						{
							if ( it6 == it3 ) continue;
							RotDir::iterator it7 = it6->second.find( it4->first );
							if ( it7 == it6->second.end() ) continue;
							if ( emin.find( it5->first ) == emin.end() ) 
								emin[it6->first] = conf[it1->first][it3->first] - conf[it1->first][it6->first];
							emin[it6->first] += ecur - it7->second;
						}
					}
				}
				bool dflag = true;
				for ( RotDir::iterator it8 = emin.begin(); it8 != emin.end(); it8++ )
				{
					if ( it8->second < 0 ) 
					{
						dflag = false;
						break;
					}
				}
				if ( dflag )
				{
					DeadEnd de;
					de.res1 = it1->first;
					de.res2 = it2->first;
					de.r1 = it3->first;
					de.r2 = 0;
					deadend.push_back( de );
					break;
				}
			}
		}
	}
			*/
	for ( int dc = 0; dc < deadend.size(); dc++ )
	{
		DeadEnd& de = deadend[dc];
		if ( rset[de.res1].find(de.res2) == rset[de.res1].nend() ) continue;
		RotConf::niterator it1 = rset[de.res1][de.res2].find( de.r1 );
		if ( it1 != rset[de.res1][de.res2].nend() ) 
		{
			for ( RotDir::niterator it2 = it1.second().nbegin(); it2 != it1.second().nend(); it1.second().incr( it2 ) )
			{
				RotDir::niterator it3 = rset[de.res2][de.res1][ it2.first ].find( de.r1 );
				if ( it3 != rset[de.res2][de.res1][ it2.first ].nend() )
				{
					rset[de.res2][de.res1][ it2.first ][ de.r1 ].clear();
					if ( !rset[de.res2][de.res1][ it2.first ].nsize() )
					{
						rset[de.res2][de.res1][ it2.first ].clear();
					}
				}
			}
			rset[de.res1][de.res2].erase( it1 );
		}
		if ( !rset[de.res1][de.res2].nsize() )
		{
			rset[de.res1][de.res2].clear();
			rset[de.res2][de.res1].clear();
		}
		conf[de.res1][de.r1].clear();
	}
	return deadend.size();
}
				

bool find_single( RotTree* tree, RotSet& rset, int node, 
	vector<int>& passed, 
	set<int>& s_passed )
{
	int point = passed.size();
	passed.push_back( node );
	s_passed.insert( node );
	bool rv = false;
	RotRes& rres = rset[node];
	set<int> un;
	for ( RotRes::niterator it = rres.nbegin(); it != rres.nend(); rres.incr( it ) )
	{
		if ( s_passed.find( it.first ) != s_passed.end() ) continue;
		rv = true;
		RotTree *nn = new RotTree;
		if ( !find_single( nn, rset, it.first, passed, s_passed ) )
		{
			nn->res = node;
			nn->res1 = -1;
			for ( int vc = point; vc < passed.size(); vc++ ) 
			{
				nn->core.insert( passed[vc] );
				//if ( vc > point ) s_passed.erase( s_passed.find( passed[vc] ) );
			}
			//un.insert( nn->core.begin(), nn->core.end() );
			tree->child.push_back( nn );
			passed.erase( passed.begin() + point + 1, passed.end() );
		}
		else
		{
			tree->child.insert( tree->child.end(), nn->child.begin(), nn->child.end() );
			nn->child.clear();
			delete nn;
		}
	}
	return rv;
}

/*
bool find_pair( RotTree* tree, RotSet& rset, int node, int pnode, 
	vector<int>& passed, 
	set<int>& s_passed,
	set<int>& core )
{
	int point = passed.size();
	passed.push_back( node );
	s_passed.insert( node );
	bool rv = false;
	RotRes& rres = rset[node];
	set<int> un;
	for ( RotRes::iterator it = rres.begin(); it != rres.end(); it++ )
	{
		if ( s_passed.find( it->first ) != s_passed.end() 
		|| core.find( it->first ) == core.end() 
		|| it->first == pnode ) continue;
		rv = true;
		RotTree *nn = new RotTree;
		if ( !find_pair( nn, rset, it->first, pnode, passed, s_passed, core ) )
		{
			for ( int vc = point; vc < passed.size(); vc++ ) 
			{
				nn->core.insert( passed[vc] );
				//if ( vc > point ) s_passed.erase( s_passed.find( passed[vc] ) );
			}
			nn->core.insert( pnode );
			nn->res = node;
			nn->res1 = pnode;
			
			//un.insert( nn->core.begin(), nn->core.end() );
			tree->child.push_back( nn );
			passed.erase( passed.begin() + point + 1, passed.end() );
		}
		else
		{
			tree->child.insert( tree->child.end(), nn->child.begin(), nn->child.end() );
			nn->child.clear();
			delete nn;
		}
	}
	return rv;
}
*/

void assign_tree( RotTree *child, RotTree *src, bool rec = true )
{
	if ( rec ) for ( int tc = 0; tc < child->child.size(); tc++ )
	{
		assign_tree( child->child[tc], src );
	}
	for ( int tc = 0; tc < src->child.size(); )
	{
		set<int> intersect;
		insert_iterator< set<int> > ii( intersect, intersect.begin() );
		set_intersection( child->core.begin(), child->core.end(),
			src->child[tc]->core.begin(), src->child[tc]->core.end(), ii );
		if ( intersect.size() )
		{
			child->child.push_back( src->child[tc] );
			src->child.erase( src->child.begin() + tc );
		}
		else tc++;
	}
}

/*
void enum_pair( RotTree **tree, RotSet& rset )
{
	RotTree *child;
	for ( set<int>::iterator it = (*tree)->core.begin(); it != (*tree)->core.end(); it++ )
	{
		set<int>::iterator it1 = it;
		it1++;
		if ( it1 == (*tree)->core.end() ) break;
		vector<int> passed;
		set<int> s_passed;
		child = new RotTree;
		find_pair( child, rset, *it1, *it, passed, s_passed, (*tree)->core );
		if ( passed.size() >= (*tree)->core.size() - 1 || passed.size() <= 1 )
		{
			delete child;
			continue;
		}
		for ( int vc = 0; vc < passed.size(); vc++ ) child->core.insert( passed[vc] );
		child->core.insert( *it );
		child->res = *it1;
		child->res1 = *it;
		assign_tree( child, *tree );
		for ( int lc = 0; lc < (*tree)->child.size(); lc++ )
		{
			child->child.push_back( (*tree)->child[lc] );
		}
		(*tree)->child.clear();
		delete *tree;
		*tree = child;
		break;
	}
	for ( int tc = 0; tc < (*tree)->child.size(); tc++ )
	{
		enum_pair( &((*tree)->child[tc]), rset );
	}
}
*/

void enum_group( RotTree *tree, RotSet& rset, RedundantSet& rdset )
{
	for ( int tc = 0; tc < tree->child.size(); tc++ )
	{
		enum_group( tree->child[tc], rset, rdset );
	}
	//map< int, RotTree* > stack;
	set<int> core = tree->core;
	RotConf empty_rc;
	/*
	if ( tree->res1 != -1 )
	{
		if ( rset[ tree->res ].find( tree->res1 ) == rset[ tree->res ].end() )
		{
			rset[ tree->res ][ tree->res1 ] = empty_rc;
		}
	}
	*/
	do
	{
		int best = rset.size() + 1;
		int point;
		for ( set<int>::iterator it = core.begin(); it != core.end(); it++ )
		{
			int csize = 0;
			RotRes rres = rset[*it];
			for ( RotRes::niterator it1 = rres.nbegin(); it1 != rres.nend(); rres.incr( it1 ) )
			{
				if ( core.find( it1.first ) == core.end() ) continue;
				csize++;
			}
			if ( csize < best )
			{
				best = csize;
				point = *it;
			}
		}
		if ( best >= core.size() - 1 )
		{
			/*
			for ( map< int, RotTree* >::iterator s_it = stack.begin(); s_it != stack.end(); s_it++ )
			{
				tree->child.push_back( s_it->second );
			}
			*/
			tree->core = core;
			break;
		}
		RotTree *child = new RotTree;
		child->core.insert( point );
		RotRes& rres = rset[point];
		for ( RotRes::niterator it = rres.nbegin(); it != rres.nend(); rres.incr( it ) )
		{
			RotSet::iterator res_it = rset.find( it.first );
			if ( res_it == rset.end() ) continue;
			if ( core.find( it.first ) == core.end() ) continue;
			child->core.insert( it.first );
			/*
			map< int, RotTree* >::iterator s_it = stack.find( it->first );
			if ( s_it != stack.end() ) 
			{
				child->child.push_back( s_it->second );
				stack.erase( s_it );
			}
			*/
			/*
			for ( int tc = 0; tc < tree->child.size(); )
			{
				if ( it->first == tree->child[tc]->res )
				{
					child->child.push_back( tree->child[tc] );
					tree->child.erase( tree->child.begin() + tc );
				}
				else tc++;
			}
			*/
			for ( RotRes::niterator it1 = rres.nbegin(); it1 != rres.nend(); rres.incr( it1 ) )
			{
				if ( it1 == it ) continue;
				if ( res_it->second.find( it1.first ) == res_it->second.nend() ) 
				{
					rdset.insert( Redundant( point, it1.first ) );
					rdset.insert( Redundant( it1.first, point ) );
					res_it->second[ it1.first ] = empty_rc;
				}
			}
		}
		//stack[point] = child;
		assign_tree( child, tree, false );
		tree->child.push_back( child );
		core.erase( core.find( point ) );
	}
	while ( 1 );
}

void split_group( RotTree *tree, RotSet& rset )
{
	bool fflag;
	if ( tree->core.size() > 2 ) do
	{
		fflag = false;
		for ( set<int>::iterator it = tree->core.begin(); it != tree->core.end(); it++ )
		{
			for ( set<int>::iterator it1 = tree->core.begin(); it1 != tree->core.end(); it1++ )
			{
				if ( it1 == it ) continue;
				if ( rset[*it].find(*it1) != rset[*it].nend() && rset[*it][*it1].nsize() > 0 ) continue;
				RotTree *child = new RotTree;
				child->core = tree->core;
				//rdset.erase( it1 );
				for ( int cc = 0; cc < tree->child.size(); )
				{
					if ( tree->child[cc]->core.find( *it ) != tree->child[cc]->core.end() )
					{
						child->child.push_back( tree->child[cc] );
						tree->child.erase( tree->child.begin() + cc );
					}
					else cc++;
				}
				tree->child.push_back( child );
				fflag = true;
				tree->core.erase( it );
				child->core.erase( child->core.find( *it1 ) );
				break;
			}
			if ( fflag ) break;
		}
	}
	while ( fflag );
	for ( int tc = 0; tc < tree->child.size(); tc++ )
	{
		split_group( tree->child[tc], rset );
	}
}

void find_union( RotTree *tree,	set<int>& un )
{
	un.insert( tree->core.begin(), tree->core.end() );
	for ( int cc = 0; cc < tree->child.size(); cc++ )
	{
		find_union( tree->child[cc], un );
	}
}

int find_maxsize( RotTree *tree )
{
	int rv = tree->core.size();
	for ( int cc = 0; cc < tree->child.size(); cc++ )
	{
		int ms = find_maxsize( tree->child[cc] );
		if ( ms > rv ) rv = ms;
	}
	return rv;
}

int BuildRotTree( vector< RotTree* >& trees, RotSet rset )
{
	set<int> processed;
	int maxsize = 0;
	do
	{
		for ( RotSet::iterator it = rset.begin(); it != rset.end(); it++ )
		{
			if ( processed.find( it->first ) != processed.end() ) continue;
			RotTree *nn = new RotTree;
			vector<int> passed;
			set<int> s_passed;
			find_single( nn, rset, it->first, passed, s_passed );
			for ( int vc = 0; vc < passed.size(); vc++ ) nn->core.insert( passed[vc] );
			nn->res = it->first;
			nn->res1 = -1;
			trees.push_back( nn );
			find_union( nn, processed );
			int ms = find_maxsize( nn );
			if ( maxsize < ms ) maxsize = ms;
		}
	}
	while ( processed.size() < rset.size() );
	//printf( "maxsize %d\n", maxsize );
	/*
	maxsize = 0;
	for ( int tc = 0; tc < trees.size(); tc++ )
	{
		enum_pair( &(trees[tc]), rset );
		int ms = find_maxsize( trees[tc] );
		if ( maxsize < ms ) maxsize = ms;
	}
	//printf( "newmaxsize %d\n", maxsize );
	*/
	maxsize = 0;
	RedundantSet rdset;
	for ( int tc = 0; tc < trees.size(); tc++ )
	{
		enum_group( trees[tc], rset, rdset );
		int ms = find_maxsize( trees[tc] );
		if ( maxsize < ms ) maxsize = ms;
	}
	//printf( "newnewmaxsize %d rdset %d\n", maxsize, rdset.size() );

	maxsize = 0;
	for ( int tc = 0; tc < trees.size(); tc++ )
	{
		split_group( trees[tc], rset );
		int ms = find_maxsize( trees[tc] );
		if ( maxsize < ms ) maxsize = ms;
	}
	//printf( "newnewnewmaxsize %d rdset %d\n", maxsize, rdset.size() );
	return maxsize;
}
			
	


/*
void BuildRotTree( vector< RotTree* >& trees, RotSet& rset )
{
	RotConf empty_rc;
	map< int, RotTree* > stack;
	int lastres;
	do
	{
		RotSet::iterator best;
		int bsize = rset.size() + 1;
		for ( RotSet::iterator it = rset.begin(); it != rset.end(); it++ )
		{
			if ( it->second.size() < bsize )
			{
				bsize = it->second.size();
				best = it;
			}
		}
		RotTree *nn = new RotTree;
		lastres = nn->res = best->first;
		nn->rres = best->second;
		for ( RotRes::iterator it = nn->rres.begin(); it != nn->rres.end(); it++ )
		{
			RotSet::iterator res_it = rset.find( it->first );
			if ( res_it == rset.end() ) continue;
			map< int, RotTree* >::iterator s_it = stack.find( it->first );
			if ( s_it != stack.end() ) 
			{
				nn->child.push_back( s_it->second );
				stack.erase( s_it );
			}
			for ( RotRes::iterator it1 = nn->rres.begin(); it1 != nn->rres.end(); it1++ )
			{
				if ( it1 == it ) continue;
				if ( res_it->second.find( it1->first ) == res_it->second.end() ) res_it->second[ it1->first ] = empty_rc;
			}
			res_it->second.erase( res_it->second.find( nn->res ) );
		}
		stack[ lastres ] = nn;
		rset.erase( best );
	}
	while ( rset.size() );
	for ( map< int, RotTree* >::iterator s_it = stack.begin(); s_it != stack.end(); s_it++ ) trees.push_back( s_it->second );
}
*/

struct MBScore
{
	set<int> cnodes;
	double *score;
	MBScore() { score = 0; }
	~MBScore() { delete [] score; }
};	

static void add_conf( double *conf, VInt& sizes, VInt& sel, double value )
{
	VInt offsets;
	offsets.resize( sizes.size() + 1 );
	offsets.back() = 1;
	for ( int cc = sizes.size() - 1; cc >= 0; cc-- ) offsets[cc] = sizes[cc] * offsets[ cc + 1 ];
	vector<double*> ptr;
	ptr.resize( sel.size() + 1 );
	ptr[0] = conf;
	for ( int pc = 1; pc < sel.size() + 1; pc++ ) 
	{
		if ( sel[ pc - 1 ] == -1 ) ptr[pc] = ptr[ pc - 1 ];
		else ptr[pc] = ptr[ pc - 1 ] + sel[ pc - 1 ] * offsets[pc];
	}
	do
	{
		*( ptr.back() ) += value;
		int cc = ptr.size() - 1;
		while ( cc > 0 ) 
		{
			if ( sel[ cc - 1 ] == -1 ) 
			{
				ptr[cc] += offsets[cc];
				for ( int pc = cc + 1; pc < sel.size() + 1; pc++ ) 
				{
					if ( sel[ pc - 1 ] == -1 ) ptr[pc] = ptr[ pc - 1 ];
					else ptr[pc] = ptr[ pc - 1 ] + sel[ pc - 1 ] * offsets[pc];
				}
				if ( ptr[cc] >= ptr[ cc - 1 ] + offsets[ cc - 1 ] )
				{
					cc--;
					continue;
				}
				break;
			}
			else cc--;
		}
		if ( cc <= 0 ) break;
		
	}
	while ( true );
}

static void add_conf( double *conf, VInt& sizes, VInt& sel, double* score )
{
	VInt coffsets;
	coffsets.insert( coffsets.begin(), 1 );
	VInt csizes;
	for ( int cc = sizes.size() - 1; cc >= 0; cc-- ) 
	{
		if ( sel[cc] == -1 ) continue;
		coffsets.insert( coffsets.begin(), sizes[cc] * coffsets.front() );
		csizes.insert( csizes.begin(), sizes[cc] );
	}
	vector<int> points;
	points.resize( csizes.size() );
	for ( int pc = 0; pc < csizes.size(); pc++ ) points[pc] = 0;
	points.back() -= 1;
	do
	{
		int cc = points.size() - 1;
		while ( cc >= 0 ) 
		{
			points[cc]++;
			if ( points[cc] >= csizes[cc] )
			{
				for ( int pc = cc; pc < points.size(); pc++ ) points[pc] = 0;
				cc--;
				continue;
			}
			break;
		}
		if ( cc < 0 ) break;
		double *ptr = score;
		for ( int pc = 0; pc < points.size(); pc++ )
		{
			ptr += points[pc] * coffsets[pc+1];
		}
		VInt nsel;
		nsel.resize( sizes.size() );
		cc = 0;
		for ( int pc = 0; pc < sizes.size(); pc++ ) if ( sel[pc] == -1 ) nsel[pc] = -1; else nsel[pc] = points[cc++];
		add_conf( conf, sizes, nsel, *ptr );
	}
	while ( true );
}

static double *find_maximums( double *conf, VInt& sizes, VInt& sel, ConfSet& cset )
{
	VInt offsets;
	offsets.resize( sizes.size() + 1 );
	offsets.back() = 1;
	for ( int cc = sizes.size() - 1; cc >= 0; cc-- ) offsets[cc] = sizes[cc] * offsets[ cc + 1 ];
	VInt coffsets;
	coffsets.insert( coffsets.begin(), 1 );
	for ( int cc = sizes.size() - 1; cc >= 0; cc-- ) 
	{
		if ( sel[cc] == -1 ) continue;
		coffsets.insert( coffsets.begin(), sizes[cc] * coffsets.front() );
	}
	vector<int> points;
	points.resize( sel.size() );
	for ( int pc = 0; pc < sel.size(); pc++ ) points[pc] = 0;
	points.back() -= 1;
	double *rv = new double[ coffsets[0] ];
	if ( !rv ) return 0;
	const double MaxSCEnergy = 1000000;
	for ( int cc = 0; cc < coffsets[0]; cc++ ) rv[cc] = MaxSCEnergy;
	do
	{
		int cc = points.size() - 1;
		while ( cc >= 0 ) 
		{
			points[cc]++;
			if ( points[cc] >= sizes[cc] )
			{
				for ( int pc = cc; pc < points.size(); pc++ ) points[pc] = 0;
				cc--;
				continue;
			}
			break;
		}
		if ( cc < 0 ) break;
		double *p1 = conf;
		double *p2 = rv;
		int pcc = 1;
		for ( int pc = 0; pc < points.size(); pc++ )
		{
			p1 += points[pc] * offsets[pc+1];
			if ( sel[pc] != -1 )
			{
				p2 += points[pc] * coffsets[ pcc++ ];
			}
		}
		if ( *p1 >= *p2 ) continue;
		VInt left;
		VInt right;
		for ( int pc = 0; pc < points.size(); pc++ )
		{
			if ( sel[pc] == -1 )
			{
				right.push_back( points[pc] );
			}
			else
			{
				left.push_back( points[pc] );
			}
		}
		if ( left.size() == 0 ) left.push_back( -1 );
		cset[left] = right;
		*p2 = *p1;
	}
	while ( true );
	return rv;
}
	
bool PathUp( RotChain& chain, RotTree *tree, MBScore& rscore, RotSet& rset, RotConf& rconf, double& energy )
{
	set<int> curNodes = tree->core;
	map<int,int> curMap;
	int rc = 0;
	for ( set<int>::iterator it = curNodes.begin(); it != curNodes.end(); it++, rc++ )
	{
		curMap[ *it ] = rc;
	}
	set<int> intersect;
	insert_iterator< set<int> > ii( intersect, intersect.begin() );
	set_intersection( rscore.cnodes.begin(), rscore.cnodes.end(), curNodes.begin(), curNodes.end(), ii );
	rscore.cnodes = intersect;
	vector< int > sizes;
	sizes.resize( curNodes.size() );
	for ( set<int>::iterator it = curNodes.begin(); it != curNodes.end(); it++ )
	{
		//sizes[ curMap[ *it ] ] = chain.residue[ *it ].r.size(); 
		sizes[ curMap[ *it ] ] = rconf[*it].nsize(); 
	}
	int msize = 1;
	for ( int cc = 0; cc < sizes.size(); cc++ ) 
	{
	    msize *= sizes[cc];
	    if ( msize <= 0 || msize >= maxDynSize ) 
		{
			return false;
		}
	}
	double *conf = new double[ msize ];
	if ( !conf ) 
	{
		return false;
	}
	memset( conf, 0, msize * sizeof( double ) );
	vector< vector<int> > rindex;
	for ( set<int>::iterator it = curNodes.begin(); it != curNodes.end(); it++ )
	//for ( RotRes::iterator it = tree->rres.begin(); it != tree->rres.end(); it++ )
	{
		VInt sel;
		sel.resize( sizes.size() );
		for ( int cc = 0; cc < sel.size(); cc++ ) sel[cc] = -1;
		vector<int> crindex;
		crindex.resize( chain.residue[ *it ].r.size() );
		int rc = 0;
		for ( RotDir::niterator r_it = rconf[*it].nbegin(); r_it != rconf[*it].nend(); rconf[*it].incr( r_it ), rc++ )
		{
			sel[ curMap[ *it ] ] = rc;
			add_conf( conf, sizes, sel, r_it.second().v );
			crindex[ r_it.first ] = rc;
		}
		rindex.push_back( crindex );
		if ( rset.find( *it ) == rset.end() ) continue;
		for ( set<int>::iterator it1 = curNodes.begin(); it1 != it; it1++ )
		{
			if ( rset[*it].find( *it1 ) == rset[*it].nend() ) continue;
			RotConf& crconf = rset[*it][*it1];
			for ( int cc = 0; cc < sel.size(); cc++ ) sel[cc] = -1;
			for ( RotConf::niterator c_it = crconf.nbegin(); c_it != crconf.nend(); crconf.incr( c_it ) )
			{
				sel[ curMap[ *it ] ] = crindex[ c_it.first ];
				for ( RotDir::niterator r_it = c_it.second().nbegin(); r_it != c_it.second().nend(); c_it.second().incr( r_it ) )
				{
					sel[ curMap[ *it1 ] ] = rindex[ curMap[ *it1 ] ][ r_it.first ];
					add_conf( conf, sizes, sel, r_it.second().v );
				}
			}
		}
	}
	vector< MBScore > score;
	score.resize( tree->child.size() );
	for ( int cc = 0; cc < tree->child.size(); cc++ )
	{
		score[cc].cnodes = curNodes;
		if ( !PathUp( chain, tree->child[cc], score[cc], rset, rconf, energy ) )
		{
			delete [] conf;
			return false;
		}
		if ( !score[cc].cnodes.size() ) continue;
		VInt sel;
		sel.resize( sizes.size() );
		for ( int cc1 = 0; cc1 < sel.size(); cc1++ ) sel[cc1] = -1;
		for ( set<int>::iterator it = score[cc].cnodes.begin(); it != score[cc].cnodes.end(); it++ )
		{
			sel[ curMap[ *it ] ] = 1;
		}
		add_conf( conf, sizes, sel, score[cc].score );
	}
	VInt sel;
	sel.resize( sizes.size() );
	for ( int cc = 0; cc < sel.size(); cc++ ) sel[cc] = -1;
	for ( set<int>::iterator it = rscore.cnodes.begin(); it != rscore.cnodes.end(); it++ ) sel[ curMap[ *it ] ] = 1;
	rscore.score = find_maximums( conf, sizes, sel, tree->maximums );
	if ( !rscore.score )
	{
		delete [] conf;
		return false;
	}
	energy = conf[0];
	delete [] conf;
	return true;
}

struct MDScore
{
	set<int> cnodes;
	VInt conf;
};	

void PathDown( Chain& chain, RotChain& rchain, RotTree *tree, RotConf& rconf, MDScore& rscore )
{
	set<int> curNodes = tree->core;
	map<int,int> curMap;
	int rc = 0;
	for ( set<int>::iterator it = curNodes.begin(); it != curNodes.end(); it++, rc++ )
	{
		curMap[ *it ] = rc;
	}
	set<int> intersect;
	insert_iterator< set<int> > ii( intersect, intersect.begin() );
	set_intersection( rscore.cnodes.begin(), rscore.cnodes.end(), curNodes.begin(), curNodes.end(), ii );
	MDScore nscore;
	nscore.cnodes = curNodes;
	VInt conf = rscore.conf;
	int vc = 0;
	for ( set<int>::iterator it = rscore.cnodes.begin(); it != rscore.cnodes.end(); it++ ) 
	{
		if ( intersect.find( *it ) == intersect.end() ) conf.erase( conf.begin() + vc );
		else vc++;
	}
	VInt nconf;
	if ( conf.size() ) nconf = tree->maximums[conf];
	else nconf = tree->maximums.begin()->second;
	vc = 0;
	rc = 0;
	for ( set<int>::iterator it = curNodes.begin(); it != curNodes.end(); it++, rc++ ) 
	{
		if ( intersect.find( *it ) != intersect.end() ) 
		{
			nconf.insert( nconf.begin() + rc, conf[vc] );
//			printf( "%d\n", conf[vc] );
			vc++;
		}
		else
		{
			RotDir::niterator r_it = rconf[*it].nbegin();
			for ( int rcc = 0; rcc < nconf[rc]; rcc++ ) rconf[*it].incr( r_it );
			chain.residue[ *it ] = rchain.residue[ *it ].r[ r_it.first ];
		}
	}
	nscore.conf = nconf;
	for ( int cc = 0; cc < tree->child.size(); cc++ )
	{
		PathDown( chain, rchain, tree->child[cc], rconf, nscore );
	}
}

bool PredictSide( Chain& chain, RotChain& rchain )
{
	RotSet rset;
	RotConf rconf;
	double energy = 0;
	if ( !CalcRotSetSeq( rchain, rset, rconf ) ) return false;
	//if ( !CalcRotSetOmp( rchain, rset, rconf ) ) return false;
	//if ( !CalcRotSetAnn( rchain, rset, rconf ) ) return false;
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
		if ( rchain.residue[rc].r.size() == 1 )
		{
			chain.residue[rc] = rchain.residue[rc].r[0];
			continue;
		}
		if ( rset.find( rc ) == rset.end() )
		{
			double emin = 100000;
			int best = -1;
			for ( RotDir::niterator it = rconf[rc].nbegin(); it != rconf[rc].nend(); it++ )
			{
				if ( it.second().v < emin )
				{
					emin = it.second().v;
					best = it.first;
				}
			}
			energy += emin;
			chain.residue[rc] = rchain.residue[rc].r[best];
		}
	}
	for ( int dc = 0; dc < 3; dc++ )
	{
		int nd = DeadEndElimination( rset, rconf );
		//printf ( "de %d\n", nd );
		if ( nd == 0 ) break;
	}
	
	vector< RotTree* > trees;
	int maxsize = BuildRotTree( trees, rset );
	int tc;
	for ( tc = 0; tc < trees.size(); tc++ )
	{
		MBScore s1;
		double cenergy;
		if ( !PathUp( rchain, trees[tc], s1, rset, rconf, cenergy ) ) 
		{
			printf( "PathUp failed\n" );
			break;
		}
		energy += cenergy;
		MDScore s2;
		s2.conf.push_back( -1 );
		PathDown( chain, rchain, trees[tc], rconf, s2 );
		delete trees[tc];
	}
	if ( tc < trees.size() ) 
	{
	    for ( ; tc < trees.size(); tc++ )
	    {
		delete trees[tc];
	    }
	    return false;
	}
	//printf( "%g\n", energy );
	//if ( energy > 100 * rchain.residue.size() ) return false;
	//printf( "energy %g parameter %g\n", energy );
	return true;
}

