
#ifdef BSINGLE

#include "common.h"
#include "counters.h"

struct Unit
{
	SS ss;
	Space sp;
	CScheme scheme;
	double distance;
	double angle;
};

const double ssFactor = 0;
const double SurfaceFactor = 0;
const double CysBridgeTerm = 0;

#endif

#include "chain.h"

const double MinVdw = -100;
const double HPRatio = -0.5;
const double HFactor = 30000;

#ifndef CMP
static const char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

static void print_atom( FILE *ofile, int ac, const char *aname, const char *aatype, int rc, int lc, char chain, const char *name, Vector coord )
{
	fprintf( ofile, 
		"ATOM   %4d  %-3.3s %-3.3s %c %3d     %7.3f %7.3f %7.3f  1.00 00.00 \n",
//		"ATOM   %4d  %-3.3s %-3.3s %c %3d     %7.3f %7.3f %7.3f  1.00 00.00      %4.4s%4d\n",
		ac, aname, aatype, chain, rc, coord.x, coord.y, coord.z );
}
#else
const double ssFactor = 0;
const double CysBridgeTerm = 0;
#endif

void BuildBeta( Chain& chain, Unit& u, int beg, const char *seq )
{
	const double last = 0.8;
	const double pi = 3.14159;
	for ( int rc = 0; rc < u.ss.size; rc++ )
	{
		chain.residue.resize( chain.residue.size() + 1 );
		Residue& r = chain.residue.back();
		r.name1 = seq[rc];
		strcpy( r.name3, a_name[ r.name1 - 'A' ] );
		r.number = beg + rc;
		Vector rcenter = u.sp.beg + ( u.sp.end - u.sp.beg ) * ( double( rc ) / ( u.ss.size - 1 ) );
		Vector or_ort = u.sp.orientation * ( ( 1. - 2 * ( rc % 2 ) ) / u.sp.orientation.norm() );
		Vector dir0_ort = ( u.sp.end - u.sp.beg );
		dir0_ort = !dir0_ort;
		Vector o0_ort = or_ort & dir0_ort;
		double tangle = -0.01 * pi;
		Vector dir_ort = dir0_ort * cos( tangle ) + o0_ort * sin( tangle );
		Vector o_ort = o0_ort * cos( tangle ) - dir0_ort * sin( tangle );
		Vector ca = rcenter + or_ort * last;
		Vector n_dir = ( or_ort * ( - cos( pi/3 ) ) - dir_ort * sin( pi/3 ) ) * sin( pi/3 ) - o_ort * cos( pi/3 );
		Vector c_dir = ( or_ort * ( - cos( pi/3 ) ) + dir_ort * sin( pi/3 ) ) * sin( pi/3 ) - o_ort * cos( pi/3 );
		Vector n = ca + n_dir * 1.45;
		Vector c = ca + c_dir * 1.51;
		Vector o = c - o_ort * 1.23;
		r.atom.resize( 4 );
		strcpy( r.atom[0].name, "N" );
		r.atom[0].coord = n;
		strcpy( r.atom[1].name, "CA" );
		r.atom[1].coord = ca;
		strcpy( r.atom[2].name, "C" );
		r.atom[2].coord = c;
		strcpy( r.atom[3].name, "O" );
		r.atom[3].coord = o;
	}
}
		
void BuildAlpha( Chain& chain, Unit& u, double last_angle, int beg, const char *seq, bool last_flag = true )
{
	const double last = 2.6;
	const double pi = 3.14159;
	const double a4 = 1.52;
	const double a5 = 1.61;
	double approx_angle = ( u.ss.type == 1 ) ? a4 : a5;
	double approx_last = ( u.ss.size - 1 ) * approx_angle;
	double nt = round ( ( approx_last - last_angle ) / 2 / pi  );
	double an = last_flag ? ( last_angle + nt * 2 * pi ) / ( u.ss.size - 1 ) : approx_angle;
	double d_an = asin( ( u.sp.end - u.sp.beg ).norm() / ( last * an * ( u.ss.size - 1 ) ) );
	for ( int rc = 0; rc < u.ss.size; rc++ )
	{
		chain.residue.resize( chain.residue.size() + 1 );
		Residue& r = chain.residue.back();
		r.name1 = seq[rc];
		strcpy( r.name3, a_name[ r.name1 - 'A' ] );
		r.number = beg + rc;
		Vector rcenter = u.sp.beg + ( u.sp.end - u.sp.beg ) * ( double( rc ) / ( u.ss.size - 1 ) );
		Vector dir0_ort = ( u.sp.end - u.sp.beg );
		dir0_ort = !dir0_ort;
		Vector or0_ort = u.sp.orientation;
		or0_ort = !or0_ort;
		Vector or1_ort = or0_ort * cos( an * rc ) + ( dir0_ort & or0_ort ) * sin( an * rc );
		Vector dir1_ort = dir0_ort * sin( d_an ) + ( dir0_ort & or1_ort ) * cos( d_an );
		Vector o0_ort = dir1_ort & or1_ort;
		Vector or_ort = or1_ort * cos( 54 * pi / 180 ) + 
			( dir1_ort * sin( 0.59 ) + o0_ort * cos( 0.59 ) ) * sin( 54 * pi / 180 );
		Vector dir_ort = ( or1_ort & or_ort );
		dir_ort = !dir_ort;
		Vector o_ort = dir_ort & or_ort;
		Vector ca = rcenter + or1_ort * last;
		Vector n_dir = ( or_ort * ( -cos( pi/3 ) ) - dir_ort * sin( pi/3 ) ) * sin( pi/3 ) + o_ort * cos( pi/3 );
		Vector c_dir = ( or_ort * ( -cos( pi/3 ) ) + dir_ort * sin( pi/3 ) ) * sin( pi/3 ) + o_ort * cos( pi/3 );
		Vector n = ca + n_dir * 1.45;
		Vector c = ca + c_dir * 1.51;
		Vector o = c + dir0_ort * 1.23;
		r.atom.resize( 4 );
		strcpy( r.atom[0].name, "N" );
		r.atom[0].coord = n;
		strcpy( r.atom[1].name, "CA" );
		r.atom[1].coord = ca;
		strcpy( r.atom[2].name, "C" );
		r.atom[2].coord = c;
		strcpy( r.atom[3].name, "O" );
		r.atom[3].coord = o;
		//strcpy( r.atom[4].name, "CB" );
		//r.atom[4].coord = ca + or_ort * 1.5;
	}
}

void SaveChain( Chain& chain, const char *fname )
{
	FILE *ofile = fopen( fname, "wt" );
	int acc = 1;
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		for ( int ac = 0; ac < chain.residue[rc].atom.size(); ac++ )
		{
			Atom& a = chain.residue[rc].atom[ac];
			print_atom( ofile, acc++, a.name, chain.residue[rc].name3, chain.residue[rc].number, 0, ' ', 0, a.coord );
		}
	}
	fclose( ofile );
}

const int pdbLineSize = 100;

struct pdbLine
{
	char s[ pdbLineSize ];

	char *lineType() { return s; }
	char *atomNumber() { return s + 7; }
	char *atomType() { return s + 13; }
	char *chainName() { return s + 21; }
	char *aaNumber() { return s + 23; }
	char *aaName() { return s + 17; }
	char *x() { return s + 31; }
	char *y() { return s + 39; }
	char *z() { return s + 47; }
};

void LoadChain( Chain& chain, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	pdbLine line;
	while( ifile && fgets( line.s, pdbLineSize, ifile ) )
	{
		if ( strncmp( line.lineType(), "ATOM", 4 ) ) continue;
		if ( !chain.residue.size() || chain.residue.back().number != atoi( line.aaNumber() ) )
		{
			chain.residue.resize( chain.residue.size() + 1 );
			strncpy( chain.residue.back().name3, line.aaName(), 3 );
			chain.residue.back().name3[3] = 0;
			for ( int lc = 0; lc < 26; lc++ ) if ( strncmp( line.aaName(), a_name[lc], 3 ) == 0 ) chain.residue.back().name1 = lc + 'A';
			chain.residue.back().number = atoi( line.aaNumber() );
		}
		Atom a;
		memset( a.name, 0, sizeof( a.name ) );
		strncpy( a.name, line.atomType(), strcspn( line.atomType(), " " ) );
		if ( strcmp( a.name, "OXT" ) == 0 ) strcpy( a.name, "O" );
		a.coord = Vector( atof( line.x() ), atof( line.y() ), atof( line.z() ) );
		chain.residue.back().atom.push_back( a );
	}
	if ( ifile ) fclose( ifile );
}
		
#include "ff.cpp"

double ChainVDWEnergy( Chain& chain )
{
	double rv = 0;
	for ( int rc1 = 0; rc1 < chain.residue.size(); rc1++ )
	{
		Residue& r1 = chain.residue[rc1];
		FFAA *aa1 = ffaa + r1.name1 - 'A';;
		//for ( aa1 = ffaa; aa1 < ffaa + 20 && strcmp( aa1->name3, r1.name3 ); aa1++ );
		for ( int rc2 = 0; rc2 < rc1; rc2++ )
		{
			Residue& r2 = chain.residue[rc2];
			FFAA *aa2 = ffaa + r2.name1 - 'A';;
			//for ( aa2 = ffaa; aa2 < ffaa + 20 && strcmp( aa2->name3, r2.name3 ); aa2++ );
			for ( int ac1 = 0; ac1 < r1.atom.size(); ac1++ )
			{
				Atom& a1 = r1.atom[ac1];
				FFAtom *at1;
				for ( at1 = aa1->atom; at1->name && strcmp( at1->name, a1.name ); at1++ );
				if ( !at1->name ) { printf( "can't find %d %d\n", rc1, ac1 ); continue; }
				if ( strcmp( ffield[ at1->number ].name, at1->type ) ) { printf( "mismatch %d %d\n", rc1, ac1 ); continue; }
				for ( int ac2 = 0; ac2 < r2.atom.size(); ac2++ )
				{
					Atom& a2 = r2.atom[ac2];
					if ( rc1 == rc2 + 1 && ac1 == aN && ac2 == aC ) continue;
					FFAtom *at2;
					for ( at2 = aa2->atom; at2->name && strcmp( at2->name, a2.name ); at2++ );
					if ( !at2->name ) { printf( "%d %d\n", rc2, ac2 ); continue; }
					double dist = ( a1.coord - a2.coord ).norm();
					if ( dist > 10 ) continue;
					dist /= 10;
					FFLJ& lj = ffield[ at1->number ].pot[ at2->number ];
					double en = lj.c6 * pow( dist, -6 ) - lj.c12 * pow( dist, -12 );
					en /= 4200;
					rv += en;
				}
			}
		}
	}
	return rv;
}

#include "radii.h"
extern "C" {
#include "CalcAccSurf.h"
}


#define RN              1.65
#define RCA             1.87
#define RC              1.76
#define RO              1.4
#define RSIDEATOM       1.8
#define RWATER          1.4

static int radius( char name1, const char *aname, double& rv )
{
	FFAA *aa1 = ffaa + name1 - 'A';
	FFAtom *at1;
	for ( at1 = aa1->atom; at1->name && strcmp( at1->name, aname ); at1++ );
	const char *name = at1->type;
	if ( name[0] == 'C' ) 
	{
		rv = RSIDEATOM + RWATER;
		return 1;
	}
	else if ( name[0] == 'S' )
	{
		rv = RSIDEATOM + RWATER;
		return 1;
	}
	else if ( ( name1 == 'K' && strcmp( at1->name, "NZ" ) == 0 ) 
		|| ( name1 == 'R' && ( strncmp( at1->name, "NH", 2 ) == 0 || strcmp( at1->name, "NE" ) == 0 ) ) ) 
	{
		rv = RN + RWATER;
		return 1;
	}
	else if ( name[0] == 'O' )
	{
		rv = RO + RWATER;
		return 0;
	}
	else if ( name[0] == 'N' )
	{
		rv = RN + RWATER;
		return 0;
	}
	return -1;
}



#define DMAX 15.

double calc_surface( CAS *cas, Chain& chain, int nr, double& cysEn, int cbeg = 0, int cend = -1  )
{
	if ( cend == -1 ) cend = chain.residue.size();
	Residue& r1 = chain.residue[nr];
	double rv = 0;
	for ( int a1 = 0; a1 < r1.atom.size(); a1++ )
	{
		Atom &at1 = r1.atom[a1];
		double rad;
		int type = radius( r1.name1, at1.name, rad );
		double hpfactor = ( type == 1 ) ? 1 : - HPRatio;
		if ( type == -1 ) continue; 
		bool contact = false;
	    CASResetAtoms( cas );
	    CASSetCenterAtom( cas, at1.coord.x, at1.coord.y, at1.coord.z, rad );
		for ( int rc = cbeg; rc < cend; rc++ )
		{
			if ( rc == nr ) continue;
			Residue& r2 = chain.residue[rc];
			if ( false && rc > 0 && chain.residue[rc].number != chain.residue[rc-1].number + 1 )
			{
				Vector center = ( chain.residue[rc].atom[1].coord 
					+ chain.residue[rc-1].atom[1].coord ) * 0.5;
				Vector dir = center - chain.residue[rc].atom[1].coord;
				double rad = dir.norm() - 3.;
				if ( rad > 0 )
				{
					double dist = ( center - at1.coord ).norm();
					CASAddNeigbourAtom( cas, center.x, center.y, center.z, 
						rad, dist * dist );
				}
			}
			if ( ( r2.atom[0].coord - at1.coord ).norm() > 10 ) continue;
			for ( int a2 = 0; a2 < r2.atom.size(); a2++ )
			{
				Atom &at2 = r2.atom[a2];
				double rad2;
				if ( radius( r2.name1, at2.name, rad2 ) == -1 ) continue;
				double dist = ( at2.coord - at1.coord ).norm();
				if ( dist < rad + rad2 )
				{
					CASAddNeigbourAtom( cas, at2.coord.x, at2.coord.y, at2.coord.z, rad2, dist * dist );
				}
				if ( dist < 4.5 && at1.name[0] == 'S' && at2.name[0] == 'S' && r1.name1 == 'C' && r2.name1 == 'C' && rc < nr )
					cysEn += CysBridgeTerm;
				
			}
		}
		//double res = ( rad * rad * 4 * 3.14159 - CASSurface( cas ) ) * ( 2 * type - 1 );
		double res = CASSurface( cas ) * hpfactor;
		rv += res;
	}
	//rv -= 200;
	//printf( "%s %g\n", r1.name3, rv );
	return rv;
}

double HydrEnergy( Chain& chain, double& cysEn )
{
	double rv = 0;
    CAS *cas= CASCreate(1/*ORDER*/);
    	cysEn = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		rv += calc_surface( cas, chain, rc, cysEn );
	}
	CASDelete( cas );
	return rv;
}


typedef float real;
typedef int integer;
typedef short ftnlen;

extern "C" {
integer s_cmp(char *a0, char *b0, ftnlen la, ftnlen lb)
{
register unsigned char *a, *aend, *b, *bend;
a = (unsigned char *)a0;
b = (unsigned char *)b0;
aend = a + la;
bend = b + lb;

if(la <= lb)
	{
	while(a < aend)
		if(*a != *b)
			return( *a - *b );
		else
			{ ++a; ++b; }

	while(b < bend)
		if(*b != ' ')
			return( ' ' - *b );
		else	++b;
	}

else
	{
	while(b < bend)
		if(*a == *b)
			{ ++a; ++b; }
		else
			return( *a - *b );
	while(a < aend)
		if(*a != ' ')
			return(*a - ' ');
		else	++a;
	}
return(0);
}
/*
int gfortran_compare_string( ftnlen la, const char *a0,  ftnlen lb, const char *b0)
{
register unsigned char *a, *aend, *b, *bend;
a = (unsigned char *)a0;
b = (unsigned char *)b0;
aend = a + la;
bend = b + lb;

if(la <= lb)
	{
	while(a < aend)
		if(*a != *b)
			return( *a - *b );
		else
			{ ++a; ++b; }

	while(b < bend)
		if(*b != ' ')
			return( ' ' - *b );
		else	++b;
	}

else
	{
	while(b < bend)
		if(*a == *b)
			{ ++a; ++b; }
		else
			return( *a - *b );
	while(a < aend)
		if(*a != ' ')
			return(*a - ' ');
		else	++a;
	}
return(0);
}
*/
}


extern "C" integer tinkerside_( char resname[3], real *chi, integer *n0, real *coord, integer *n );

void BuildSide( Residue& rs, Residue& r, Vector cprev, double *cchi )
{
	rs = r;
	real chi[4];
	integer n0 = 40, n;
	real coord[120];
	coord[0] = cprev.x;
	coord[1] = cprev.y;
	coord[2] = cprev.z;
	char resname[3];
	memcpy( resname, r.name3, 3 );
	for ( int ac = 1; ac < 4; ac++ )
	{
		coord[ ac * 3 ] = r.atom[ ac - 1 ].coord.x;
		coord[ ac * 3 + 1 ] = r.atom[ ac - 1 ].coord.y;
		coord[ ac * 3 + 2 ] = r.atom[ ac - 1 ].coord.z;
	}
	for ( int cc = 0; cc < 4; cc++ ) chi[cc] = cchi[cc];
	tinkerside_( resname, chi, &n0, coord, &n );
	FFAA *aa = ffaa + r.name1 - 'A';
	//for ( aa = ffaa; aa < ffaa + 20 && strcmp( aa->name3, r.name3 ); aa++ );
	for ( int ac = 4; ac < n - 1; ac++ )
	{
		if ( !( aa->atom[ ac ].name ) ) break;
		rs.atom.resize( ac + 1 );
		rs.atom[ ac ].coord.x = coord[ ac * 3 ];
		rs.atom[ ac ].coord.y = coord[ ac * 3 + 1 ];
		rs.atom[ ac ].coord.z = coord[ ac * 3 + 2 ];
		strcpy( rs.atom[ ac ].name, aa->atom[ ac ].name );
	}
}

#include "rotamersbb.cpp"

void BuildSide( RotChain& rchain, Chain& chain )
{
	int ssconv[7] = { 0, 1, 1, 1, 1, 2 };
	double dummy[4] = {0};
	rchain.residue.resize( chain.residue.size() );
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Vector cprev;
		if ( rc > 0 && chain.residue[rc].number == chain.residue[rc-1].number + 1 )
			cprev = chain.residue[rc-1].atom[2].coord;
		else
		{
			Vector dir = chain.residue[rc].atom[0].coord - chain.residue[rc].atom[1].coord;
			dir = !dir;
			Vector cdir = chain.residue[rc].atom[1].coord - chain.residue[rc].atom[2].coord;
			Vector ort = cdir - dir * ( cdir * dir );
			ort = !ort;
			cprev = chain.residue[rc].atom[0].coord + dir * 1.41 * 0.5 + ort * 1.41 * 0.866;
		}
			
		int ord = chain.residue[rc].name1 - 'A';
		int type = ssconv[ chain.residue[rc].sstype ];
		if ( numRotamers[ type ][ ord ] == 0 )
		{
			rchain.residue[rc].r.resize( 1 );
			BuildSide( rchain.residue[rc].r[0], chain.residue[rc], cprev, dummy );
			rchain.residue[rc].r[0].rotamer = 0;
			rchain.residue[rc].r[0].freq = 1;
		}
		else if ( rotamerFrequences[type][ord][0] == 0 )
		{
			rchain.residue[rc].r.resize( 1 );
			BuildSide( rchain.residue[rc].r[0], chain.residue[rc], cprev, &( rotamers[type][ord][0][0] ) );
			rchain.residue[rc].r[0].rotamer = 0;
			rchain.residue[rc].r[0].freq = 1;
		}
		else
		{ 
			int rtc = 0;
			for ( int tc = 0; tc < numRotamers[type][ord]; tc++ )
			{
				if ( rotamerFrequences[type][ord][tc] == 0 ) continue;
				rchain.residue[rc].r.resize( rtc + 1 );
				BuildSide( rchain.residue[rc].r[rtc], chain.residue[rc], cprev, 
					&( rotamers[type][ord][tc][0] ) );
				rchain.residue[rc].r[rtc].rotamer = tc;
				rchain.residue[rc].r[rtc].freq = rotamerFrequences[type][ord][tc];
				rtc++;
			}
		}
		rchain.residue[rc].surface = 0;
	}
}

void BuildSideWithH( Residue& rs, Residue& r, Vector cprev, double *cchi )
{
	rs = r;
	rs.atom.erase( rs.atom.begin() + 4, rs.atom.end() );
	real chi[4];
	integer n0 = 40, n;
	real coord[120];
	coord[0] = cprev.x;
	coord[1] = cprev.y;
	coord[2] = cprev.z;
	char resname[3];
	memcpy( resname, r.name3, 3 );
	if ( strncmp( resname, "HIS", 3 ) == 0 ) resname[2] = 'E';
	for ( int ac = 1; ac < 4; ac++ )
	{
		coord[ ac * 3 ] = r.atom[ ac - 1 ].coord.x;
		coord[ ac * 3 + 1 ] = r.atom[ ac - 1 ].coord.y;
		coord[ ac * 3 + 2 ] = r.atom[ ac - 1 ].coord.z;
	}
	for ( int cc = 0; cc < 4; cc++ ) chi[cc] = cchi[cc];
	tinkerside_( resname, chi, &n0, coord, &n );
	FFAA *aa = ffaa + r.name1 - 'A';
	//for ( aa = ffaa; aa < ffaa + 20 && strcmp( aa->name3, r.name3 ); aa++ );
	for ( int ac = 4; ac < n - 1; ac++ )
	{
		rs.atom.resize( ac + 1 );
		rs.atom[ ac ].coord.x = coord[ ac * 3 ];
		rs.atom[ ac ].coord.y = coord[ ac * 3 + 1 ];
		rs.atom[ ac ].coord.z = coord[ ac * 3 + 2 ];
		if ( ( aa->atom[ ac ].name ) )	strcpy( rs.atom[ ac ].name, aa->atom[ ac ].name );
		else strcpy( rs.atom[ac].name, "H" );
	}
}
			
void BuildSideWithH( Chain& nchain, Chain& chain )
{
	int ssconv[7] = { 0, 1, 1, 1, 1, 2 };
	double dummy[4] = {0};
	nchain.residue.resize( chain.residue.size() );
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Vector cprev;
		if ( rc > 0 && chain.residue[rc].number == chain.residue[rc-1].number + 1 )
			cprev = chain.residue[rc-1].atom[2].coord;
		else
		{
			Vector dir = chain.residue[rc].atom[0].coord - chain.residue[rc].atom[1].coord;
			dir = !dir;
			Vector cdir = chain.residue[rc].atom[1].coord - chain.residue[rc].atom[2].coord;
			Vector ort = cdir - dir * ( cdir * dir );
			ort = !ort;
			cprev = chain.residue[rc].atom[0].coord + dir * 1.41 * 0.5 + ort * 1.41 * 0.866;
		}
			
		int ord = chain.residue[rc].name1 - 'A';
		int type = ssconv[ chain.residue[rc].sstype ];
		if ( numRotamers[ type ][ ord ] == 0 )
		{
			BuildSideWithH( nchain.residue[rc], chain.residue[rc], cprev, dummy );
		}
		else
		{ 
			BuildSideWithH( nchain.residue[rc], chain.residue[rc], cprev, 
				&( rotamers[type][ord][ chain.residue[rc].rotamer ][0] ) );
		}
	}
}

double calc_surface( Residue& r1, Residue& r2 )
{
	double rv = 0;
	for ( int a1 = 0; a1 < r1.atom.size(); a1++ )
	{
		Atom &at1 = r1.atom[a1];
		double rad;
		int type = radius( r1.name1, at1.name, rad );
		if ( type == -1 ) continue; 
		bool contact = false;
		double hpfactor = ( type == 1 ) ? 1 : - HPRatio;
	   // CASResetAtoms( cas );
	    //CASSetCenterAtom( cas, at1.coord.x, at1.coord.y, at1.coord.z, rad );
		for ( int a2 = 0; a2 < r2.atom.size(); a2++ )
		{
			Atom &at2 = r2.atom[a2];
			double rad2;
			int type2 = radius( r2.name1, at2.name, rad2 );
			if ( type2 == -1 ) continue;
			double dist = ( at2.coord - at1.coord ).norm();
			if ( dist < rad + rad2 )
			{
				rv += rad * rad * 2 * 3.14159 
					* ( 1. + ( rad2 * rad2 - dist * dist - rad * rad ) / ( 2 * dist * rad ) )
					* hpfactor;
				//CASAddNeigbourAtom( cas, at2.coord.x, at2.coord.y, at2.coord.z, rad2, dist * dist );
				
			}
			if ( r1.name1 == 'C' && r2.name1 == 'C' 
				&& at1.name[0] == 'S' && at2.name[0] == 'S' && dist < rad + rad2 )
			{
				rv += HFactor * ssFactor / 2;
			}
		}
		//double res = ( rad * rad * 4 * 3.14159 - CASSurface( cas ) ) * ( type );
		//rv += res;
	}
	//rv -= 100;
	//printf( "%s %g\n", r1.name3, rv );
	return rv;
}

#include "power.cpp"

double calc_vdw( Residue& r1, Residue& r2, int b1, int e1, int b2, int e2 )
{
	double rv = 0;
	//if ( r1.name1 < 'A' || r1.name1 > 'Z' || r2.name1 < 'A' || r2.name1 > 'Z' )
	//{
	//	printf( "res - error\n" );
	//	exit( 1 );
	//}
	//if ( e1 > r1.atom.size() || b1 < 0 || e2 > r2.atom.size() || b2 < 0 )
	//{
	//	printf( "bounds - error\n" );
	//	exit( 1 );
	//}
	//printf( "step 1\n" );
	FFAA *aa1 = ffaa + r1.name1 - 'A';;
	//for ( aa1 = ffaa; aa1 < ffaa + 20 && strcmp( aa1->name3, r1.name3 ); aa1++ );
	FFAA *aa2 = ffaa + r2.name1 - 'A';
	//for ( aa2 = ffaa; aa2 < ffaa + 20 && strcmp( aa2->name3, r2.name3 ); aa2++ );
	//printf( "step 2\n" );
	for ( int ac1 = b1; ac1 < e1; ac1++ )
	{
		Atom& a1 = r1.atom[ac1];
		
		FFAtom *at1 = aa1->atom + ac1;
		//if ( !at1->name || at1->number >= 14 || at1->number < 0 ) 
		//{
		//	printf( "atom: %c %d\n", r1.name1, ac1 );
		//	exit( 1 );
		//}
		//for ( at1 = aa1->atom; at1->name && strcmp( at1->name, a1.name ); at1++ );
		//if ( !at1->name ) { printf( "can't find %d %d\n", rc1, ac1 ); continue; }
		//if ( strcmp( ffield[ at1->number ].name, at1->type ) ) { printf( "mismatch %d %d\n", rc1, ac1 ); continue; }
		//printf( "step 3\n" );
		for ( int ac2 = b2; ac2 < e2; ac2++ )
		{
			Atom& a2 = r2.atom[ac2];
			if ( r1.number == r2.number + 1 && ac1 == aN && ac2 == aC ) continue;
			FFAtom *at2 = aa2->atom + ac2;
			//if ( !at2->name || at2->number >= 14 || at2->number < 0 ) 
			//{
			//	printf( "atom2: %c %d\n", r2.name1, ac2 );
			//	exit( 1 );
			//}
			//printf( "step 4\n" );
			//for ( at2 = aa2->atom; at2->name && strcmp( at2->name, a2.name ); at2++ );
			//if ( !at2->name ) { printf( "%d %d\n", rc2, ac2 ); continue; }
			double sqdist;
			double d2 = a1.coord.x - a2.coord.x; sqdist = d2 * d2;
			d2 = a1.coord.y - a2.coord.y; sqdist += d2 * d2;
			d2 = a1.coord.z - a2.coord.z; sqdist += d2 * d2;
			int dindex = int( sqdist * 10 );
			if ( dindex < 0 || dindex >= 360 ) continue;
			FFLJ& lj = ffield[ at1->number ].pot[ at2->number ];
			//printf( "step 5 %d %d %d\n", dindex, at1->number, at2->number );
			double en = lj.c6 * power3[ dindex ] - lj.c12 * power6[ dindex ];
			//printf( "step 6\n" );
			if ( en < -1e9 ) return en / 4200;
			rv += en;
		}
	}
	return rv / 4200;
}

#include "surface.cpp"

double MaxPairEnergy( RotChain& rchain )
{
	double rv = 0;
	for ( int rc1 = 0; rc1 < rchain.residue.size(); rc1++ )
	{
		for ( int rc2 = 0; rc2 < rc1; rc2++ )
		{
			if ( ( rchain.residue[rc1].r[0].atom[0].coord - rchain.residue[rc2].r[0].atom[0].coord ).norm() > 12 ) continue;
			double maxpe = MinVdw;
			int tb1 = -1;
			int tb2 = -1;
			double e1 = calc_vdw( rchain.residue[rc1].r[0], rchain.residue[rc2].r[0], 0, 4, 0, 4 );
			if ( e1 < MinVdw ) return -100;
			int size1 = rchain.residue[rc1].r[0].atom.size();
			int size2 = rchain.residue[rc2].r[0].atom.size();
			for ( int tc1 = 0; tc1 < rchain.residue[rc1].r.size(); tc1++ )
			{
				double e2 = e1 + calc_vdw( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[0], 4, size1, 0, 4 );
				if ( e2 < MinVdw ) 
				{
					rchain.residue[rc1].r.erase( rchain.residue[rc1].r.begin() + tc1 );
					tc1--;
					continue;
				}
				double maxre = MinVdw - 1;
				for ( int tc2 = 0; tc2 < rchain.residue[rc2].r.size(); tc2++ )
				{
					double en = e2 + calc_vdw( rchain.residue[rc1].r[tc1], rchain.residue[rc2].r[tc2], 4, size1, 4, size2 );
					if ( en > maxpe ) 
					{
						maxpe = en;
						tb1 = tc1;
						tb2 = tc2;
					}
					if ( en > maxre )
					{
						maxre = en;
					}
				}
				if ( maxre < MinVdw )
				{
					rchain.residue[rc1].r.erase( rchain.residue[rc1].r.begin() + tc1 );
					tc1--;
					continue;
				}
			}
			if ( tb1 == -1 ) return -100;
			double s1, s2;
			rchain.residue[rc1].surface += ( s1 = calc_surface( rchain.residue[rc1].r[tb1], rchain.residue[rc2].r[tb2] ) );
			rchain.residue[rc2].surface += ( s2 = calc_surface( rchain.residue[rc2].r[tb2], rchain.residue[rc1].r[tb1] ) );
		}
	}
	for ( int rc = 0; rc < rchain.residue.size(); rc++ )
	{
		rv += rchain.residue[rc].surface 
		    -  averageSurface[ min( int( rchain.residue.size() / SizeStep ), MaxSizeCount - 1 ) ]
		    [ rchain.residue[rc].r[0].name1 - 'A' ];
	}
	return rv / HFactor;
}

//#include "scatd-nv.cpp"

bool PredictSide( Chain& chain, RotChain& rchain );

#ifndef BSINGLE
#ifndef CMP

static void build_vector( Vector& v, const Space& sp, RelVector rv )
{
	Vector dir = sp.end - sp.beg;
	dir = !dir;
	Vector point = sp.beg + dir * rv.dist;
	Vector ori = sp.orientation;
	ori = !ori;
	Vector ori1 = dir & ori;
	v = point + ori * rv.last * cos( rv.angle ) + ori1 * rv.last * sin( rv.angle );
}

void BuildByScheme( Chain& chain, const Unit& u, int beg, const char *seq )
{
	const double last = 0.8;
	const double pi = 3.14159;
	for ( int rc = 0; rc < u.ss.size; rc++ )
	{
		chain.residue.resize( chain.residue.size() + 1 );
		Residue& r = chain.residue.back();
		r.name1 = seq[rc];
		strcpy( r.name3, a_name[ r.name1 - 'A' ] );
		r.number = beg + rc;
		r.sstype = u.ss.type;
		r.atom.resize( 4 );
		RelVector rv = u.scheme.bb[rc].atom[0];
		strcpy( r.atom[0].name, "N" );
		build_vector( r.atom[0].coord, u.sp, u.scheme.bb[rc].atom[0] );
		strcpy( r.atom[1].name, "CA" );
		build_vector( r.atom[1].coord, u.sp, u.scheme.bb[rc].atom[1] );
		strcpy( r.atom[2].name, "C" );
		build_vector( r.atom[2].coord, u.sp, u.scheme.bb[rc].atom[2] );
		strcpy( r.atom[3].name, "O" );
		build_vector( r.atom[3].coord, u.sp, u.scheme.bb[rc].atom[3] );
		for ( int ac = 0; ac < 4; ac++ )
		{
			Vector v = r.atom[ac].coord;
			double n = v.norm();
			if ( !( n == n ) )
			{
				printf( "bad vector %d %d %d %d\n", rc, ac, u.ss.size, u.scheme.bb[rc].count );
			}
		}
	}
}

void AmberEnergy( Chain& chain, double& Epol, double& Eelt );

double PosEnergyBias( Chain& chain, Input& i )
{
	double rv = 0;
	for ( int c1 = 0; c1 < chain.residue.size(); c1++ )
	{
		if ( i.selPos.find( chain.residue[ c1 ].number ) == i.selPos.end() ) continue;
		Vector v1 = chain.residue[ c1 ].atom[1].coord;
		for ( int c2 = 0; c2 < c1; c2++ )
		{
			if ( i.selPos.find( chain.residue[ c2 ].number ) == i.selPos.end() ) continue;
			Vector v2 = chain.residue[ c1 ].atom[1].coord;
			if ( (v1 - v2).norm() < 7 ) rv += PosBiasTerm;
		}
	}
	return rv;
}


double RealEnergy( vector<Unit>& unit, vector<int>& beg, Energies& en, Input& i )
{
	/*
	int ctypes[] = { 2, 1, 1, 1, 1, 1, 1, 1 };
	double ssen = 0;
	
	Chain chain;
	for ( int uc = 0; uc < unit.size(); uc++ )
	{
		const char *seq = i.seq.data() + beg[uc];
		if ( unit[uc].ss.type == 0 ) BuildBeta( chain, unit[uc], beg[uc], seq );
		else BuildAlpha( chain, unit[uc], i.last[ unit[uc].ss ].angle, beg[uc], seq );
		if ( i.sspred.size() && unit[uc].ss.size <= MaxLoopLength ) 
			ssen += SSPredFactor * i.sspred[ beg[uc] ].p[ unit[uc].ss.size - 1 ][ ctypes[ unit[uc].ss.type ] ];
	}
	*/
	Chain chain;
	for ( int uc = 0; uc < unit.size(); uc++ )
	{
		const char *seq = i.seq.data() + beg[uc];
		//if ( unit[uc].ss.type == 0 ) BuildBeta( chain, unit[uc], beg[uc], seq );
		//else BuildAlpha( chain, unit[uc], i.last[ unit[uc].ss ].angle, beg[uc], seq );
		BuildByScheme( chain, unit[uc], beg[uc], seq );
	}
	RotChain rchain;
	BuildSide( rchain, chain );
	Chain nchain;
	nchain.residue.resize( chain.residue.size() );
	if ( !PredictSide( nchain, rchain ) ) return - 100;
	Chain hchain;
	BuildSideWithH( hchain, nchain );
	double Epol, Eelt;
	AmberEnergy( hchain, Epol, Eelt );
	double res = -HydrEnergy( nchain, en.cys );
	en.posbias = PosEnergyBias( chain, i );
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		res += averageSurface[ min( 
		int( ( chain.residue.back().number - chain.residue[0].number ) / SizeStep ), MaxSizeCount - 1 ) ]
//		int( ( chain.residue.size() ) / SizeStep ), MaxSizeCount - 1 ) ]
		[ chain.residue[rc].name1 - 'A' ];
	}
	
	/*
	SaveChain( chain, "tmp1.pdb" );
	system( "./scatd -i tmp1.pdb -o tmp2.pdb >/dev/null" );
	chain.residue.clear();
	LoadChain( chain, "tmp2.pdb" );
	double vdw = ChainVDWEnergy( chain ) / 2000;
	double he = HydrEnergy( chain ) / 3000;
	printf( "vdw %g hydr %g\n", vdw, he );
	return vdw + he;
	*/
	//double rv = MaxPairEnergy( rchain ) + ssen;
	//printf ( "%g %g\n", rv, ssen );
	en.surf = res * SurfaceFactor;
	en.elt = - AmberEnergyFactor * Eelt;
	en.pol = - AmberEnergyFactor * Epol;
	
	return en.surf + en.cys + en.elt + en.pol + en.posbias;//0.0015;//0.002;
}

int SaveModel( const vector<Unit>& unit, const vector<int>& beg, Input& i, const char *fname )
{
	Chain chain;
	for ( int uc = 0; uc < unit.size(); uc++ )
	{
		const char *seq = i.seq.data() + beg[uc];
		BuildByScheme( chain, unit[uc], beg[uc], seq );
	}
	RotChain rchain;
	BuildSide( rchain, chain );
	Chain nchain;
	nchain.residue.resize( chain.residue.size() );
	if ( !PredictSide( nchain, rchain ) ) return 0;
	SaveChain( nchain, fname );
	return 1;
}
#endif

#else
#ifndef LPW4

int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	Chain chain;
	LoadChain( chain, argv[1] );
	/*
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		chain.residue[rc].atom.erase( chain.residue[rc].atom.begin() + 4, chain.residue[rc].atom.end() );
	}
	RotChain rchain;
	BuildSide( rchain, chain );
	MaxPairEnergy( rchain );
	*/
	/*
	char *coils = new char[ chain.residue.size() ];
	memset( coils, 0, chain.residue.size() );
	FILE *ifile = fopen( argv[2], "rt" );
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() == "COIL" ) 
		{
			for ( int rc = 0; rc < l.GetInt( "SIZE"); rc++ ) coils[ l.GetInt( "FIRST" ) + rc ] = 1;
	    	}
	}	
	while ( 1 );
	fclose( ifile );
	*/
	const int SegmStep = 5;
    CAS *cas= CASCreate(0);
	srand( time( 0 ) );
	int sc = 0;
	do
	{
	    if ( ++sc * SegmStep > 0.7 * chain.residue.size() ) break;
    	    double res[26] = { 0 };
	    int cnt[26] = { 0 };
	    int segmSize = sc * SegmStep;
	    int cbeg = rand() % ( chain.residue.size() - segmSize );
	    double cysEn;
	    for ( int rc = cbeg; rc < cbeg + segmSize; rc++ )
	    {
		//if ( !coils[rc] ) continue;
		//res[ rchain.residue[rc].r[0].name1 - 'A' ] += rchain.residue[rc].surface;
		res[ chain.residue[rc].name1 - 'A' ] += 
			calc_surface( cas, chain, rc, cysEn, cbeg, cbeg + segmSize );
		cnt[ chain.residue[rc].name1 - 'A' ] ++;
	    }
	
	//delete coils;
	    printf( "%3d ", sc );
	    for ( int lc = 0; lc < 26; lc++ )
	    {
		if ( cnt[lc] != 0 ) res[lc] /= cnt[lc];
		printf( "%10.2f", res[lc] );
	    }
	    printf( "\n" );
	}
	while ( 1 ); 
	CASDelete( cas );
	return 0;
}

#endif
#endif
