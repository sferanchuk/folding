typedef vector<double> Scheme;

struct RelVector
{
	double angle;
	double dist;
	double last;
};

struct Backbone
{
	RelVector atom[4];
	int count;
};

struct CScheme 
{ 
	Scheme s[3];
	vector<Backbone> bb;
	void add_rv( int count, RelVector& rv, const RelVector& rv1 )
	{
		if ( count )
		{
			Vector v1 = Vector( rv.last, 0, 0 );
			Vector v2 = Vector( 0, rv.last, 0 );
			Vector pv =  v1 * cos( rv.angle ) + v2 * sin( rv.angle );
			Vector vv1 = Vector( rv1.last, 0, 0 );
			Vector vv2 = Vector( 0, rv1.last, 0 );
			Vector ppv =  vv1 * cos( rv1.angle ) + vv2 * sin( rv1.angle );
			rv.dist = ( rv.dist * count ) / ( count + 1 ) + rv1.dist / ( count + 1 );
			Vector sum = Vector( 0, 0, rv.dist ) + pv * ( double ( count ) / ( count + 1 ) )
							+ ppv * ( 1. / ( count + 1 ) );
			rv.last = ( sum - Vector( 0, 0, sum.z ) ).norm();
			rv.angle = dihedral_angle( Vector( 1, 0, 0 ), Vector( 0, 0, 0 ), 
							Vector( 0, 0, sum.z ), sum );
		}
		else rv = rv1;
	}
	void resize( int size ) 
	{
		bb.resize( size );
		for ( int c = 0; c < 3; c++ ) if ( s[c].size() < size )
		{
			s[c].resize( size );
			for ( int fc = 0; fc < size; fc++ ) 
			{
				s[c][fc] = 0;
				bb[fc].count = 0;
			}
		}
	}
	void add( const CScheme& cs )
	{
		if ( !bb.size() || !bb[0].count ) resize( cs.bb.size() );
		for ( int c = 0; c < 3; c++ )
		{
			for ( int fc = 0; fc < min( s[c].size(), cs.s[c].size() ); fc++ ) s[c][fc] += cs.s[c][fc];
		}
		for ( int fc = 0; fc < min( bb.size(), cs.bb.size() ); fc++ )
		{
			if ( cs.bb[fc].count == 0 ) continue;
			for ( int ac = 0; ac < 4; ac++ )
			{
				add_rv( bb[fc].count, bb[fc].atom[ac], cs.bb[fc].atom[ac] );
			}
			bb[fc].count++;
		}
	}
	void add( const Scheme* cs )
	{
		//resize( s[0].size() );
		for ( int c = 0; c < 3; c++ )
		{
			for ( int fc = 0; fc < min( s[c].size(), cs[c].size() ); fc++ ) s[c][fc] += cs[c][fc];
		}
	}
};
