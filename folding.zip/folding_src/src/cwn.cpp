
#include "common.h"
#include "geom-f.h"
#include "counters.h"

const double MatchLinkRmsd = 3.3;//3.3;
int MinLinkCount = 10;

int tagCnt = 1;

struct Stat
{
	Acc< int > letter;
	Acc< SS > ss;
	Acc< SS > mono;
	Acc< Coil > coil;
		
	PAcc< int, SS > p_ss_letters;
	PAcc< int, SS > p_hydr_letters;

	LastAcc last;
	SchAcc sch;
	SSDetailAcc ssdet;
	LinkAcc link;
	map< SS, LastData, Comparer<SS> > mlast;
};

//------------------------------------------------------------------------------

static int count_mono( Stat& stat, Line& l, double value )
{
	SS ss;
	ss.type = l.GetInt( fType );
	ss.size = l.GetInt( fSize );
	
	return stat.mono.Count( ss, value );
}

static void count_ss_detail( Stat& stat, Line& l, double value )
{
	SSDetail ssd;
	ssd.ss.type = l.GetInt( fType );
	ssd.ss.size = l.GetInt( fSize );
	ssd.order = l.GetInt( fOrder );
	
	stat.ssdet.Count( ssd, l.GetDouble( fAngle ), l.GetDouble( fCenter ), l.GetDouble( fOrientation ), value );
}

static int count_letter( Stat& stat, Line& l, double value )
{
	int rect = l.GetInt( fRecType );
	int letter = l.GetString( fLetter )[ 0 ];
	if ( rect == 0 )
	{
		stat.letter.Count( letter, value );
		return -1;
	}
	SS ss;
	ss.type = l.GetInt( fType );
	ss.size = l.GetInt( fSize );
	if ( rect == 1 ) return stat.p_ss_letters.Count( letter, ss, value );
	if ( rect == 2 ) return stat.p_hydr_letters.Count( letter, ss, value );
}

static int count_ss( Stat& stat, Line& l, double value )
{
	SS ss;
	ss.type = l.GetInt( fType );
	ss.size = l.GetInt( fSize );
	
	int rv = stat.ss.Count( ss, value );
	stat.last.Count( ss, l.GetDouble( fOrientation ), l.GetDouble( fDir ), l.GetDouble( fLast ), value );
	Line ll;
	CScheme s;
	s.resize( ss.size );
	if ( l.GetFirst( ll ) ) do 
	{
		if ( ll.GetType() == rScheme )
		{
			s.s[ ll.GetInt( fType ) ][ ll.GetInt( fOrder ) ] = ll.GetInt( fValue );
		}
		else if ( ll.GetType() == rSSDetail )
		{
			count_ss_detail( stat, ll, value );
		}
		else if ( ll.GetType() == rLetter )
		{
			count_letter( stat, ll, value );
		}
	}
	while ( l.GetNext( ll ) );
	double hbond = l.GetInt( fHBond );
	stat.sch.Count( ss, s, value, hbond  );
	return -1;
}

static void load_orientation( Orientation& o, Line& l )
{
	o.dist = l.GetDouble( fDistance );
	o.angle = l.GetDouble( fAngle );
	o.orient1 = l.GetDouble( fOrient1 );
	o.orient2 = l.GetDouble( fOrient2 );
	o.offset1 = l.GetDouble( fOffset1 );
	o.offset2 = l.GetDouble( fOffset2 );
}

static void load_relvector( RelVector& rv, Line& l )
{
	rv.dist = l.GetDouble( fDistance );
	rv.angle = l.GetDouble( fAngle );
	rv.last = l.GetDouble( fLast );
}

static void load_link_head( Link& link, Line& l )
{
	int size1 = l.GetInt( fNumSS1 );
	link.f.key.ss.resize( size1 );
	link.f.o.resize( size1 );
	link.f.scheme.resize( size1 );
	int size2 = l.GetInt( fNumSS2 );
	link.s.key.ss.resize( size2 );
	link.s.o.resize( size2 );
	link.s.scheme.resize( size2 );
	link.hbond = l.GetInt( fHBond );
	link.weight = l.GetDouble( fValue );
}

static int load_link_detail( Link& link, Line& l )
{
	int rect = l.GetInt( fRecType );
	int order = l.GetInt( fOrder );
	if ( rect == 0 ) 
	{
		link.f.key.ss[order].size = l.GetInt( fSize );
		link.f.key.ss[order].type = l.GetInt( fType );
		link.f.scheme[order].resize( link.f.key.ss[order].size );
		if ( order > 0 ) load_orientation( link.f.o[order], l );
	}
	else
	{
		link.s.key.ss[order].size = l.GetInt( fSize );
		link.s.key.ss[order].type = l.GetInt( fType );
		link.s.scheme[order].resize( link.s.key.ss[order].size );
		if ( order > 0 ) load_orientation( link.s.o[order], l );
		else load_orientation( link.o, l );
	}
	return ( rect == 1 && order == link.s.key.ss.size() - 1 );
}

static int count_coil( Stat& stat, Line& l, double value )
{
	Coil c;
	c.size = 0;//l.GetInt( fSize );
	c.distance = int( l.GetDouble( fDistance ) / 1. );
	stat.coil.Count( c, value );
	return -1;
}

int ProcessInput( Stat& stat, char *iname, int key )//, char *oname )
{
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) return 0;
	//FILE *ofile = fopen( oname, "wt" );
	//if ( !ofile ) return 0;
	double weight = 1;
	do
	{
		Line ll;
		int res = ll.Read( ifile );
		if ( res == eEOF ) break;		
		if ( res != eOK ) return 0;
		Line l;
		if ( ll.GetFirst( l ) ) do 
		{
		if ( l.GetType() == rHeader ) continue;
		else if ( l.GetType() == rMono && key == 0 ) count_mono( stat, l, weight );
		else if ( l.GetType() == rSS && key == 0 ) count_ss( stat, l, weight );
		else if ( l.GetType() == rLink )
		{
			Link link;
			load_link_head( link, l );
			Line l2;
			if ( l.GetFirst( l2 ) ) do
			{
				if ( l2.GetType() == rLinkDetail ) load_link_detail( link, l2 );
				else if ( l2.GetType() == rScheme && l2.GetInt( fRecType ) == 0 ) link.f.scheme[ l2.GetInt( fSS ) ].s[ l2.GetInt( fType ) ][ l2.GetInt( fOrder ) ] = l2.GetInt( fValue );
				else if ( l2.GetType() == rScheme && l2.GetInt( fRecType ) == 1 ) link.s.scheme[ l2.GetInt( fSS ) ].s[ l2.GetInt( fType ) ][ l2.GetInt( fOrder ) ] = l2.GetInt( fValue );
				else if ( l2.GetType() == rBackbone && l2.GetInt( fRecType ) == 0 ) load_relvector( link.f.scheme[ l2.GetInt( fSS ) ].bb[ l2.GetInt( fOrder ) ].atom[ l2.GetInt( fAtom ) ], l2 );
				else if ( l2.GetType() == rBackbone && l2.GetInt( fRecType ) == 1 ) load_relvector( link.s.scheme[ l2.GetInt( fSS ) ].bb[ l2.GetInt( fOrder ) ].atom[ l2.GetInt( fAtom ) ], l2 );
			}
			while ( l.GetNext( l2 ) );
			if ( true || link.f.key.ss[0].size == key ) stat.link.Count( link );
		}
		else if ( l.GetType() == rCoil && key == 0 ) count_coil( stat, l, weight );
		}
		while ( ll.GetNext( l ) );
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

static void save_letters( Stat &stat, FILE *ofile )
{
	Acc<int> lnorm = stat.letter;
	SS ss;
	double value;
	int letter;
	int tag;
	stat.p_ss_letters.Begin();
	while ( stat.p_ss_letters.Next( letter, ss, value, tag ) )
	{
		lnorm.Count( letter, value );
	}
	stat.p_ss_letters.Begin();
	while ( stat.p_ss_letters.Next( letter, ss, value, tag ) )
	{
		Line l( rLetter );
		l.PutInt( fRecType, 1 );
		char let = letter;
		l.PutString( fLetter, string( &let, 1 ) );
		l.PutInt( fSize, ss.size );
		l.PutInt( fType, ss.type );
		double weight = log( value ) - log( lnorm.theMap[ letter ].value );
		l.PutInt( fTag, tag );
		l.PutDouble( fValue, weight + 2. );
		l.Write( ofile );
	}
	stat.p_hydr_letters.Begin();
	while ( stat.p_hydr_letters.Next( letter, ss, value, tag ) )
	{
		Line l( rLetter );
		l.PutInt( fRecType, 2 );
		char let = letter;
		l.PutString( fLetter, string( &let, 1 ) );
		l.PutInt( fSize, ss.size );
		l.PutInt( fType, ss.type );
		l.PutInt( fTag, tag );
		double weight = log( value ) 
			- log( stat.p_ss_letters.GetValue( letter, ss ) ) + 2.;
		l.PutDouble( fValue, weight );
		l.Write( ofile );
	}
}

static void save_mono( Stat &stat, FILE *ofile )
{
	SS ss;
	double value;
	int tag;

	stat.mono.Begin();
	while ( stat.mono.Next( ss, value, tag ) )
	{
		Line l( rMono );
		l.PutInt( fType, ss.type );
		l.PutInt( fSize, ss.size );
		l.PutInt( fTag, tag );
		l.PutDouble( fValue, value );
		l.Write( ofile );
	}
}

static void save_orientation( Line& l, Orientation& o )
{
	l.PutDouble( fDistance, o.dist );
	l.PutDouble( fAngle, o.angle );
	l.PutDouble( fOrient1, o.orient1 );
	l.PutDouble( fOrient2, o.orient2 );
	l.PutDouble( fOffset1, o.offset1 );
	l.PutDouble( fOffset2, o.offset2 );
}

static void save_link( Link& link, FILE *ofile )
{
	Line ll( rLink );
	ll.PutInt( fNumSS1, link.f.key.ss.size() );
	ll.PutInt( fNumSS2, link.s.key.ss.size() );
	//ll.PutInt( fSize, link.f.key.ss[0].size );
	//ll.PutInt( fType, link.f.key.ss[0].type );
	//ll.PutInt( fScheme, link.f.scheme[0] );
	ll.PutInt( fTag, link.tag );
	ll.PutDouble( fHBond, link.hbond );
	ll.PutDouble( fValue, link.weight );
	//ll.Write( ofile );
	for ( int c = 0; c < link.f.key.ss.size(); c++ )
	{
		Line l( rLinkDetail );
		l.PutInt( fRecType, 0 );
		l.PutInt( fOrder, c );
		l.PutInt( fSize, link.f.key.ss[c].size );
		l.PutInt( fType, link.f.key.ss[c].type );
		for ( int cc = 0; cc < link.f.key.ss[c].size; cc++ )
		{
			for ( int tc = 0; tc < 2; tc++ )
			{
				Line l2( rScheme );
				l2.PutInt( fOrder, cc );
				l2.PutInt( fType, tc );
				l2.PutDouble( fValue, link.f.scheme[c].s[tc][cc] );
				l.PutLine( l2 );
			}
			for ( int ac = 0; ac < 4; ac++ )
			{
				Line l2( rBackbone );
				l2.PutInt( fOrder, cc );
				l2.PutInt( fAtom, ac );
				l2.PutDouble( fDistance, link.f.scheme[c].bb[cc].atom[ac].dist );
				l2.PutDouble( fAngle, link.f.scheme[c].bb[cc].atom[ac].angle );
				l2.PutDouble( fLast, link.f.scheme[c].bb[cc].atom[ac].last );
				l.PutLine( l2 );
			}
		}
		if ( c > 0 ) save_orientation( l, link.f.o[c] );
		ll.PutLine( l );
	}
	for ( int c = 0; c < link.s.key.ss.size(); c++ )
	{
		Line l( rLinkDetail );
		l.PutInt( fRecType, 1 );
		l.PutInt( fOrder, c );
		l.PutInt( fSize, link.s.key.ss[c].size );
		l.PutInt( fType, link.s.key.ss[c].type );
		for ( int cc = 0; cc < link.s.key.ss[c].size; cc++ )
		{
			for ( int tc = 0; tc < 2; tc++ )
			{
				Line l2( rScheme );
				l2.PutInt( fOrder, cc );
				l2.PutInt( fType, tc );
				l2.PutDouble( fValue, link.s.scheme[c].s[tc][cc] );
				l.PutLine( l2 );
			}
			for ( int ac = 0; ac < 4; ac++ )
			{
				Line l2( rBackbone );
				l2.PutInt( fOrder, cc );
				l2.PutInt( fAtom, ac );
				l2.PutDouble( fDistance, link.s.scheme[c].bb[cc].atom[ac].dist );
				l2.PutDouble( fAngle, link.s.scheme[c].bb[cc].atom[ac].angle );
				l2.PutDouble( fLast, link.s.scheme[c].bb[cc].atom[ac].last );
				l.PutLine( l2 );
			}
		}
		if ( c > 0 ) save_orientation( l, link.s.o[c] );
		else save_orientation( l, link.o );
		ll.PutLine( l );
	}
	ll.Write( ofile );
}

typedef vector< LinkList::iterator > LinkVector;
typedef map< LinkKey, LinkVector, CompareLinks > LinkGroup;

int clusterize( int size, double *_distances, double threshold, int *centers, int *sizes );

static void add_unit( VVector& v, Space& sp, int pos )
{
	v[ 3 * pos ] = sp.beg;
	v[ 3 * pos + 1 ] = sp.beg + sp.orientation;
	v[ 3 * pos + 2 ] = sp.end;
}

double CompareLinks( Stat &stat, Link& l1, Link& l2 )
{
	int size = ( l1.f.key.ss.size() + l1.s.key.ss.size() ) * 3;
	VVector v1;
	VVector v2;
	v1.resize( size );
	v2.resize( size );
	Space space;
	space.beg = Vector( 0, 0, 0 );
	space.orientation = Vector( 0, -1, 0 ) * stat.mlast[ l1.f.key.ss[0] ].last;
	space.end = space.beg + Vector( 0, 0, 1 ) * stat.mlast[ l1.f.key.ss[0] ].dist;
	add_unit( v1, space, 0 );
	add_unit( v2, space, 0 );
	for ( int c = 1; c < l1.f.key.ss.size(); c++ )
	{
		Space s1;
		unit_position_s( s1, space, l1.f.o[c], stat.mlast[ l1.f.key.ss[c] ] );
		add_unit( v1, s1, c );
		Space s2;
		unit_position_s( s2, space, l2.f.o[c], stat.mlast[ l2.f.key.ss[c] ] );
		add_unit( v2, s2, c );
	}
	Space ss1;
	unit_position_s( ss1, space, l1.o, stat.mlast[ l1.s.key.ss[0] ] );
	add_unit( v1, ss1, l1.f.key.ss.size() );
	Space ss2;
	unit_position_s( ss2, space, l2.o, stat.mlast[ l2.s.key.ss[0] ] );
	add_unit( v2, ss2, l1.f.key.ss.size() );
	for ( int c = 1; c < l1.s.key.ss.size(); c++ )
	{
		Space s1;
		unit_position_s( s1, ss1, l1.s.o[c], stat.mlast[ l1.s.key.ss[c] ] );
		add_unit( v1, s1, c + l1.f.key.ss.size() );
		Space s2;
		unit_position_s( s2, ss2, l2.s.o[c], stat.mlast[ l2.s.key.ss[c] ] );
		add_unit( v2, s2, c + l1.f.key.ss.size() );
	}
	double res = FindRmsd( size, &(v1[0]), &(v2[0]) );
	if ( res < 0.001 ) res = 0.001;
	return res;
}

void MergeLinks( Stat &stat, int key )
{
	LinkAcc::Map::iterator it;
	for ( it = stat.link.mapf.begin(); it != stat.link.mapf.end(); it++ )
	{
		if ( MinLinkCount == 1 && it->first.ss[0].size != key ) continue;
		LinkList::iterator it1;
		LinkGroup lg;
		for ( it1 = it->second.begin(); it1 != it->second.end(); it1++ )
		{
			it1->weight = 1;
			lg[ it1->s.key ].push_back( it1 );
		}
		for ( LinkGroup::iterator it2 = lg.begin(); it2 != lg.end(); it2++ )
		{
			int size = it2->second.size();
			if ( size == 1 ) 
			{
				it->second.erase( it2->second[0] );
				continue;
			}
			double *dist = new double[ size * ( size - 1 ) / 2 ];
			int *centers = new int[ size ];
			int *sizes = new int[ size ];
			bool find = false;
			for ( int c1 = 0; c1 < size; c1++ )
			{
				for ( int c2 = 0; c2 < c1; c2++ )
				{
					dist[ c1 * ( c1 - 1 ) / 2 + c2 ] = CompareLinks( stat, *( it2->second[c2] ), *( it2->second[c1] ) );
				}
			}
			int res = clusterize( size, dist, MatchLinkRmsd, centers, sizes );
			for ( int c = 0; c < size; c++ )
			{
				int rc;
				for ( rc = 0; rc < res; rc++ )
				{
					if ( centers[rc] == c ) break;
				}
				if ( rc == res || sizes[rc] < MinLinkCount ) it->second.erase( it2->second[c] );
				else it2->second[c]->weight = sizes[rc];
			}
			delete dist;
			delete centers;
			delete sizes;
		}
	}
}

static void save_link( Stat &stat, FILE *ofile )
{
	//MergeLinks( stat );
	LinkAcc::Map::iterator it;
	for ( it = stat.link.mapf.begin(); it != stat.link.mapf.end(); it++ )
	{
		LinkList::iterator it1;
		for ( it1 = (*it).second.begin(); it1 != (*it).second.end(); it1++ )
		{
			save_link( *it1, ofile );
		}
	}
}

static void save_coil( Stat &stat, FILE *ofile )
{
	Coil c;
	double value;
	int tag;

	stat.coil.Begin();
	while ( stat.coil.Next( c, value, tag ) )
	{
		Line l( rCoil );
		l.PutInt( fSize, c.size );
		l.PutInt( fDistance, c.distance );
		l.PutInt( fTag, tag );
		l.PutDouble( fValue, value );
		l.Write( ofile );
	}
}

static void save_last( Stat &stat, FILE *ofile )
{
	SS ss;
	LastData ld;
	
	stat.last.Begin();
	while ( stat.last.Next( ss, ld ) )
	{
		Line l( rLast );
		l.PutInt( fType, ss.type );
		l.PutInt( fSize, ss.size );
		l.PutDouble( fDistance, ld.dist );
		l.PutDouble( fAngle, ld.angle );
		l.PutDouble( fLast, ld.last );
		l.PutDouble( fValue, ld.weight );
		l.Write( ofile );
		stat.mlast[ss] = ld;
	}
}

static void save_ss_detail( Stat &stat, FILE *ofile )
{
	SSDetail ssd;
	double dist;
	double angle;
	double last;

	stat.ssdet.Begin();
	while ( stat.ssdet.Next( ssd, angle, dist, last ) )
	{
		Line l( rSSDetail );
		l.PutInt( fType, ssd.ss.type );
		l.PutInt( fSize, ssd.ss.size );
		l.PutInt( fOrder, ssd.order );
		l.PutDouble( fCenter, dist );
		l.PutDouble( fAngle, angle );
		l.PutDouble( fOrientation, last );
		l.Write( ofile );
	}
}

/*
static void save_sch_detail( vector<double> sch, int ref, int type, FILE *ofile )
{
	for ( int c = 0; c < sch.size(); c++ )
	{
		Line l( rSchemeDetail );
		l.PutInt( fRef, ref );
		l.PutInt( fType, type );
		l.PutInt( fOrder, c );
		l.PutDouble( fValue, sch[c] );
		l.Write( ofile );
	}
};

static void save_scheme( Stat &stat, FILE *ofile )
{
	SS ss;
	Space space;
	vector<double> sch1;
	vector<double> sch2;
	int cnt = 0;

	stat.sch.Begin();
	while ( stat.sch.Next( ss, space, sch1, sch2 ) )
	{
		Line l( rScheme );
		l.PutInt( fOrder, cnt );
		l.PutInt( fSS1, ss.type );
		l.PutInt( fSize1, ss.size );
		l.PutInt( fSS2, space.ss.type );
		l.PutInt( fSize2, space.ss.size );
		l.PutInt( fContactType, space.o.ctype );
		l.PutInt( fDistance, space.o.dist );
		l.PutInt( fAngle, space.o.angle );
		l.PutInt( fOrient1, space.o.orient1 );
		l.PutInt( fOrient2, space.o.orient2 );
		l.PutInt( fOffset1, space.o.offset1 );
		l.PutInt( fOffset2, space.o.offset2 );
		l.Write( ofile );
		save_sch_detail( sch1, cnt, 1, ofile );
		save_sch_detail( sch2, cnt, 2, ofile );
		cnt++;
	}
}

*/

static void save_scheme( Stat& stat, FILE *ofile )
{
	SS ss;
	stat.ss.Begin();
	double value;
	int tag;
	while ( stat.ss.Next( ss, value, tag ) )
	{
		CScheme scheme;
		double hbond;
		if ( stat.sch.Find( ss, scheme, hbond ) )
		{
			Line ll( rSS );
			ll.PutInt( fSize, ss.size );
			ll.PutInt( fType, ss.type );
			ll.PutDouble( fHBond, hbond );
			for ( int cc = 0; cc < ss.size; cc++ )
			{
				for ( int tc = 0; tc < 2; tc++ )
				{
					Line l( rScheme );
					l.PutInt( fOrder, cc );
					l.PutInt( fType, tc );
					l.PutDouble( fValue, scheme.s[tc][cc] );
					ll.PutLine( l );
				}
			}
			ll.Write( ofile );
		}
	}
}

int DoCalc( char *ifname, char *ofname )
{
	Stat stat;

	for ( int key = 0; key < 1; key++ )
	{
		if ( !ProcessInput( stat, ifname, key ) ) return 0;
		MergeLinks( stat, key );
		printf( "." );
		fflush( stdout );
	}
	
	FILE *ofile = fopen( ofname, "wt" );
	Line l( rHeader );
	l.PutInt( fTag, tagCnt );
	l.Write( ofile );
	//save_letters( stat, ofile );
	save_scheme( stat, ofile );
	save_mono( stat, ofile );
	save_last( stat, ofile );
	save_link( stat, ofile );
	save_coil( stat, ofile );
	//save_scheme( stat, ofile );
	save_ss_detail( stat, ofile );
	fclose( ofile );
	return 1;
}

int main( int argc, char **argv )
{
	if ( argc < 3 ) return 1;
	if ( argc >= 4 ) MinLinkCount = atoi( argv[3] );
	if ( !DoCalc( argv[1], argv[2] ) ) return 1;
	return 0;
}
