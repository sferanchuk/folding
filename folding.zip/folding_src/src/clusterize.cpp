
#include <stdio.h>
#include <stdlib.h>

typedef struct treenode {
	struct treenode *p[2];
	double d[2];
	int num;
	} TREE;


void free_tree( TREE *top )
{
	if ( top->num < 0 )
	{
		free_tree( top->p[0] );
		free_tree( top->p[1] );
	}
	delete top;
}

TREE *build_cluster_tree( int nseq, double (*dist)( int, int ) ) {
   int l,m,n;
   int lm,mm;
   float **mdis;
   char flag;
   double min,depth;
   TREE **ps;
   TREE *newnode,*sh;

   ps = new TREE*[ nseq ];
   for( l = 0; l < nseq; l++ )
   {
		ps[l] = new TREE;
		ps[l]->num = l;
   }
   mdis = new float*[ nseq ];
   for( l = 0; l < nseq;  l++ )
   {
	  mdis[l] = new float[ l ];
	  for ( m = 0; m < l; m++ ) mdis[l][m] = dist( l, m );
   }

   do {
		flag = 0;
		min = 99999999.;
		lm = -1;
		for( l=1; l<nseq; l++ ) if (ps[l] != NULL) {
			flag=1;
			for(m=0;m<l;m++) if (ps[m] != NULL) {
				if ( mdis[l][m] < min || lm==-1 ) {
					 min = mdis[l][m];
					 lm  = l;
					 mm  = m;
					 };
				};
			};
		if (!flag) break;

		for(n=0;    n<mm  ; n++) if (ps[n] != NULL)	mdis[mm][n] = (mdis[mm][n]+mdis[lm][n])/2;
		for(n=mm+1; n<lm  ; n++) if (ps[n] != NULL) mdis[n][mm] = (mdis[n][mm]+mdis[lm][n])/2;
		for(n=lm+1; n<nseq; n++) if (ps[n] != NULL)	mdis[n][mm] = (mdis[n][mm]+mdis[n][lm])/2;

		newnode = new TREE;
		newnode->num = -1;
		newnode->p[0] = ps[mm];
		depth         = 0;
		sh            = newnode->p[0];
		while ( sh->num < 0 ) {
			depth  += sh->d[0];
			sh      = sh->p[0];
			}
		newnode->d[0] = min-depth;
		//if ( newnode->d[0] < 0.001 ) newnode->d[0] = 0.001;

		newnode->p[1] = ps[lm];
		depth       = 0;
		sh          = newnode->p[1];
		while ( sh->num < 0 ) {
			depth  += sh->d[0];
			sh      = sh->p[0];
			}
		newnode->d[1] = min-depth;
		//if ( newnode->d[1] < 0.001 ) newnode->d[1] = 0.001;
		ps[mm] = newnode;
		ps[lm] = NULL;
		}
   while (1);

   for ( l = 0; l < nseq; l++ ) delete mdis[l];
   delete mdis;
   TREE *result = ps[0];
   delete ps;
   return result;
}

static int nseq;
static int changes;
static int *list[4];

static double (*get_seq_distance)( int n1, int n2 );

char shiftturn ( TREE *top, char d1, char d2 ) {
	TREE *q;
	double dist;

	if (top->num>=0) return(0);
	q = top->p[d1];
	if (q->num>=0) return(0);
	top->p[d1] = q->p[d2];
	dist = q->d[d2];
	q->p[d2] = top->p[!d1];
	q->d[d2] = top->d[0];
	top->d[0] = dist;
	top->p[!d1] = q;
	return(1);
	}

void makelist( TREE *t, int *list, int *c ) {
	if (t->num!=-1) {
		list[*c] = t->num;
		(*c)++;
		}
	else {
		makelist( t->p[0], list, c );
		makelist( t->p[1], list, c );
		}
	}

static int edgetest( TREE *top ) {
	int i,j;
	int n[4] = {0}, k[4], m[4];
	int path[3]={0};
	double sum[3];

	for (i=0;i<2;i++) for (j=0;j<2;j++) makelist(top->p[i]->p[j],list[2*i+j],&(n[2*i+j]));

    for (k[0]=0; k[0]<n[0]; k[0]++ )
    for (k[1]=0; k[1]<n[1]; k[1]++ )
    for (k[2]=0; k[2]<n[2]; k[2]++ )
    for (k[3]=0; k[3]<n[3]; k[3]++ ) {

		for (i=0; i<4; i++) m[i] = list[i][k[i]] ;
		/* 0 = 02,13; 1 = 03,12; 2 = 01,23   */
		/* exchange will be 1<>2 or 1<>3     */

		sum[0] = get_seq_distance( m[0],m[2] ) + get_seq_distance( m[1],m[3] );
		sum[1] = get_seq_distance( m[0],m[3] ) + get_seq_distance( m[1],m[2] );
		sum[2] = get_seq_distance( m[0],m[1] ) + get_seq_distance( m[2],m[3] );

		if ((sum[0]< sum[1])&&(sum[0]< sum[2])) path[0]++;
		if ((sum[1]< sum[2])&&(sum[1]<=sum[0])) path[1]++;
		if ((sum[2]<=sum[1])&&(sum[2]<=sum[0])) path[2]++;

		}  /* 4-th for */

	if ((path[0]> path[1])&&(path[0]> path[2])) return(0);
	if ((path[1]> path[2])&&(path[1]>=path[0])) return(1);
	if ((path[2]>=path[1])&&(path[2]>=path[0])) return(2);
	return(2);
	}

static void changeedge( TREE *top, char i, char k) {
/* i - order of exchange; k - number of fixed edge */

	TREE *q1,*q2,*q3;
	if (i>1) return;

	q1 = top->p[0];
	q2 = top->p[1];
	q3 = q1->p[!k];
	if (k) {
		q1->p[!k] = q2->p[!i];
		q2->p[!i] = q3;
		}
	else {
		q1->p[!k] = q2->p[i];
		q2->p[i] = q3;
		}
    changes = 1;
	}

static void topt_rec( TREE *top, char d2 ) {

	 if (top->p[1]->num>=0) {
		shiftturn(top,0,d2);
		}
	 else {
		changeedge(top,edgetest(top),d2);
		shiftturn(top,1,0);
		topt_rec(top,0);
		shiftturn(top,1,1);
		topt_rec(top,1);
		shiftturn(top,0,d2);
		}
	 return;
	 }
/*  topt_rec */


static void change_topology( TREE *top ) {

	do {
        changes = 0;
		while (shiftturn(top,0,0));
		shiftturn(top,1,0);
		topt_rec(top,0);
		shiftturn(top,1,1);
		topt_rec(top,1);
		}
	while(changes);
}

static TREE *build_simple_tree( void ) {
	int i;
	TREE *top, *p, *pp;

    top = new TREE;
	top->num = 0;

	for ( i=1; i<nseq; i++ ) {
        p  = new TREE;
		p->num = i;
        pp = new TREE;
		pp->num = -1;
		pp->p[0] = top;
		pp->p[1] = p;
        pp->d[0] = pp->d[1] = 0.001;  // 祬?
		top = pp;
		}
	return(top);
	}

/*-------------------------------------------------------*/

void edgedist4( TREE *top ) {
	int i,j;
	int n[4] = {0}, k[4], m[4];
	int count = 0;
	double sum = 0;

	for (i=0;i<2;i++) for (j=0;j<2;j++) makelist(top->p[i]->p[j],list[2*i+j],&(n[2*i+j]));

    for (k[0]=0; k[0]<n[0]; k[0]++ )
    for (k[1]=0; k[1]<n[1]; k[1]++ )
    for (k[2]=0; k[2]<n[2]; k[2]++ )
    for (k[3]=0; k[3]<n[3]; k[3]++ ) {
		count++;
		for (i=0; i<4; i++) m[i] = list[i][k[i]] ;
		sum += - 2*(get_seq_distance(m[1],m[0]) + get_seq_distance(m[3],m[2]))
				  + get_seq_distance(m[2],m[0]) + get_seq_distance(m[3],m[0])
				  + get_seq_distance(m[2],m[1]) + get_seq_distance(m[3],m[1]) ;
		}

	top->d[0] = sum/(4.0*count);
	if (top->d[0]<0.001) top->d[0] = 0.001;
	}


void edgedist3( TREE *top ) {
	/* leaf at top->p[1] branch    */
	int  i;
	int  n[2] = {0,0};
    int  k[2];
    int  m[3];
	int count = 0;
	double sum = 0;
	TREE *p;

	m[2] = top->p[1]->num;
	p = top->p[0];
	makelist(p->p[0],list[0],&n[0]);
	makelist(p->p[1],list[1],&n[1]);

    for (k[0]=0; k[0]<n[0]; k[0]++ )
    for (k[1]=0; k[1]<n[1]; k[1]++ ) {
		count++;
		for (i=0; i<2; i++) m[i]= list[i][k[i]] ;

		sum -= get_seq_distance(m[1],m[0]);
		sum += get_seq_distance(m[2],m[1]);
		sum += get_seq_distance(m[2],m[1]);
		}
	top->d[0] = sum/(2.0*count);
	if (top->d[0] < 0.001) top->d[0] = 0.001;
	}


void tdis_rec( TREE *top, char d2 ) {
	 if (top->p[1]->num>=0) {
		edgedist3(top);
		shiftturn(top,0,d2);
		}
	 else {
		edgedist4(top);
		shiftturn(top,1,0);
		tdis_rec(top,0);
		shiftturn(top,1,1);
		tdis_rec(top,1);
		shiftturn(top,0,d2);
		}
	 return;
	 }


void branch_length( TREE *top ) {
	TREE *q,*tq;
	int cnt = 0;

	/* moving to start */
	tq = top;
	while (shiftturn(tq,0,0)) cnt++;

	/* start */
	shiftturn(tq,1,0);
	tdis_rec(tq,0);
	shiftturn(tq,1,1);
	tdis_rec(tq,1);

	/* computing of root edge */
	q = tq->p[1];
	tq->p[1] = tq->p[0];
	tq->p[0] = q;
	edgedist3(tq);
	top->d[0] = top->d[1] = (top->d[0]*0.5);
	q = tq->p[1];
	tq->p[1] = tq->p[0];
	tq->p[0] = q;
	while (shiftturn(tq,1,0) && cnt--);
	}


TREE *build_tree( int _nseq, double (*dist)( int, int ) )
{
    int i;

    get_seq_distance = dist;
    nseq = _nseq;
    for ( i = 0; i < 4; i++ ) list[i] = new int[nseq];
    TREE *tree = build_cluster_tree( nseq, dist );
    //change_topology( tree );
    //branch_length( tree );

    for ( i = 0; i < 4; i++ ) delete list[i];
    return tree;
}

static int get_leaf_number ( TREE *top ) {
	if (top->num>=0) return(1);
	return(	get_leaf_number( top->p[0] ) +
			get_leaf_number( top->p[1] ) );
	}
	
// 2009


static double *distances;
static int *cluster_centers;
static int *cluster_sizes;
static int *cluster_members;
static int cluster_count;

static double _get_seq_distance( int i1, int i2 )
{
	int j1 = i1;
	int j2 = i2;
	if ( i1 > i2 )
	{
		j1 = i2;
		j2 = i1;
	}
	return distances[ j2 * ( j2 - 1 ) / 2 + j1 ];
}

static int one_cluster( TREE *top, double threshold )
{
	if ( top->num >= 0 ) return 1;
	if ( top->d[0] + top->d[1] > threshold ) return 0;
	return one_cluster( top->p[0], threshold ) && one_cluster( top->p[1], threshold );
}

/*
static double min_distance( TREE *top, int *num )
{
	if ( top->num >= 0 ) 
	{
		*num = top->num;
		return 0;
	}
	int n[2];
	double d1 = min_distance( top->p[0], n ) + top->d[0];
	double d2 = min_distance( top->p[1], n + 1 ) + top->d[1];
	if ( d1 < d2 )
	{
		*num = n[0];
		return d1;
	}
	*num = n[1];
	return d2;
}
*/

static int count_members( TREE *top, int *num )
{
	if ( top->num >= 0 ) 
	{
		*num = top->num;
		return 1;
	}
	int n1 = count_members( top->p[0], num );
	int n2 = count_members( top->p[1], num + n1 );
	return n1 + n2;
}

static int find_center( int *members, int nm )
{
	int best = 0;
	double bestv = 10000000;
	for ( int c1 = 0; c1 < nm; c1++ )
	{
		double res = 0;
		for ( int c2 = 0; c2 < nm; c2++ )
		{
			if ( c1 == c2 ) continue;
			res += get_seq_distance( members[c1], members[c2] );
		}
		if ( res < bestv )
		{
			bestv = res;
			best = c1;
		}
	}
	return members[best];
}
	

static void analyze( TREE *top, double threshold )
{
	if ( one_cluster( top, threshold ) )
	{
		int nm = count_members( top, cluster_members );
		cluster_sizes[ cluster_count ] = get_leaf_number( top );
		cluster_centers[ cluster_count ] = find_center( cluster_members, nm );
		cluster_count++;
		return;
	}
	analyze( top->p[0], threshold );
	analyze( top->p[1], threshold );
}
	
	
int clusterize( int size, double *_distances, double threshold, int *centers, int *sizes )
{
	if ( size == 0 ) return 0;
	if ( size == 1 ) 
	{
		centers[0] = 0;
		sizes[0] = 1;
		return 1;
	}
	if ( size == 2 )
	{
		if ( _distances[0] < threshold )
		{
			centers[0] = 0;
			sizes[0] = 2;
			return 1;
		}
		else
		{
			centers[0] = 0;
			centers[1] = 1;
			sizes[0] = sizes[1] = 1;
			return 2;
		}
	}
	distances = _distances;
	cluster_centers = centers;
	cluster_sizes = sizes;
	cluster_count = 0;
	cluster_members = new int[ size ];
	TREE *tree = build_tree( size, _get_seq_distance );
	analyze( tree, 2. * threshold );
	free_tree( tree );
	delete cluster_members;
	return cluster_count;
}

/*

int main()
{
	const int size = 4;
	//double _distances[ size * (size - 1) / 2 ] = { 0.5, 2., 2.5, 5., 6., 7., };
	double _distances[ size * (size - 1) / 2 ] = { 5, 6, 7, 5., 6., 7., };
	int centers[ size ];
	int sizes[ size ];
	int res = clusterize( size, _distances, 3, centers, sizes );
	for ( int rc = 0; rc < res; rc++ ) printf( "%d %d\n", centers[rc], sizes[rc] );
	return 0;
}

*/