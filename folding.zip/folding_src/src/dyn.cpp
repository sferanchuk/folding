
#include "common.h"
#include <list>
#include <set>

#include "loopp.cpp"


struct SS 
{
	int beg;
	int size;
	int type;
};

struct Space 
{
	Vector beg;
	Vector dir;
	Vector orientation;
};

struct Unit
{
	SS ss;
	Space sp;
	double distance;
	vector<int> scheme;
};

struct Pathway
{
	vector<Unit> unit;
	int node;
	double energy;
};

struct Input
{
	list< Pathway > pathway;
	string seq;
};

int LoadPathway( Input &i, char *fname )
{
	Pathway *p = 0;
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	do
	{
		Line lh;
		int res = lh.Read( ifile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 0;
		if ( lh.GetType() == rPathway )
		{
			Pathway pp;
			pp.node = lh.GetInt( fOrder );
			i.pathway.push_back( pp );
			p = &( i.pathway.back() );
			p->unit.resize( lh.GetInt( fSize ) );
			Line l;
			if ( lh.GetFirst( l ) ) do
			{
				int ord = l.GetInt( fOrder );
				Unit& u = p->unit[ord];
				u.ss.size = l.GetInt( fSize );
				u.scheme.resize( u.ss.size );
				u.ss.type = l.GetInt( fType );
				u.sp.beg = l.GetVector( fCenter );
				u.sp.dir = l.GetVector( fDir );
				u.sp.orientation = l.GetVector( fOrientation );
				u.distance = l.GetDouble( fDistance );
				Line ll;
				if ( l.GetFirst( ll ) ) do
				{
					p->unit[ ll.GetInt( fUnit ) ].scheme[ ll.GetInt( fOrder ) ] = (int)( ll.GetDouble( fScheme ) );
				}
				while ( l.GetNext( ll ) );
			}
			while ( lh.GetNext( l ) );
		}
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

int LoadSeq( Input& i, char *fname )
{	
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	do
	{
		int c = getc( ifile );
		if ( c == EOF ) break;
		if ( c >= 'A' && c <= 'Z' ) i.seq.push_back( c );
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

const double big = 100000;

struct Matrix
{
	int n1;
	int n2;
	double *data;
	Matrix( int N1, int N2 ) 
	{ 
		n1 = N1; 
		n2 = N2; 
		data = new double[ n1 * n2 ];
		memset( data, 0, n1 * n2 * sizeof( double ) );
	}
	~Matrix() { delete data; }
	double& at( int i1, int i2 ) { return data[ i1 * n2 + i2 ]; }
};

static void contact_weights( Matrix& w, Pathway& p, string seq )
{
	for ( int uc = 0; uc < p.unit.size(); uc++ )
	{
		for ( int sc = 0; sc < seq.size(); sc++ )
		{
			if ( sc + p.unit[uc].ss.size > seq.size() )
			{
				w.at( uc, sc ) = -big;
				continue;
			}
			w.at( uc, sc ) = 0;
			for ( int scc = 0; scc < p.unit[uc].ss.size; scc++ )
			{
				int ord = strchr( tom1_ord, seq[ sc + scc ] ) - tom1_ord;
				w.at( uc, sc ) += tom1[ ord * tom1_max + min( p.unit[uc].scheme[scc], tom1_max - 1 ) ];
			}
		}
	}
}

#include "distr.cpp"
//const double energyFactor = 0.1;// 8.31 * 300. / 42000.;//??????????

double SelEnergy( double length, double dist )
{
	dist /= 3.5;

	int il = (int)length - 3;
	if ( il < 0 ) return -big;
	if ( il >= 20 ) il = 20;
	int id = (int)( dist * 2 );
	if ( id >= 40 ) id = 40;
	double v = ldistr[il][id];
	if ( v == 0 ) return -big; // return -100;

	return ( log( v ) ) * energyFactor;
}

static void loop_weights( Matrix& w, Pathway& p, string seq )
{
	for ( int uc = 0; uc < p.unit.size() - 1; uc++ )
	{
		for ( int sc = 0; sc < seq.size(); sc++ )
		{
			if ( sc > 20 )
			{
				w.at( uc, sc ) = -big;
				continue;
			}
			w.at( uc, sc ) = SelEnergy( sc, p.unit[uc].distance );
		}
	}
}

int Dynamic( Pathway& p, string seq )
{
	Matrix w1( p.unit.size(), seq.size() );
	Matrix w2( p.unit.size(), seq.size() );
	
	contact_weights( w1, p, seq );
	loop_weights( w2, p, seq );
	
	Matrix m1( p.unit.size(), seq.size() );
	for ( int sc = 0; sc < seq.size(); sc++ ) m1.at( 0, sc ) = w1.at( 0, sc );
	for ( int uc = 1; uc < p.unit.size(); uc++ )
	{
		for ( int sc = 0; sc < seq.size(); sc++ )
		{
			double bweight = -big;
			for ( int scc = 0; scc < sc - p.unit[ uc - 1 ].ss.size; scc++ )
			{
				double cweight = m1.at( uc - 1, scc ) + w2.at( uc - 1, sc - scc - p.unit[ uc - 1 ].ss.size );
				if ( cweight > bweight )
				{
					bweight = cweight;
				}
			}
			m1.at( uc, sc ) = bweight + w1.at( uc, sc );
		}
	}
	double bweight = -big;
	int bc = -1;
	int uc = p.unit.size() - 1;
	for ( int sc = 0; sc < seq.size(); sc++ )
	{
		if ( m1.at( uc, sc ) > bweight )
		{
			bweight = m1.at( uc, sc );
			bc = sc;
		}
	}
	if ( bc == -1 ) return 0;
	p.unit[uc].ss.beg = bc;
	p.energy = bweight;
	for ( uc--; uc >= 0; uc-- )
	{
		int sc = p.unit[ uc + 1 ].ss.beg;
		bweight = -big;
		bc = -1;
		for ( int scc = 0; scc < sc - p.unit[ uc ].ss.size; scc++ )
		{
			double cweight = m1.at( uc, scc ) + w2.at( uc, sc - scc - p.unit[ uc ].ss.size );
			if ( cweight > bweight )
			{
				bc = scc;
				bweight = cweight;
			}
		}
		if ( bc == -1 ) return 0;
		p.unit[uc].ss.beg = bc;
	}
	return 1;
}
				

void SavePathway( const Pathway& p, int order, FILE *ofile )
{
	Line lh( rHeader );
	lh.PutInt( fOrder, order );
	lh.PutDouble( fEnergy, p.energy );
	for ( int uc = 0; uc < p.unit.size(); uc++ )
	{
		const Unit &u = p.unit[uc];
		Line l( rSS );
		l.PutInt( fOrder, order );
		l.PutInt( fCluster, 0 );
		l.PutInt( fOrder, uc );
		l.PutInt( fFirst, u.ss.beg );
		l.PutInt( fSize, u.ss.size );
		l.PutInt( fType, u.ss.type );
		l.PutVector( fCenter, u.sp.beg );
		l.PutVector( fDir, u.sp.dir );
		l.PutVector( fOrientation, u.sp.orientation );
		lh.PutLine( l );
	}
	lh.Write( ofile );
}


bool operator<( const Pathway& p1, const Pathway& p2 )
{
	return p1.energy < p2.energy;
}

struct PCash
{
	typedef set<Pathway> Set;
	typedef Set::iterator iterator;
	Set set;
	int maxSize;
	
	PCash( int theMaxSize ) 
	{ 
		maxSize = theMaxSize; 
	}
	
	bool Insert( const Pathway& o )
	{
		if ( !set.size() && maxSize > 0 )
		{
			set.insert( o );
			return true;
		}
		const Pathway& omin = *( set.begin() );
		if ( set.size() >= maxSize && o < omin ) return false;
		set.insert( o );
		if ( set.size() > maxSize )
		{
			set.erase( set.begin() );
		}
		return true;
	}
};

int main( int argc, char **argv )
{
	if ( argc < 4 ) return 1;
	Input i;
	if ( !LoadPathway( i, argv[1] ) ) return 1;
	if ( !LoadSeq( i, argv[2] ) ) return 1;
	PCash cash( 20 );
	for ( list<Pathway>::iterator it = i.pathway.begin(); it != i.pathway.end(); it++ )
	{
		if ( Dynamic( *it, i.seq ) ) cash.Insert( *it );
		printf( "*" ); 
		fflush( stdout );

	}
	printf( "\n" );
	FILE *ofile = fopen( argv[3], "wt" );
	int cnt = 0;
	PCash::iterator it = cash.set.end(); 
	if ( it != cash.set.begin() ) do
	{
		it--;
		SavePathway( *it, cnt++, ofile );
	}
	while ( it != cash.set.begin() );
	fclose( ofile );
	return 0;
}
		
						
	