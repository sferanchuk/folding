

#include "common.h"
#include "counters.h"

#include <pdb++.h>

struct Unit
{
	SS ss;
	Space sp;
	CScheme scheme;
	double distance;
	double angle;
};

double hbondFactor = 0.018;//0.014;//0.03;//0.005;
const double CysBridgeTerm = 0.03;//0.05;
double AmberEnergyFactor = 0.05;
double SurfaceFactor = 0.0000672;


const double MinVdw = -100;
const double HPRatio = -0.5;
const double HFactor = 30000;

#include "chain.h"

static const char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

static double aa_conf[] = { 0.438069, 0, 0.251111, 1.24089,  1.2104, 0.421711,  0.41509,
						0.354882,  0.442724, 0,  0.510083,  0.713571,  0.7922, 1.59425,
						0, 0.429024, 1.5923,  2.4284,  0.875718, 0.860051, 0,
						0.824068,  0.702748, 0,  0.823387, 0 };
						
static void print_atom( FILE *ofile, int ac, const char *aname, const char *aatype, int rc, int lc, char chain, const char *name, Vector coord )
{
	fprintf( ofile, 
		"ATOM   %4d  %-3.3s %-3.3s %c %3d     %7.3f %7.3f %7.3f  1.00 00.00 \n",
//		"ATOM   %4d  %-3.3s %-3.3s %c %3d     %7.3f %7.3f %7.3f  1.00 00.00      %4.4s%4d\n",
		ac, aname, aatype, chain, rc, coord.x, coord.y, coord.z );
}

const int pdbLineSize = 100;

struct pdbLine
{
	char s[ pdbLineSize ];

	char *lineType() { return s; }
	char *atomNumber() { return s + 7; }
	char *atomType() { return s + 13; }
	char *chainName() { return s + 21; }
	char *aaNumber() { return s + 23; }
	char *aaName() { return s + 17; }
	char *x() { return s + 31; }
	char *y() { return s + 39; }
	char *z() { return s + 47; }
};

int LoadChain( Chain& chain, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	pdbLine line;
	while( ifile && fgets( line.s, pdbLineSize, ifile ) )
	{
		if ( strncmp( line.lineType(), "ATOM", 4 ) ) continue;
		if ( !chain.residue.size() || chain.residue.back().number != atoi( line.aaNumber() ) )
		{
			chain.residue.resize( chain.residue.size() + 1 );
			strncpy( chain.residue.back().name3, line.aaName(), 3 );
			chain.residue.back().name3[3] = 0;
			if ( strncmp( chain.residue.back().name3, "HI", 2 ) == 0 ) chain.residue.back().name3[2] = 'S';
			for ( int lc = 0; lc < 26; lc++ ) if ( strncmp( chain.residue.back().name3, a_name[lc], 3 ) == 0 ) chain.residue.back().name1 = lc + 'A';
			chain.residue.back().number = atoi( line.aaNumber() );
		}
		Atom a;
		memset( a.name, 0, sizeof( a.name ) );
		char *atomType = line.atomType() - 1;
		if ( *atomType == ' ' ) atomType++;
		strncpy( a.name, atomType, strcspn( atomType, " " ) );
		if ( strcmp( a.name, "OXT" ) == 0 ) strcpy( a.name, "O" );
		a.coord = Vector( atof( line.x() ), atof( line.y() ), atof( line.z() ) );
		chain.residue.back().atom.push_back( a );
	}
	if ( ifile ) fclose( ifile );
	return 1;
}

int LoadChain2( Chain &chain, const char * fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	if ( !fgets(buf, 256, ifile ) ) return 0;
	PDB *ppdb = new PDB( buf );
	Residue *r = NULL;
	bool model = false;

	do
	{
		PDB& pdb = *ppdb;
		if ( pdb.type() == PDB::ATOM ) 
		{
  			PDB::Atom &a = pdb.atom;
  			if ( a.residue.chainId == '\0' ) a.residue.chainId = ' ';
  			if ( a.residue.insertCode == '\0' ) a.residue.insertCode = ' ';
  			
  			if ( r == NULL || r->number != a.residue.seqNum || r->icode != a.residue.insertCode )
  			{
  				int order = chain.residue.size();
  				chain.residue.resize( order + 1 );
  				r = &( chain.residue.back() );
  				r->number = a.residue.seqNum;
   				r->icode = a.residue.insertCode;
 				strcpy( r->name3, a.residue.name );
				if ( strncmp( r->name3, "HI", 2 ) == 0 ) r->name3[2] = 'S';
				if ( strncmp( r->name3, "MSE", 3 ) == 0 ) strcpy( r->name3, "MET" );
				for ( int lc = 0; lc < 26; lc++ ) if ( strncmp( r->name3, a_name[lc], 3 ) == 0 ) r->name1 = lc + 'A';
  			}
  			r->atom.resize( r->atom.size() + 1 );
  			Atom &at = r->atom.back();
  			at.coord = Vector( a.xyz[0], a.xyz[1], a.xyz[2] );
			if ( a.name[0] == ' ' )
			{
				strcpy( at.name, a.name + 1 );
			}
			else strcpy( at.name, a.name );
  		}
		else if ( pdb.type() == PDB::MODEL ) 
		{
			if ( model ) break;
			else model = true;
		}
   		char buf[256];
   		if ( !fgets( buf, 256, ifile ) ) 
   		{
   			fclose( ifile );
   			return 1;
   		}
   		delete ppdb;
   		ppdb = new PDB( buf );
   	}
   	while ( 1 );
   	return 1;
}
		
#include "ff.cpp"
/*
double ChainVDWEnergy( Chain& chain )
{
	double rv = 0;
	for ( int rc1 = 0; rc1 < chain.residue.size(); rc1++ )
	{
		Residue& r1 = chain.residue[rc1];
		FFAA *aa1 = ffaa + r1.name1 - 'A';;
		//for ( aa1 = ffaa; aa1 < ffaa + 20 && strcmp( aa1->name3, r1.name3 ); aa1++ );
		for ( int rc2 = 0; rc2 < rc1; rc2++ )
		{
			Residue& r2 = chain.residue[rc2];
			FFAA *aa2 = ffaa + r2.name1 - 'A';;
			//for ( aa2 = ffaa; aa2 < ffaa + 20 && strcmp( aa2->name3, r2.name3 ); aa2++ );
			for ( int ac1 = 0; ac1 < r1.atom.size(); ac1++ )
			{
				Atom& a1 = r1.atom[ac1];
				FFAtom *at1;
				for ( at1 = aa1->atom; at1->name && strcmp( at1->name, a1.name ); at1++ );
				if ( !at1->name ) { printf( "can't find %d %d\n", rc1, ac1 ); continue; }
				if ( strcmp( ffield[ at1->number ].name, at1->type ) ) { printf( "mismatch %d %d\n", rc1, ac1 ); continue; }
				for ( int ac2 = 0; ac2 < r2.atom.size(); ac2++ )
				{
					Atom& a2 = r2.atom[ac2];
					if ( rc1 == rc2 + 1 && ac1 == aN && ac2 == aC ) continue;
					FFAtom *at2;
					for ( at2 = aa2->atom; at2->name && strcmp( at2->name, a2.name ); at2++ );
					if ( !at2->name ) { printf( "%d %d\n", rc2, ac2 ); continue; }
					double dist = ( a1.coord - a2.coord ).norm();
					if ( dist > 10 ) continue;
					dist /= 10;
					FFLJ& lj = ffield[ at1->number ].pot[ at2->number ];
					double en = lj.c6 * pow( dist, -6 ) - lj.c12 * pow( dist, -12 );
					en /= 4200;
					rv += en;
				}
			}
		}
	}
	return rv;
}
*/

#include "radii.h"
extern "C" {
#include "CalcAccSurf.h"
}


#define RN              1.65
#define RCA             1.87
#define RC              1.76
#define RO              1.4
#define RSIDEATOM       1.8
#define RWATER          1.4

static int radius( char name1, const char *aname, double& rv )
{
	FFAA *aa1 = ffaa + name1 - 'A';
	FFAtom *at1;
	for ( at1 = aa1->atom; at1->name && strcmp( at1->name, aname ); at1++ );
	const char *name = at1->type;
	if ( name[0] == 'C' ) 
	{
		rv = RSIDEATOM + RWATER;
		return 1;
	}
	else if ( name[0] == 'S' )
	{
		rv = RSIDEATOM + RWATER;
		return 1;
	}
	else if ( ( name1 == 'K' && strcmp( at1->name, "NZ" ) == 0 ) 
		|| ( name1 == 'R' && ( strncmp( at1->name, "NH", 2 ) == 0 || strcmp( at1->name, "NE" ) == 0 ) ) ) 
	{
		rv = RN + RWATER;
		return 1;
	}
	else if ( name[0] == 'O' )
	{
		rv = RO + RWATER;
		return 0;
	}
	else if ( name[0] == 'N' )
	{
		rv = RN + RWATER;
		return 0;
	}
	return -1;
}



#define DMAX 15.

double calc_surface( CAS *cas, Chain& chain, int nr, double& cysEn, int cbeg = 0, int cend = -1  )
{
	if ( cend == -1 ) cend = chain.residue.size();
	Residue& r1 = chain.residue[nr];
	double rv = 0;
	for ( int a1 = 0; a1 < r1.atom.size(); a1++ )
	{
		Atom &at1 = r1.atom[a1];
		double rad;
		int type = radius( r1.name1, at1.name, rad );
		double hpfactor = ( type == 1 ) ? 1 : - HPRatio;
		if ( type == -1 ) continue; 
		bool contact = false;
	    CASResetAtoms( cas );
	    CASSetCenterAtom( cas, at1.coord.x, at1.coord.y, at1.coord.z, rad );
		for ( int rc = cbeg; rc < cend; rc++ )
		{
			if ( rc == nr ) continue;
			Residue& r2 = chain.residue[rc];
			if ( false && rc > 0 && chain.residue[rc].number != chain.residue[rc-1].number + 1 )
			{
				Vector center = ( chain.residue[rc].atom[1].coord 
					+ chain.residue[rc-1].atom[1].coord ) * 0.5;
				Vector dir = center - chain.residue[rc].atom[1].coord;
				double rad = dir.norm() - 3.;
				if ( rad > 0 )
				{
					double dist = ( center - at1.coord ).norm();
					CASAddNeigbourAtom( cas, center.x, center.y, center.z, 
						rad, dist * dist );
				}
			}
			if ( ( r2.atom[0].coord - at1.coord ).norm() > 10 ) continue;
			for ( int a2 = 0; a2 < r2.atom.size(); a2++ )
			{
				Atom &at2 = r2.atom[a2];
				double rad2;
				if ( radius( r2.name1, at2.name, rad2 ) == -1 ) continue;
				double dist = ( at2.coord - at1.coord ).norm();
				if ( dist < rad + rad2 )
				{
					CASAddNeigbourAtom( cas, at2.coord.x, at2.coord.y, at2.coord.z, rad2, dist * dist );
				}
				if ( dist < 4.5 && at1.name[0] == 'S' && at2.name[0] == 'S' && r1.name1 == 'C' && r2.name1 == 'C' && rc < nr )
					cysEn += CysBridgeTerm;
				
			}
		}
		//double res = ( rad * rad * 4 * 3.14159 - CASSurface( cas ) ) * ( 2 * type - 1 );
		double res = CASSurface( cas ) * hpfactor;
		rv += res;
	}
	return rv;
}

double HydrEnergy( Chain& chain, double& cysEn )
{
	double rv = 0;
    CAS *cas= CASCreate(1/*ORDER*/);
    	cysEn = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		rv += calc_surface( cas, chain, rc, cysEn );
	}
	CASDelete( cas );
	return rv;
}

typedef float real;
typedef int integer;
typedef short ftnlen;

#include "rotamersbb.cpp"

extern "C" integer tinkerside_( char resname[3], real *chi, integer *n0, real *coord, integer *n );

void BuildSide( Residue& rs, Residue& r, Vector cprev, double *cchi )
{
	rs = r;
	real chi[4];
	integer n0 = 40, n;
	real coord[120];
	coord[0] = cprev.x;
	coord[1] = cprev.y;
	coord[2] = cprev.z;
	char resname[3];
	memcpy( resname, r.name3, 3 );
	for ( int ac = 1; ac < 4; ac++ )
	{
		coord[ ac * 3 ] = r.atom[ ac - 1 ].coord.x;
		coord[ ac * 3 + 1 ] = r.atom[ ac - 1 ].coord.y;
		coord[ ac * 3 + 2 ] = r.atom[ ac - 1 ].coord.z;
	}
	for ( int cc = 0; cc < 4; cc++ ) chi[cc] = cchi[cc];
	tinkerside_( resname, chi, &n0, coord, &n );
	FFAA *aa = ffaa + r.name1 - 'A';
	//for ( aa = ffaa; aa < ffaa + 20 && strcmp( aa->name3, r.name3 ); aa++ );
	for ( int ac = 4; ac < n - 1; ac++ )
	{
		if ( !( aa->atom[ ac ].name ) ) break;
		rs.atom.resize( ac + 1 );
		rs.atom[ ac ].coord.x = coord[ ac * 3 ];
		rs.atom[ ac ].coord.y = coord[ ac * 3 + 1 ];
		rs.atom[ ac ].coord.z = coord[ ac * 3 + 2 ];
		strcpy( rs.atom[ ac ].name, aa->atom[ ac ].name );
	}
}


void BuildSide( RotChain& rchain, Chain& chain )
{
	int ssconv[7] = { 0, 1, 1, 1, 1, 2 };
	double dummy[4] = {0};
	rchain.residue.resize( chain.residue.size() );
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Vector cprev;
		if ( rc > 0 && chain.residue[rc].number == chain.residue[rc-1].number + 1 )
			cprev = chain.residue[rc-1].atom[2].coord;
		else
		{
			Vector dir = chain.residue[rc].atom[0].coord - chain.residue[rc].atom[1].coord;
			dir = !dir;
			Vector cdir = chain.residue[rc].atom[1].coord - chain.residue[rc].atom[2].coord;
			Vector ort = cdir - dir * ( cdir * dir );
			ort = !ort;
			cprev = chain.residue[rc].atom[0].coord + dir * 1.41 * 0.5 + ort * 1.41 * 0.866;
		}
			
		int ord = chain.residue[rc].name1 - 'A';
		int type = 1;
		if ( numRotamers[ type ][ ord ] == 0 )
		{
			rchain.residue[rc].r.resize( 1 );
			BuildSide( rchain.residue[rc].r[0], chain.residue[rc], cprev, dummy );
			rchain.residue[rc].r[0].rotamer = 0;
			rchain.residue[rc].r[0].freq = 1;
		}
		else if ( rotamerFrequences[type][ord][0] == 0 )
		{
			rchain.residue[rc].r.resize( 1 );
			BuildSide( rchain.residue[rc].r[0], chain.residue[rc], cprev, &( rotamers[type][ord][0][0] ) );
			rchain.residue[rc].r[0].rotamer = 0;
			rchain.residue[rc].r[0].freq = 1;
		}
		else
		{ 
			int rtc = 0;
			for ( int tc = 0; tc < numRotamers[type][ord]; tc++ )
			{
				if ( rotamerFrequences[type][ord][tc] == 0 ) continue;
				rchain.residue[rc].r.resize( rtc + 1 );
				BuildSide( rchain.residue[rc].r[rtc], chain.residue[rc], cprev, 
					&( rotamers[type][ord][tc][0] ) );
				rchain.residue[rc].r[rtc].rotamer = tc;
				rchain.residue[rc].r[rtc].freq = rotamerFrequences[type][ord][tc];
				rtc++;
			}
		}
		rchain.residue[rc].surface = 0;
	}
}

void BuildSideWithH( Residue& rs, Residue& r, Vector cprev, double *cchi )
{
	rs = r;
	rs.atom.erase( rs.atom.begin() + 4, rs.atom.end() );
	real chi[4];
	integer n0 = 40, n;
	real coord[120];
	coord[0] = cprev.x;
	coord[1] = cprev.y;
	coord[2] = cprev.z;
	char resname[3];
	memcpy( resname, r.name3, 3 );
	if ( strncmp( resname, "HIS", 3 ) == 0 ) resname[2] = 'E';
	for ( int ac = 1; ac < 4; ac++ )
	{
		coord[ ac * 3 ] = r.atom[ ac - 1 ].coord.x;
		coord[ ac * 3 + 1 ] = r.atom[ ac - 1 ].coord.y;
		coord[ ac * 3 + 2 ] = r.atom[ ac - 1 ].coord.z;
	}
	for ( int cc = 0; cc < 4; cc++ ) chi[cc] = cchi[cc];
	tinkerside_( resname, chi, &n0, coord, &n );
	FFAA *aa = ffaa + r.name1 - 'A';
	//for ( aa = ffaa; aa < ffaa + 20 && strcmp( aa->name3, r.name3 ); aa++ );
	for ( int ac = 4; ac < n - 1; ac++ )
	{
		rs.atom.resize( ac + 1 );
		rs.atom[ ac ].coord.x = coord[ ac * 3 ];
		rs.atom[ ac ].coord.y = coord[ ac * 3 + 1 ];
		rs.atom[ ac ].coord.z = coord[ ac * 3 + 2 ];
		if ( ( aa->atom[ ac ].name ) )	strcpy( rs.atom[ ac ].name, aa->atom[ ac ].name );
		else strcpy( rs.atom[ac].name, "H" );
	}
}
			
void BuildSideWithH( Chain& nchain, Chain& chain )
{
	int ssconv[7] = { 0, 1, 1, 1, 1, 2 };
	double dummy[4] = {0};
	nchain.residue.resize( chain.residue.size() );
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Vector cprev;
		if ( rc > 0 && chain.residue[rc].number == chain.residue[rc-1].number + 1 )
			cprev = chain.residue[rc-1].atom[2].coord;
		else
		{
			Vector dir = chain.residue[rc].atom[0].coord - chain.residue[rc].atom[1].coord;
			dir = !dir;
			Vector cdir = chain.residue[rc].atom[1].coord - chain.residue[rc].atom[2].coord;
			Vector ort = cdir - dir * ( cdir * dir );
			ort = !ort;
			cprev = chain.residue[rc].atom[0].coord + dir * 1.41 * 0.5 + ort * 1.41 * 0.866;
		}
			
		int ord = chain.residue[rc].name1 - 'A';
		int type = 1;
		if ( numRotamers[ type ][ ord ] == 0 )
		{
			BuildSideWithH( nchain.residue[rc], chain.residue[rc], cprev, dummy );
		}
		else
		{ 
			BuildSideWithH( nchain.residue[rc], chain.residue[rc], cprev, 
				&( rotamers[type][ord][ chain.residue[rc].rotamer ][0] ) );
		}
	}
}

/*
double calc_surface( Residue& r1, Residue& r2 )
{
	double rv = 0;
	for ( int a1 = 0; a1 < r1.atom.size(); a1++ )
	{
		Atom &at1 = r1.atom[a1];
		double rad;
		int type = radius( r1.name1, at1.name, rad );
		if ( type == -1 ) continue; 
		bool contact = false;
		double hpfactor = ( type == 1 ) ? 1 : - HPRatio;
	   // CASResetAtoms( cas );
	    //CASSetCenterAtom( cas, at1.coord.x, at1.coord.y, at1.coord.z, rad );
		for ( int a2 = 0; a2 < r2.atom.size(); a2++ )
		{
			Atom &at2 = r2.atom[a2];
			double rad2;
			int type2 = radius( r2.name1, at2.name, rad2 );
			if ( type2 == -1 ) continue;
			double dist = ( at2.coord - at1.coord ).norm();
			if ( dist < rad + rad2 )
			{
				rv += rad * rad * 2 * 3.14159 
					* ( 1. + ( rad2 * rad2 - dist * dist - rad * rad ) / ( 2 * dist * rad ) )
					* hpfactor;
				//CASAddNeigbourAtom( cas, at2.coord.x, at2.coord.y, at2.coord.z, rad2, dist * dist );
				
			}
			if ( r1.name1 == 'C' && r2.name1 == 'C' 
				&& at1.name[0] == 'S' && at2.name[0] == 'S' && dist < rad + rad2 )
			{
				rv += HFactor * ssFactor / 2;
			}
		}
	}
	return rv;
}

#include "power.cpp"

double calc_vdw( Residue& r1, Residue& r2, int b1, int e1, int b2, int e2 )
{
	double rv = 0;
	FFAA *aa1 = ffaa + r1.name1 - 'A';;
	FFAA *aa2 = ffaa + r2.name1 - 'A';
	for ( int ac1 = b1; ac1 < e1; ac1++ )
	{
		Atom& a1 = r1.atom[ac1];
		
		FFAtom *at1 = aa1->atom + ac1;
		for ( int ac2 = b2; ac2 < e2; ac2++ )
		{
			Atom& a2 = r2.atom[ac2];
			if ( r1.number == r2.number + 1 && ac1 == aN && ac2 == aC ) continue;
			FFAtom *at2 = aa2->atom + ac2;
			double sqdist;
			double d2 = a1.coord.x - a2.coord.x; sqdist = d2 * d2;
			d2 = a1.coord.y - a2.coord.y; sqdist += d2 * d2;
			d2 = a1.coord.z - a2.coord.z; sqdist += d2 * d2;
			int dindex = int( sqdist * 10 );
			if ( dindex < 0 || dindex >= 360 ) continue;
			FFLJ& lj = ffield[ at1->number ].pot[ at2->number ];
			double en = lj.c6 * power3[ dindex ] - lj.c12 * power6[ dindex ];
			if ( en < -1e9 ) return en / 4200;
			rv += en;
		}
	}
	return rv / 4200;
}
*/
#include "surface.cpp"


bool PredictSide( Chain& chain, RotChain& rchain );

void AmberEnergy( Chain& chain, double& Epol, double& Eelt );

int CalcEnergy( const char *fname )
{
	Chain chain;
	if ( !LoadChain2( chain, fname ) ) return 0;
	Chain pchain = chain;
	int rcc = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		pchain.residue[rcc].atom.resize(4);
		int flag = 0;
		for ( int ac = 0; ac < chain.residue[rc].atom.size(); ac++ )
		{
			Atom& a = chain.residue[rc].atom[ac];
			if ( strcmp( a.name, "N" ) == 0 ) { pchain.residue[rcc].atom[0] = a; flag = flag | 1; }
			if ( strcmp( a.name, "CA" ) == 0 ) { pchain.residue[rcc].atom[1] = a; flag = flag | 2; }
			if ( strcmp( a.name, "C" ) == 0 ) { pchain.residue[rcc].atom[2] = a; flag = flag | 4; }
			if ( strcmp( a.name, "O" ) == 0 ) { pchain.residue[rcc].atom[3] = a; flag = flag | 8; }
		}
		if ( flag == 15 ) rcc++;
		else pchain.residue.erase( pchain.residue.begin() + rcc );
	}
	RotChain rchain;
	BuildSide( rchain, pchain );
	Chain nchain;
	nchain.residue.resize( pchain.residue.size() );
	PredictSide( nchain, rchain );
	Chain hchain;
	BuildSideWithH( hchain, nchain );
	double Epol, Eelt, Ecys;
	AmberEnergy( hchain, Epol, Eelt );
	double Ecorr = 0;
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		Ecorr += aa_conf[ chain.residue[rc].name1 - 'A' ];
	}
	double res = -HydrEnergy( nchain, Ecys );
	for ( int rc = 0; rc < nchain.residue.size(); rc++ )
	{
		res += averageSurface[ min( 
		int( ( nchain.residue.back().number - nchain.residue[0].number ) / SizeStep ), MaxSizeCount - 1 ) ]
		[ nchain.residue[rc].name1 - 'A' ];
	}
	printf( "Electrostatic energy term: %g\n", AmberEnergyFactor * ( Eelt + Ecorr ) * 10 );
	printf( "Surface term:              %g\n", - SurfaceFactor * res * 10);
	printf( "Cysteine bridges term:     %g\n", - Ecys * 10 );
	return 1;
}


int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	if ( !CalcEnergy( argv[1] ) ) return 1;
	return 0;
}
