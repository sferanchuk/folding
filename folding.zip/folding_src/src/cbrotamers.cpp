
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};
			
const int maxRotamer = 200;						
			
struct Rotamer
{
	char *name3;
	int nr;
	//int sum;
	double freq[ maxRotamer ];
	double chi[ maxRotamer ][4];
};

Rotamer data[26][3];

int main()
{
	FILE *ifile = fopen( "myBBDepRotamer.lib", "rt" );
	if ( !ifile ) return 1;
	char buf[200];
	int phi[3] = { -110, -60, -70 };
	int psi[3] = { 130, 30, 20 };
	int maxn = 0;
	while ( fgets( buf, 200, ifile ) )
	{
		int an = 0;
		while ( an < 26 && strncmp( buf, a_name[an], 3 ) ) an++;
		if ( an == 26 ) continue;
		int cphi = atoi( buf + 5 );
		int cpsi = atoi( buf + 10 );
		int tc = 0;
		while ( tc < 3 && !( cphi == phi[tc] && cpsi == psi[tc] ))  tc++;
		if ( tc == 3 ) continue;
		//int n = atoi( buf + 21 );
		//if ( n < 3 ) continue;
		//data[an].sum += n;
		int& num = data[an][tc].nr;
		data[an][tc].freq[num] = atof( buf + 32 );
		double *chi = &( data[an][tc].chi[ num ][0] );
		chi[0] = atof( buf + 43 );
		chi[1] = atof( buf + 51 );
		chi[2] = atof( buf + 59 );
		chi[3] = atof( buf + 67 );
		num++;
		if ( num > maxn ) maxn = num;
	}
	fclose( ifile );
	printf ( "int numRotamers[3][26] = { " );
	for ( int tc = 0; tc < 3; tc++ )
	{
	printf( "{ " );
	for ( int lc = 0; lc < 26; lc++ )
	{
		printf( " %d ", data[lc][tc].nr );
		if ( lc < 25 ) printf( "," );
		else printf( "}" );
	}
	if ( tc < 2 ) printf( ",\n" );
	else printf( " };\n" );
	}
	
	printf ( "double rotamerFrequences[3][26][%d] = { ", maxn );
	for ( int tc = 0; tc < 3; tc++ )
	{
	printf( "{ " );
	for ( int lc = 0; lc < 26; lc++ )
	{
		printf( "{ " );
		if ( data[lc][tc].nr == 0 ) printf ( "1." );
		for ( int nc = 0; nc < data[lc][tc].nr; nc++ )
		{
			printf( " %7.4f ", data[lc][tc].freq[nc] );
			if ( nc < data[lc][tc].nr - 1 ) printf ( " , " );
		}
		printf( " } " );
		if ( lc < 25 ) printf( ",\n" );
		else printf( " }" );
	}
	if ( tc < 2 ) printf( ",\n" );
	else printf( " };\n" );
	}
	
	printf ( "double rotamers[3][26][%d][4] = { ", maxn );
	for ( int tc = 0; tc < 3; tc++ )
	{
	printf( "{ " );
	for ( int lc = 0; lc < 26; lc++ )
	{
		printf( "{ " );
		for ( int nc = 0; nc < data[lc][tc].nr; nc++ )
		{
			printf( " { " );
			for ( int cc = 0; cc < 4; cc++ )
			{
				printf( " %8.2f ", data[lc][tc].chi[nc][cc] );
				if ( cc < 3 ) printf( "," );
				else printf ( "}" );
			}
			if ( nc < data[lc][tc].nr - 1 ) printf ( " , " );
		}
		printf( " } " );
		if ( lc < 25 ) printf( ",\n" );
		else printf( " }" );
	}
	if ( tc < 2 ) printf( ",\n" );
	else printf( " };\n" );
	}
	return 0;
}

		
