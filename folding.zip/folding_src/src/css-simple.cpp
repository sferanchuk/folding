
// create secondary structure file

#include "common.h"

#include <pdb++.h>

struct Atom
{
	Vector coord;
	int number;
	char name[5];
};

enum { aN, aCA, aC, aO };

struct Residue
{
	vector<Atom> atom;
	Vector center;
	int number;
	char icode;
	char name3[5];
	char name1;
	int order;
};

struct Coil
{
	int first;
	int size;
	int ss1;
	int ss2;
	double distance;
	double angle;
	int order;
};

struct Chain
{
	vector<Residue> residue;
	string seq;
	string ss;
	char letter;
	char fname[10];
};

int LoadChain( FILE *ifile, PDB **ppdb, Chain &chain, const char *oname );
int LoadSS( Chain& chain, const char *oname );
void AddHydrContacts( Chain& chain );
void AddCoils( Chain& chain );
void WriteChain( Chain& chain, FILE *ofile );

//------------------------------------------------------------------------------

static int get_sname( const char *fname, char *sname, int size )
{
   	char buf[256];
   	strcpy( buf, fname );
   	int c = strlen( buf ) - 1;
   	while ( c > 0 && buf[c] != '.' ) c--;
    buf[c] = 0;
    while ( c > 0 && buf[c] != '\\' && buf[c] != '/' ) c--;
   	if ( buf[c] == '\\' || buf[c] == '/' ) c++;
   	strncpy( sname, buf + c, size - 1 );
   	sname[ size - 1 ] = 0;
}

static void make_center( Residue &res )
{
	Vector dir1 = !( res.atom[ aC ].coord - res.atom[ aCA ].coord );
	Vector dir2 = !( res.atom[ aN ].coord - res.atom[ aCA ].coord );
	Vector basis1 = !( dir1 + dir2 );
	Vector basis2 = !( dir1 & dir2 );
	Vector dirc = !( basis1 * cos( 54. * 3.14 / 180 ) + basis2 * cos( 36. * 3.14 / 180 ) );
	res.center = res.atom[ aCA ].coord - dirc * 3.;
}

void add_centers( Chain& chain )
{
	for ( int rc = 0; rc < chain.residue.size(); rc++ )
	{
		make_center( chain.residue[rc] );
	}
}

int ProcessPdbFile( const char *fname )
{
	char sname[10] = "";
	get_sname( fname, sname, sizeof( sname ) );
	char tmpname[20];
	strcpy( tmpname, sname );
	strcat( tmpname, ".tmp" );

	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	if ( !fgets(buf, 256, ifile ) ) return 0;
	PDB *pdb = new PDB( buf );
	do
	{
		Chain chain;
		strcpy( chain.fname, sname );

		int res =  LoadChain( ifile, &pdb, chain, tmpname );
		chain.ss.append( chain.seq.size(), 'C' );
		if ( !LoadSS( chain, tmpname ) ) break;
        char oname[13];
        sprintf( oname, "%s:%c", sname, ( chain.letter == ' ' ) ? '_' : chain.letter );
		printf( ">%s {%s}\n%s\n", oname, chain.ss.data(), chain.seq.data() );
		if ( !res ) break;
	}
	while ( 1 );
	delete pdb;
	fclose( ifile );
	return 1;
}

static int convert_resname( char *name3 )
{
	const char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

	for ( int ac = 0; ac < 26; ac++ )
	{
		if ( strncmp( a_name[ac], name3, 3 ) == 0 ) return 'A' + ac;
	}
	return 0;
}


int LoadChain( FILE *ifile, PDB **ppdb, Chain &chain, const char *oname )
{
	FILE *ofile = fopen( oname, "wb" );
	if ( !ofile ) return 0;
	Residue *r = NULL;

	do
	{
		PDB& pdb = **ppdb;
		if ( pdb.type() == PDB::ATOM ) 
		{
  			PDB::Atom &a = pdb.atom;
  			if ( a.residue.chainId == '\0' ) a.residue.chainId = ' ';
  			if ( a.residue.insertCode == '\0' ) a.residue.insertCode = ' ';
  			
  			if ( r == NULL ) chain.letter = a.residue.chainId;
  			else if ( chain.letter != a.residue.chainId ) 
  			{
  				fclose( ofile );
  				return 1;
  			}

  			if ( r == NULL || r->number != a.residue.seqNum || r->icode != a.residue.insertCode )
  			{
  				int order = chain.residue.size();
  				chain.residue.resize( order + 1 );
  				r = &( chain.residue.back() );
  				r->order = order;
  				r->number = a.residue.seqNum;
  				r->icode = a.residue.insertCode;
  				strcpy( r->name3, a.residue.name );
  				r->name1 = convert_resname( r->name3 );
				chain.seq.append( 1, r->name1 );
  			}
  			r->atom.resize( r->atom.size() + 1 );
  			Atom &at = r->atom.back();
  			at.coord = Vector( a.xyz[0], a.xyz[1], a.xyz[2] );
  			strcpy( at.name, a.name );
  			at.number = a.serialNum;
			
			fprintf( ofile, "%s\n", pdb.chars() );
 		}
		else if ( pdb.type() == PDB::MODEL ) 
		{
			if ( pdb.model.num != 1 ) 
			{
				fclose( ofile );
				return 0;
			}
		}

   		char buf[256];
   		if ( !fgets( buf, 256, ifile ) ) 
   		{
   			fclose( ofile );
   			return 0;
   		}
   		delete *ppdb;
   		*ppdb = new PDB( buf );
   	}
   	while ( 1 );
   	return 1;
}


int LoadSS( Chain& chain, const char *oname )
{
	const char *tmpname = "ss.tmp";
	char command[256];
	sprintf( command, "./ksdssp %s >%s", oname, tmpname );
	if ( system( command ) != 0 ) return 0;
	unlink( oname );
	FILE *ifile = fopen( tmpname, "rt" );
	if ( !ifile ) return 0;
	char buf[256];
	while ( fgets( buf, 256, ifile ) )
	{
		PDB pdb( buf );
  		if ( pdb.type() == PDB::HELIX ) 
  		{
  			int afirst = pdb.helix.residues[0].seqNum;
  			int alast =  pdb.helix.residues[1].seqNum;
  			for ( int rc = 0; rc < chain.residue.size(); rc++ )
			{
				if ( chain.residue[rc].number >= afirst && chain.residue[rc].number <= alast ) chain.ss[rc] = 'H';
			}
  		}
  		else if ( pdb.type() == PDB::SHEET ) 
  		{
  			int afirst = pdb.sheet.residues[0].seqNum;
  			int alast =  pdb.sheet.residues[1].seqNum;
  			for ( int rc = 0; rc < chain.residue.size(); rc++ )
			{
				if ( chain.residue[rc].number >= afirst && chain.residue[rc].number <= alast ) chain.ss[rc] = 'S';
			}
  		}
  		else continue;
  	}
  	fclose( ifile );
  	unlink( tmpname );
  	return 1;
}


int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	ProcessPdbFile( argv[1] );
	return 0;
}

