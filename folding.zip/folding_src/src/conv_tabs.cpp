
#include <stdio.h>

int main( int argc, char *argv[] )
{
	bool first = true;
	do
	{
		int ch = fgetc( stdin );
		if ( ch == EOF ) break;
		else if ( ch == '\n' ) first = true;
		else 
		{
			if ( ch != ' ' ) first = false;
			else if ( first ) ch = '\t';
		}
		fputc( ch, stdout );
	}
	while ( 1 );
	return 0;
}