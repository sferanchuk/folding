
#include <math.h>

#include "common.h"
#include "chain.h"

#define coord( ch, i ) ch.residue[i].atom[aCA].coord

const int size1 = 5;
const int size2 = 2;
const double threshold = 0.2;

const int pdbLineSize = 100;

static const char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

struct pdbLine
{
	char s[ pdbLineSize ];

	char *lineType() { return s; }
	char *atomNumber() { return s + 7; }
	char *atomType() { return s + 13; }
	char *chainName() { return s + 21; }
	char *aaNumber() { return s + 23; }
	char *aaName() { return s + 17; }
	char *x() { return s + 31; }
	char *y() { return s + 39; }
	char *z() { return s + 47; }
};

void LoadChain( Chain& chain, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	pdbLine line;
	while( ifile && fgets( line.s, pdbLineSize, ifile ) )
	{
		if ( strncmp( line.lineType(), "ATOM", 4 ) ) continue;
		if ( !chain.residue.size() || chain.residue.back().number != atoi( line.aaNumber() ) )
		{
			chain.residue.resize( chain.residue.size() + 1 );
			strncpy( chain.residue.back().name3, line.aaName(), 3 );
			chain.residue.back().name3[3] = 0;
			for ( int lc = 0; lc < 26; lc++ ) if ( strncmp( line.aaName(), a_name[lc], 3 ) == 0 ) chain.residue.back().name1 = lc + 'A';
			chain.residue.back().number = atoi( line.aaNumber() );
		}
		Atom a;
		memset( a.name, 0, sizeof( a.name ) );
		strncpy( a.name, line.atomType(), strcspn( line.atomType(), " " ) );
		if ( strcmp( a.name, "OXT" ) == 0 ) strcpy( a.name, "O" );
		a.coord = Vector( atof( line.x() ), atof( line.y() ), atof( line.z() ) );
		chain.residue.back().atom.push_back( a );
	}
	if ( ifile ) fclose( ifile );
}

void BuildFeatures1( Chain& chain, int beg, int end, vector<int>& features )
{
	for ( int pc1 = 0; pc1 < end - beg; pc1++ )
	{
		for ( int pc2 = 0; pc2 < pc1; pc2++ )
		{
			double score = 0;
			double norm = 0; 
			int weight = 0;
			for ( int sc1 = -size1; sc1 <= size1; sc1++ )
			{
				for ( int sc2 = -size2; sc2 <= size2; sc2++ )
				{
					int res1 = beg + pc1 - pc2 + sc1;
					int res2 = beg + pc1 + pc2 + sc2;
					if ( res1 < beg || res1 >= end || res2 < beg || res2 >= end || res1 >= res2 ) continue;
					double dist = ( coord( chain, res1 ) - coord( chain, res2 ) ).norm();
					//double measure = exp( - dist / 5. );
					double measure = 1. / ( 1. + dist * dist / 25. );
					double factor = 1. / ( 1. + abs( sc2 - pc2 ) );
					norm += factor;
					score += measure * factor;
					weight++;
				}
			}
			if ( score / norm < threshold ) weight = 0;
			features.push_back( weight );
		}
	}
}

void BuildFeatures2( Chain& chain, int beg, int end, vector<int>& features )
{
	for ( int pc1 = 0; pc1 < end - beg; pc1++ )
	{
		for ( int pc2 = 0; pc2 < pc1; pc2++ )
		{
			double score = 0;
			double norm = 0; 
			int weight = 0;
			for ( int sc1 = -size1; sc1 <= size1; sc1++ )
			{
				for ( int sc2 = -size2; sc2 <= size2; sc2++ )
				{
					int res1 = beg + pc1 - pc2 + sc2;
					int res2 = beg + pc1 + pc2 + sc1;
					if ( res1 < beg || res1 >= end || res2 < beg || res2 >= end || res1 >= res2 )
						continue;
					double dist = ( coord( chain, res1 ) - coord( chain, res2 ) ).norm();
					//double measure = exp( - dist / 5. );
					double measure = 1. / ( 1. + dist * dist / 25. );
					double factor = 1. / ( 1. + abs( sc2 ) );
					norm += factor;
					score += measure * factor;
					weight++;
				}
			}
			if ( score / norm < threshold ) weight = 0;
			features.push_back( weight );
		}
	}
}

int Align( Chain& target, Chain& prediction )
{
	const int frames = 10;
	for ( int beg = 0; beg < target.residue.size() - frames; beg++ )
	{
		bool match = true;
		for ( int fc = 0; fc < frames; fc++ )
		{
			if ( target.residue[ beg + fc ].name1 != prediction.residue[fc].name1 )
			{
				match = false;
				break;
			}
		}
		if ( match ) return beg;
	}
	return -1;
}

double Correlation( vector<int>& f1, vector<int>& f2 )
{
	if ( f1.size() != f2.size() )
	{
		printf( "bad input for correlation: %d %d\n", f1.size(), f2.size() );
		exit( 1 );
	}
	double n1 = 0;
	double n2 = 0;
	double corr = 0;
	for ( int fc = 0; fc < f1.size(); fc++ )
	{
		n1 += f1[fc] * f1[fc];
		n2 += f2[fc] * f2[fc];
		corr += f1[fc] * f2[fc];
	}
	return corr / sqrt( n1 * n2 );
}

void PrintDMap( Chain& chain, const char *oname )
{
	const int pixelSize = 2;
	FILE *ofile = fopen( oname, "wt" );
	if ( !ofile ) return;
	fprintf( ofile, "%!PS-Adobe-3.0 EPSF-3.0\n" );
	for ( int rc1 = 0; rc1 < chain.residue.size(); rc1++ )
	{
		for ( int rc2 = 0; rc2 < chain.residue.size(); rc2++ )
		{
			double dist = ( coord( chain, rc1 ) - coord( chain, rc2 ) ).norm();
			double measure = 1 - 1. / ( 1. + dist * dist / 25. );
			fprintf( ofile, "%d %d moveto ", rc1 * pixelSize, rc2 * pixelSize );
			fprintf( ofile, "%d 0 rlineto 0 %d rlineto %d 0 rlineto closepath\n", 
				pixelSize, pixelSize, - pixelSize );
			fprintf( ofile, "%g %g %g setrgbcolor fill\n", measure, measure, measure );
		}
	}
	fprintf( ofile, "showpage\n" );
	fclose( ofile );
}
		

int CompareStructures( const char *name_t, const char *name_p )
{
	Chain target;
	LoadChain( target, name_t );
	if ( !target.residue.size() ) return 1;
	Chain prediction;
	LoadChain( prediction, name_p );
	if ( !prediction.residue.size() ) return 1;
	int beg_t = Align( target, prediction );
	if ( beg_t == -1 )
	{
		printf( "structures don't match\n" );
		return 1;
	}
	int end_t = beg_t + prediction.residue.size();
	if ( end_t > target.residue.size() )
	{
		printf( "bad structure match\n" );
		return 1;
	}
	int beg_p = 0;
	int end_p = prediction.residue.size();
	vector<int> f_t;
	BuildFeatures1( target, beg_t, end_t, f_t );
	BuildFeatures2( target, beg_t, end_t, f_t );
	vector<int> f_p;
	BuildFeatures1( prediction, beg_p, end_p, f_p );
	BuildFeatures2( prediction, beg_p, end_p, f_p );
	double measure = Correlation( f_t, f_p );
	printf( "correlation = %g\n", measure );
	return 0;
}

int CompareRandom( const char *name1, const char *name2 )
{
	Chain ch1;
	LoadChain( ch1, name1 );
	if ( !ch1.residue.size() ) return 1;
	Chain ch2;
	LoadChain( ch2, name2 );
	if ( !ch2.residue.size() ) return 1;
	int beg1 = 0;
	int end1 = ch1.residue.size();
	int beg2 = 0;
	int end2 = ch2.residue.size();
	end1 = end2 = min( end1, end2 );
	vector<int> f1;
	BuildFeatures1( ch1, beg1, end1, f1 );
	BuildFeatures2( ch1, beg1, end1, f1 );
	vector<int> f2;
	BuildFeatures1( ch2, beg2, end2, f2 );
	BuildFeatures2( ch2, beg2, end2, f2 );
	double measure = Correlation( f1, f2 );
	printf( "correlation = %g\n", measure );
	return 0;
}

void Shuffle( vector<int>& init, vector<int>& shuffled )
{
	shuffled.resize( init.size() );
	for ( int c = 0; c < init.size(); c++ ) shuffled[c] = -1;
	for ( int c = init.size(); c > 0; c-- )
	{
		int r = rand() % c;
		for ( int cc = 0; cc < init.size(); cc++ )
		{
			if ( shuffled[cc] != -1 ) continue;
			if ( r == 0 ) 
			{
				shuffled[cc] = init[ c - 1 ];
				break;
			}
			r--;
		}
	}
}

int CalcMean( const char *name )
{
	Chain ch;
	LoadChain( ch, name );
	if ( !ch.residue.size() ) return 0;
	vector<int> f;
	BuildFeatures1( ch, 0, ch.residue.size(), f );
	BuildFeatures2( ch, 0, ch.residue.size(), f );
	double mean = 0;
	double meansq = 0;
	int cnt = 0;
	for ( int c = 0; c < 100; c++ )
	{
		vector<int> ff;
		Shuffle( f, ff );
		double measure = Correlation( f, ff );
		mean += measure;
		meansq += measure * measure;
		cnt++;
	}
	printf( "mean %g mdisp %g\n", mean /cnt, sqrt( meansq / cnt ) );
	return 1;
}

int CreateDMap( const char *cname, const char *ps )
{
	Chain chain;
	LoadChain( chain, cname );
	if ( !chain.residue.size() ) return 1;
	PrintDMap( chain, ps );
	return 0;
}

int main( int argc, char **argv )
{
	if ( argc < 2 ) return 1;
	if ( strcmp( argv[1], "compare" ) == 0 )
	{
		if ( argc < 4 ) return 1;
		return CompareStructures( argv[2], argv[3] );
	}
	else if ( strcmp( argv[1], "print" ) == 0 )
	{
		if ( argc < 4 ) return 1;
		return CreateDMap( argv[2], argv[3] );
	}
	else if ( strcmp( argv[1], "random" ) == 0 )
	{
		if ( argc < 4 ) return 1;
		return CompareRandom( argv[2], argv[3] );
	}
	else if ( strcmp( argv[1], "shuffle" ) == 0 )
	{
		if ( argc < 3 ) return 1;
		return CalcMean( argv[2] );
	}
	printf( "unknown command\n" );
	return 1;
}
