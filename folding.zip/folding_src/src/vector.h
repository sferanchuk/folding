#ifndef VECTOR_H
#define VECTOR_H


#include <math.h>
#include <time.h>
#include <stdlib.h>

#define ZERO 1.e-10
#define ZERO1 1.e-6
#define ZERO2 1.e-2
#define ZERO3 5.e-2
#define PI 3.14159
#define AMPLITUDE 10
extern double disperse;

inline double sqr(double f){return f*f;} ;

struct Vector {
   double x, y, z;
   Vector(){
   x=0;y=0;z=0;};
   Vector(double x_, double y_, double z_){
   x=x_;y=y_;z=z_;};
   inline double norm() const
   {return sqrt
		   ( sqr(x) +
			 sqr(y) +
			 sqr(z) );
   };
};

enum{LINE, ROW};

struct matrix{
 double xx, xy, xz,
		yx, yy, yz,
		zx, zy, zz;
 matrix(){
 xx=0;xy=0;xz=0;
 yx=0;yy=0;yz=0;
 zx=0;zy=0;zz=0;
 };
 matrix(const Vector&, const Vector&, const Vector&, char);
 inline double Sp(){ return xx + yy + zz; };
 inline double norm()
   {return sqrt
		   ( sqr(xx) + sqr(yx) + sqr(zx) +
			 sqr(xy) + sqr(yy) + sqr(zy) +
			 sqr(xz) + sqr(yz) + sqr(zz) );
   };
 Vector row(char);
 Vector line(char);
};

//Vector E1(1, 0, 0);
//Vector E2(0, 1, 0);
//Vector E3(0, 0, 1);
//matrix E (E1, E2, E3, ROW);

inline double operator* (const Vector& a, const Vector& b)
{
double product = a.x*b.x + a.y*b.y + a.z*b.z;
return product;
}
inline Vector operator& (const Vector& a, const Vector& b)
{
Vector product;
product.x = a.y*b.z - a.z*b.y;
product.y = a.z*b.x - a.x*b.z;
product.z = a.x*b.y - a.y*b.x;
return product;
}
inline Vector operator+ (const Vector& a, const Vector& b)
{
Vector summ;
summ.x = a.x + b.x;
summ.y = a.y + b.y;
summ.z = a.z + b.z;
return summ;
}
inline Vector operator- (const Vector& a, const Vector& b)
{
Vector summ;
summ.x = a.x - b.x;
summ.y = a.y - b.y;
summ.z = a.z - b.z;
return summ;
}
inline Vector operator* (const Vector& a, double b)
{
Vector result;
result.x = a.x * b;
result.y = a.y * b;
result.z = a.z * b;
return result;
}
inline Vector operator! (const Vector& a)
{
double norm = a.norm();
if (norm <= ZERO)
    norm = norm;
return a*(1./norm);
}

Vector turn(const Vector& x, const Vector& s, double, double);   //turns x, s-axis, s=!s
matrix operator! (const matrix&);                      //transpone
matrix operator+ (const matrix& , matrix& );
matrix operator- (const matrix& , const matrix& );
matrix operator* (const matrix& , const matrix& );
Vector operator* (const matrix& , const Vector& );

double dihedral_angle( Vector v1, Vector v2, Vector v3, Vector v4);

#endif
