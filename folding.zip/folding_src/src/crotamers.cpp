
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};
			
const int maxRotamer = 200;						
			
struct Rotamer
{
	char *name3;
	int nr;
	int sum;
	int nocc[ maxRotamer ];
	double chi[ maxRotamer ][4];
};

Rotamer data[26];

int main()
{
	FILE *ifile = fopen( "myBBIndRotamer.lib", "rt" );
	if ( !ifile ) return 1;
	char buf[100];
	int maxn = 0;
	while ( fgets( buf, 100, ifile ) )
	{
		int an = 0;
		while ( an < 26 && strncmp( buf, a_name[an], 3 ) ) an++;
		if ( an == 26 ) continue;
		int n = atoi( buf + 21 );
		if ( n < 3 ) continue;
		data[an].sum += n;
		int& num = data[an].nr;
		data[an].nocc[num] = n;
		double *chi = &( data[an].chi[ num ][0] );
		chi[0] = atof( buf + 56 );
		chi[1] = atof( buf + 70 );
		chi[2] = atof( buf + 84 );
		chi[3] = atof( buf + 98 );
		num++;
		if ( num > maxn ) maxn = num;
	}
	fclose( ifile );
	printf ( "int numRotamers[26] = { " );
	for ( int lc = 0; lc < 26; lc++ )
	{
		printf( " %d ", data[lc].nr );
		if ( lc < 25 ) printf( "," );
		else printf( "};\n" );
	}
	printf ( "double rotamerFrequences[26][%d] = { ", maxn );
	for ( int lc = 0; lc < 26; lc++ )
	{
		printf( "{ " );
		if ( data[lc].nr == 0 ) printf ( "1." );
		for ( int nc = 0; nc < data[lc].nr; nc++ )
		{
			printf( " %7.4f ", double( data[lc].nocc[nc] ) / data[lc].sum );
			if ( nc < data[lc].nr - 1 ) printf ( " , " );
		}
		printf( " } " );
		if ( lc < 25 ) printf( ",\n" );
		else printf( " };\n" );
	}
	printf ( "double rotamers[26][%d][4] = { ", maxn );
	for ( int lc = 0; lc < 26; lc++ )
	{
		printf( "{ " );
		for ( int nc = 0; nc < data[lc].nr; nc++ )
		{
			printf( " { " );
			for ( int cc = 0; cc < 4; cc++ )
			{
				printf( " %8.2f ", data[lc].chi[nc][cc] );
				if ( cc < 3 ) printf( "," );
				else printf ( "}" );
			}
			if ( nc < data[lc].nr - 1 ) printf ( " , " );
		}
		printf( " } " );
		if ( lc < 25 ) printf( ",\n" );
		else printf( " };\n" );
	}
	return 0;
}

		
