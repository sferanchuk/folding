
enum { eOK, eEMPTY, eEOREC, eEOF, eERROR };

class Line
{
	string type;
	string tvalue;
	int cnt;
	vector<string> field;
	vector<string> value;
	vector<Line*> child;
public:
    Line() {}
    Line( const char *t ) { type = t; }
	Line( const Line& l );
	void operator=( const Line& l );
    ~Line();
	int Read( FILE *ifile );
    string GetType() { return type; }
    string GetString( const string& f );
    int GetInt( const string& f ) { return atoi( GetString( f ).data() ); }
    double GetDouble( const string& f ) { return atof( GetString( f ).data() ); }
    Vector GetVector( const string& f );
	bool GetFirst( Line& l );
	bool GetNext( Line& l );
    void PutInt( const string& f, int v );
    void PutDouble( const string& f, double v );
    void PutVector( const string& f, Vector v );
	void PutString( const string& f, const string& v );
	void PutLine( const Line& l );
	void SetType( const string& t ) { type = t; }
	int Write( FILE *ofile );
};

#define rHeader "HEADER"
#define rSS "SS"
#define rSSDetail "SSDET"
#define rCoil "COIL"
#define rCoilDetail "COILDET"
#define rContact "CONTACT"
#define rPWSim "PWSIM"
#define rISS "ISS"
#define rLSS "LSS"
#define rLetter "LETTER"
#define rMono "MONO"
#define rLink "LINK"
#define rLast "LAST"
#define rScheme "SCHEME"
#define rSchemeDetail "SCHDET"
#define rLinkDetail "LINKDET"
#define rTag "TAG"
#define rPathway "PATHWAY"
#define rUnit "UNIT"
#define rDirection "DIR"
#define rCoilEnergy "CE"
#define rCoilOffset "CO"
#define rPotGap "PG"
#define rHBondFactor "HF"
#define rPotential "POT"
#define rStruct "STRUCT"
#define rBackbone "BACKBONE"

#define fNumSS "NUMSS"
#define fNumSS1 "NUMSS1"
#define fNumSS2 "NUMSS2"
#define fNumRes "NUMRES"
#define fNumContacts "NUMCONT"
#define fNumCoils "NUMCOIL"
#define fType "TYPE"
#define fNumber "NUM"
#define fRef "REF"
#define fOrder "ORDER"
#define fICode "ICODE"
#define fName "NAME"
#define fLetter "LETTER"
#define fCenter "CENTER"
#define fPhi "PHI"
#define fPsi "PSI"
#define fOrient1 "ORIENT1"
#define fOrient2 "ORIENT2"
#define fOrient3 "ORIENT3"
#define fFirst "FIRST"
#define fSize "SIZE"
#define fOrientation "ORIENT"
#define fDir "DIR"
#define fSS "SS"
#define fSS1 "SS1"
#define fSS2 "SS2"
#define fRes1 "RES1"
#define fRes2 "RES2"
#define fDistance "DIST"
#define fMinDist "MINDIST"
#define fSquare1 "SQ1"
#define fSquare2 "SQ2"
#define fHSquare1 "HSQ1" 
#define fHSquare2 "HSQ2"
#define fCluster "CLUSTER"
#define fCluster2 "CLUSTER2"
#define fAngle "ANGLE"
#define fLast "LAST"
#define fOffset1 "OFFSET1"
#define fOffset2 "OFFSET2"
#define fContactType "CTYPE"
#define fRecType "RECTYPE"
#define fSize1 "SIZE1"
#define fSize2 "SIZE2"
#define fOrder1 "ORDER1"
#define fOrder2 "ORDER2"
#define fOffset1 "OFFSET1"
#define fOffset2 "OFFSET2"
#define fScheme1 "SCHEME1"
#define fScheme2 "SCHEME2"
#define fValue "VALUE"
#define fStepDistance "SDIST"
#define fStepAngle "SANGLE"
#define fStepOrient "SORIENT"
#define fStepOffset "SOFFSET"
#define fStepCoil "SCOIL"
#define fEnergy "ENERGY"
#define fScheme "SCHEME"
#define fTag "TAG"
#define fUnit "UNIT"
#define fPathway "PATHWAY"
#define fHBond "HBOND"
#define fRHBond "RHBOND"
#define fSeq "SEQ"
#define fCoilDistance "COILDISTANCE"
#define fCoilAngle "COILANGLE"
#define fFlux "FLUX"
#define fAtom "ATOM"

