
#include <stdio.h>
#include <mpi.h>
#include <unistd.h>

struct Block
{
	int f1;
	int f2;
	char data[512];
};

int CurProcess;
int NumNodes;
int BufSize = 640000;

int main( int argc, char **argv )
{
	MPI_Init( &argc, &argv );
	MPI_Comm_rank( MPI_COMM_WORLD, &CurProcess );
	MPI_Comm_size( MPI_COMM_WORLD, &NumNodes );
	void *buf = malloc( BufSize );
	int size = BufSize;
	MPI_Buffer_attach( buf, size );
	
	if ( CurProcess != 0 )
	{
		Block bl;
		bl.f1 = CurProcess;
		for ( int c = 0; c < 512; c++ ) bl.data[c] = c % 128;
		for ( int c = 0; c < 100; c++ )
		{
			bl.f2 = c;
			MPI_Bsend( &bl, sizeof( Block ), MPI_BYTE, 0, 0, MPI_COMM_WORLD );
			if ( c % 5 == 0 ) sleep( 6 );
		}
	}
	else
	{
		bool nload = true;
		MPI_Request req;
		do
		{
			Block bl;
			MPI_Status status;
			if ( nload ) MPI_Irecv( &bl, sizeof( Block ), MPI_BYTE, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &req );
			//MPI_Recv( &bl, sizeof( Block ), MPI_BYTE, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status );
			int flag = 1;
			MPI_Test( &req, &flag, &status );
			//MPI_Wait( &req, &status );
			if ( !flag )
			{
				sleep( 1 );
				nload = false;
				continue;
			}
			nload = true;
			printf( "%d %d\n", status.MPI_SOURCE, bl.f2 );
			fflush( stdout );
			for ( int c = 0; c < 512; c++ ) if ( bl.data[c] != c % 128 ) printf( "error\n" );
		}
		while ( 1 );
	}
	MPI_Buffer_detach( &buf, &size );
	MPI_Finalize();
	return 0;
}
