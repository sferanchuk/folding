
#include "common.h"

static char *tom1_ord = "ARNDCQEGHILKMFPSTWYV";

const int tom1_max = 15;

const int distNum = 500;
const double distFactor = 50;
	
double w[20][tom1_max] = {{0}};
const double energyFactor = 8.31 * 300. / 42000.;
const double eps = 5.;
const double hbondEnergy = 0.3;
double pg = 5;
double ce = energyFactor;
double co = 0;
double hf = hbondEnergy;

/*
void linearize()
{
	for ( int ac = 0; ac < 20; ac++ )
	{
		double s1 = 0, s2 = 0;
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			s1 += cc;
			s2 += w[ac][cc];
		}
		s1 /= tom1_max;
		s2 /= tom1_max;
		double s3 = 0, s4 = 0;
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			s3 += ( cc - s1 ) * ( w[ac][cc] - s2 );
			s4 += ( cc - s1 ) * ( cc - s1 );
		}
		double b = s3 / s4;
		double a = s2 - b * s1;
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			w[ac][cc] = a + b * cc;
		}
	}
}


int check_sol()
{
	if ( lf < 1.8 ) return 0;
	double factor = ( 2. - lf ) / 2.;
	for ( int ac = 0; ac < 20; ac++ )
	{
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			if ( w[ac][cc] == 0 ) continue;
			w[ac][cc] = ( w[ac][cc] - lf ) / factor;
		}
	}
	ef /= factor;
	lf = 0;
}

int conv_nl( const char *iname )
{
	double scale = 10;
	double aaw[20];
	double cw[tom1_max];
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) return 0;
	char buf[80];
	for ( int lc = 0; lc < 10; lc++ ) fgets( buf, 80, ifile );
	int nc = atoi( buf );
	for ( int lc = 0; lc < 2 + nc; lc++ ) fgets( buf, 80, ifile );
	for ( int lc = 0; lc < 20; lc++ ) 
	{
		fgets( buf, 80, ifile );
		aaw[lc] = atof( buf );
	}
	cw[0] = 0;
	for ( int lc = 0; lc < tom1_max - 1; lc++ ) 
	{
		fgets( buf, 80, ifile );
		cw[lc+1] = atof( buf );
	}
	fgets( buf, 80, ifile );
	lf = atof( buf ) / scale;
	fgets( buf, 80, ifile );
	ef = atof( buf ) / distFactor / scale;	
	fclose( ifile );
	for ( int ac = 0; ac < 20; ac++ )
	{
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			w[ ac ][ cc ] = aaw[ac] * cw[ cc ] / scale;
		}
	}
	return 1;
}

int conv_lpsolve( const char *iname )
{
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) return 0;
	char buf[80];
	double scale = 5;
	while ( fgets( buf, 80, ifile ) )
	{
		if ( strncmp( buf, "var", 3 ) != 0 ) continue;
		int order = atoi( buf + 4 );
		double value = atof( buf + 8 );
		if ( order == 0 )
		{
			lf = -value / scale;
			continue;
		}
		if ( order == distNum )
		{
			ef = -value / distFactor / scale;
			continue;
		}
		int aa = ( order - 1 ) / ( tom1_max );
		int nc = ( order - 1 ) % ( tom1_max );
		w[ aa ][ nc + 1 ] = value / scale;
	}
	fclose( ifile );
	check_sol();
	return 1;
}
*/
int conv_lpsolve_lin( const char *iname )
{
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) return 0;
	char buf[80];
	double vars[40] = {0};
	while ( fgets( buf, 80, ifile ) )
	{
		if ( strncmp( buf, "var", 3 ) != 0 ) continue;
		int order = atoi( buf + 4 );
		double value = atof( buf + 8 );
		if ( order == 0 )
		{
			pg = 5. - value;
			continue;
		}
		if ( order == distNum )
		{
			co = value;
			continue;
		}
		if ( order == distNum + 1 )
		{
			hf = value;
			continue;
		}
		vars[ order - 1 ] = value;
	}
	fclose( ifile );
	for ( int ac = 0; ac < 20; ac++ )
	{
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			w[ ac ][ cc ] = vars[ac] + vars[ ac + 20 ] * cc;
		}
	}
	return 1;
}

void save( const char *oname )
{
	FILE *ofile = fopen( oname, "wt" );
	Line l1( rPotGap );
	l1.PutDouble( fValue, pg );
	l1.Write( ofile );
	Line l2( rCoilEnergy );
	l2.PutDouble( fValue, ce );
	l2.Write( ofile );
	Line l3( rCoilOffset );
	l3.PutDouble( fValue, co );
	l3.Write( ofile );
	Line l4( rHBondFactor );
	l4.PutDouble( fValue, hf );
	l4.Write( ofile );
	for ( int ac = 0; ac < 20; ac++ )
	{
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			Line l( rPotential );
			l.PutString( fLetter, string( tom1_ord + ac, 1 ) );
			l.PutInt( fNumContacts, cc );
			l.PutDouble( fValue, w[ ac ][ cc ] );
			l.Write( ofile );
		}
	}
	fclose( ofile );
}

/*
int conv_glpsol( const char *iname )
{
	double scale = 5;
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) return 0;
	char buf[100];
	while ( fgets( buf, 100, ifile ) )
	{
		if ( strncmp( buf + 7, "var", 3 ) != 0 ) continue;
		int order = atoi( buf + 11 );
		double value = atof( buf + 24 );
		if ( order == 0 )
		{
			lf = -value / scale;
			continue;
		}
		if ( order == distNum )
		{
			ef = -value / distFactor / scale;
			continue;
		}
		if ( order == distNum + 1 )
		{
			hf = value / scale;
			continue;
		}
		int aa = ( order - 1 ) / ( tom1_max );
		int nc = ( order - 1 ) % ( tom1_max );
		w[ aa ][ nc + 1 ] = value / scale;
	}
	fclose( ifile );
	return 1;
}

int conv_glpsol_lin( const char *iname )
{
	FILE *ifile = fopen( iname, "rt" );
	if ( !ifile ) return 0;
	char buf[80];
	double scale = 5;
	double vars[40] = {0};
	while ( fgets( buf, 80, ifile ) )
	{
		if ( strncmp( buf + 7, "var", 3 ) != 0 ) continue;
		int order = atoi( buf + 11 );
		double value = atof( buf + 24 );
		if ( order == 0 )
		{
			lf = -value / scale;
			continue;
		}
		if ( order == distNum )
		{
			ef = value / distFactor / scale;
			continue;
		}
		if ( order == distNum + 1 )
		{
			hf = -value / scale;
			continue;
		}
		if ( order == distNum + 2 )
		{
			avg = -value / scale;
			continue;
		}
		vars[ order - 1 ] = value / scale;
	}
	fclose( ifile );
	for ( int ac = 0; ac < 20; ac++ )
	{
		for ( int cc = 0; cc < tom1_max; cc++ )
		{
			w[ ac ][ cc ] = vars[ac] + vars[ ac + 20 ] * cc;
		}
	}
	return 1;
}
*/

struct Input
{
	string iname;
	string oname;
	bool linearize;
	string format;
};

int ParseInput( Input& I, int argc, char **argv )
{
	I.linearize = 0;
	for ( int ac = 1; ac < argc; ac++ )
	{
		if ( ( strcmp( argv[ac], "-i" ) == 0 || strcmp( argv[ac], "--input" ) == 0 ) && ac + 1 < argc )
		{
			I.iname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-o" ) == 0 || strcmp( argv[ac], "--output" ) == 0 ) && ac + 1 < argc )
		{
			I.oname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-f" ) == 0 || strcmp( argv[ac], "--format" ) == 0 ) && ac + 1 < argc )
		{
			I.format = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-l" ) == 0 || strcmp( argv[ac], "--linearize" ) == 0 ) )
		{
			I.linearize = 1;
		}
	}
	if ( !I.iname.size() )
	{
		printf( "No input file\n" );
		return 0;
	}
	if ( I.format != "nl" && I.format != "lpsolve" && I.format != "glpsol" )
	{
		printf( "allowed formats: nl lpsolve glpsol\n" );
		return 0;
	}
	if ( !I.oname.size() )
	{
		I.oname = string( I.iname, 0, I.iname.find( '.' ) ) + ".pot";
	}
	return 1;
}

	

int main( int argc, char **argv )
{
	if ( argc < 4 ) 
	{
		printf( 
			"Usage: sol2pot [-l] -f {nl/lpsolve/glpsol} -i <infile> [-o <outfile>]\n"
		 );
		return 1;
	}
	Input I;
	ParseInput( I, argc, argv );
	//if ( I.format == "nl" && !conv_nl( I.iname.data() )
	if ( I.format == "lpsolve" && !conv_lpsolve_lin( I.iname.data() ) )
	//	|| I.format == "glpsol" && !conv_glpsol_lin( I.iname.data() ) )
	{
		printf( "can't read file\n" );
		return 1;
	}
	//if ( I.linearize ) linearize();
	save( I.oname.data() );
	return 0;
}	