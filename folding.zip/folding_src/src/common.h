
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

#include <vector>
#include <string>
using namespace std;

#include "vector.h"
#include "format.h"

const int TheDepth = 4;
