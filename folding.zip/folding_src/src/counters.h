#include <map>
#include <list>

template <typename Key> struct Comparer
{
	bool operator() ( Key k1, Key k2 )
	{
		int size = sizeof(Key);
		const char *p1 = (const char*)(&k1);
		const char *p2 = (const char*)(&k2);
		for ( int cc = 0; cc < size; cc++ )
		{
			if ( p1[cc] < p2[cc] ) return true;
			if ( p1[cc] > p2[cc] ) return false;
		}
		return false;

	}
};

extern int tagCnt;

struct Counter 
{
	double value;
	int tag;
	Counter() { value = 0; tag = tagCnt++; }
};

template <typename Key> struct Acc
{
	typedef map< Key, Counter, Comparer< Key > > Map;

	Map theMap;
	Counter total;
	typedef typename Map::const_iterator It;
	It it;

	int Count( const Key& key, double value )
	{
		theMap[key].value += value;
		total.value += value;
		return theMap[key].tag;
	}
	void Add( const Key& key, double value, int tag )
	{
		theMap[key].value = value;
		theMap[key].tag = tag;
	}
	void Begin()
	{
		it = theMap.begin();
	}
	bool Next( Key& key, double& value, int& tag )
	{
		if ( it == theMap.end() ) return false;
		key = (*it).first;
		value = (*it).second.value;
		tag = (*it).second.tag;
		it++;
		return true;
	}
	bool Find( const Key& key, double& value, int& tag )
	{
		It it1 = theMap.find( key );
		if ( it1 == theMap.end() ) return false;
		value = (*it1).second.value;
		tag = (*it1).second.tag;
		return true;
	}
};

template <typename Key1, typename Key2> struct PAcc
{
	typedef pair< Key1, Key2 > Pair;
	typedef map< Pair, Counter, Comparer< Pair > > Map;

	Map theMap;
	typedef typename Map::const_iterator It;
	It it;
	
	int Count( const Key1& k1, const Key2& k2, double value )
	{
		Pair p;
		p.first = k1;
		p.second = k2;
		theMap[p].value += value;
		return theMap[p].tag;
	}
	void Add( const Key1& k1, const Key2& k2, double value, int tag )
	{
		Pair p;
		p.first = k1;
		p.second = k2;
		theMap[p].value = value;
		theMap[p].tag = tag;
	}
	double GetValue( const Key1& k1, const Key2& k2 )
	{
		Pair p;
		p.first = k1;
		p.second = k2;
		return theMap[p].value;
	}
	void Begin()
	{
		it = theMap.begin();
	}
	bool Next( Key1& key1, Key2& key2, double& value, int& tag )
	{
		if ( it == theMap.end() ) return false;
		key1 = (*it).first.first;
		key2 = (*it).first.second;
		value = (*it).second.value;
		tag = (*it).second.tag;
		it++;
		return true;
	}
	bool Find( const Key1& k1, const Key2& k2, double& value, int& tag )
	{
		Pair p;
		p.first = k1;
		p.second = k2;
		It it1 = theMap.find( p );
		if ( it1 == theMap.end() ) return false;
		value = (*it1).second.value;
		tag = (*it1).second.tag;
		return true;
	}
};

struct LastCnt
{
	Vector sum;
	double sdist;
	double total;
	LastCnt()
	{
		sdist = 0;
		total = 0;
	}
	void Count( double angle, double dist, double last, double weight )
	{
		Vector v1 = Vector( 1, 0, 0 );
		Vector v2 = Vector( 0, 1, 0 );
		sum = sum + ( v1 * cos( angle ) + v2 * sin( angle ) ) * last * weight;
		sdist += dist * weight;
		total += weight;
	}
};

/*
struct SchCnt
{
	typedef vector<double> VDouble;
	 
	VDouble sum;
	
	void Count( int scheme, int size, double weight )
	{
		for ( int c = 0; c < size; c++ )
		{
			if ( c >= sum.size() )
			{
				sum.resize( c + 1 );
				sum[c] = 0;
			}
			if ( scheme & ( 1 << c ) ) sum[c] += weight;
		}
	}
};
*/

struct SS
{
	int type;
	int size;
};

struct Letter
{
	SS ss;
	int letter;
};

struct Orientation
{
	double dist;
	double angle;
	double orient1;
	double orient2;
	double offset1;
	double offset2;
};

#include "scheme.h"

struct LinkKey
{
	vector<SS> ss;
};

struct LinkEntry
{
	LinkKey key;
	vector <Orientation> o;
	vector<CScheme> scheme;
};

struct Link
{
	LinkEntry f;
	LinkEntry s;
	Orientation o;
	double hbond;
	int tag;
	double weight;
	Link()
	{
		tag = tagCnt++;
		weight = 0;
	}
};

typedef list<Link> LinkList;

struct CompareLinks
{
	bool operator() ( const LinkKey& k1, const LinkKey& k2 )
	{
		if ( k1.ss.size() < k2.ss.size() ) return true;
		if ( k2.ss.size() < k1.ss.size() ) return false;
		for ( int cc = 0; cc < k1.ss.size(); cc++ )
		{
			if ( k1.ss[cc].size < k2.ss[cc].size ) return true;
			if ( k1.ss[cc].size > k2.ss[cc].size ) return false;
			if ( k1.ss[cc].type < k2.ss[cc].type ) return true;
			if ( k1.ss[cc].type > k2.ss[cc].type ) return false;
		}
		return false;
	}
};

typedef pair<LinkKey,LinkKey> LinkPKey;

struct ComparePLinks
{
	bool operator() ( const LinkPKey& k1, const LinkPKey& k2 )
	{
		if ( k1.first.ss.size() < k2.first.ss.size() ) return true;
		if ( k2.first.ss.size() < k1.first.ss.size() ) return false;
		if ( k1.second.ss.size() < k2.second.ss.size() ) return true;
		if ( k2.second.ss.size() < k1.second.ss.size() ) return false;
		for ( int cc = 0; cc < k1.first.ss.size(); cc++ )
		{
			if ( k1.first.ss[cc].size < k2.first.ss[cc].size ) return true;
			if ( k1.first.ss[cc].size > k2.first.ss[cc].size ) return false;
			if ( k1.first.ss[cc].type < k2.first.ss[cc].type ) return true;
			if ( k1.first.ss[cc].type > k2.first.ss[cc].type ) return false;
		}
		for ( int cc = 0; cc < k1.second.ss.size(); cc++ )
		{
			if ( k1.second.ss[cc].size < k2.second.ss[cc].size ) return true;
			if ( k1.second.ss[cc].size > k2.second.ss[cc].size ) return false;
			if ( k1.second.ss[cc].type < k2.second.ss[cc].type ) return true;
			if ( k1.second.ss[cc].type > k2.second.ss[cc].type ) return false;
		}
		return false;
	}
};

struct Coil
{
	int size;
	int distance;
};

struct SSDetail
{
	SS ss;
	int order;
};

struct LastData
{
	double weight;
	double last;
	double dist;
	double angle;
};

struct LastAcc
{
	typedef map< SS, LastCnt, Comparer<SS> > Map;
	
	Map theMap;
	Map::iterator it;
	Counter sum;

	void Count( SS& ss, double angle, double dist, double last, double weight )
	{
		theMap[ss].Count( angle, dist, last, weight );
	}
	void Begin()
	{
		it = theMap.begin();
	}
	bool Next( SS& ss, LastData& l )
	{
		if ( it == theMap.end() ) return false;
		ss = (*it).first;
		LastCnt &cnt = (*it).second;
		l.dist = cnt.sdist / cnt.total;
		l.last = cnt.sum.norm() / cnt.total;
		l.angle = atan2( cnt.sum.y, cnt.sum.x );
		l.weight = cnt.total;
		it++;
		return true;
	}
};

struct SSDetailAcc
{
	typedef map< SSDetail, LastCnt, Comparer<SSDetail> > Map;
	
	Map theMap;
	Map::iterator it;
	Counter sum;

	void Count( SSDetail& ssd, double angle, double dist, double last, double weight )
	{
		theMap[ssd].Count( angle, dist, last, weight );
	}
	void Begin()
	{
		it = theMap.begin();
	}
	bool Next( SSDetail& ssd, double& angle, double& dist, double& last )
	{
		if ( it == theMap.end() ) return false;
		ssd = (*it).first;
		LastCnt &cnt = (*it).second;
		dist = cnt.sdist / cnt.total;
		last = cnt.sum.norm() / cnt.total;
		angle = atan2( cnt.sum.y, cnt.sum.x );
		it++;
		return true;
	}
};


struct SchAcc
{
	struct Value
	{
		CScheme s;
		Counter sum;
		Counter hbond;
	};
	typedef map< SS, Value, Comparer<SS> > Map;
	
	Map theMap;
	Map::iterator it;

	void Count( SS& ss, const CScheme& s, double weight, double hbond )
	{
		Value& v = theMap[ss];
		v.s.add( s );
		v.sum.value += weight;
		v.hbond.value += hbond;
	}
	bool Find( 
		const SS& ss, 
		CScheme& s,
		double& hbond )
	{
		if ( ( it = theMap.find( ss ) ) == theMap.end() ) return false;
		Value value = (*it).second;
		s.resize( value.s.s[0].size() );
		for ( int c = 0; c < 3; c++ )
		{
			for ( int fc = 0; fc < s.s[c].size(); fc++ )
			{
				s.s[c][fc] = value.s.s[c][fc] / value.sum.value;
			}
		}
		hbond = value.hbond.value / value.sum.value;
		return true;
	}
};


struct LinkAcc
{
	typedef map< LinkKey, LinkList, CompareLinks > Map;
	
	Map mapf;
	Map maps;
	map<int, Link*> index;

	void Count( Link& link )
	{
		LinkKey k1 = link.f.key, k2 = link.s.key;
		mapf[k1].push_back( link );
		maps[k2].push_back( link );
		index[link.tag] = &( mapf[k1].back() );
	}
};

struct Space 
{
	Vector beg;
	Vector end;
	Vector orientation;
};

static void unit_position_s( Space& sp, Space& src, Orientation& o, LastData& last )
{
	Vector point1 = src.beg + ( !( src.end - src.beg ) ) * o.offset1;
	Vector dp1 = !( src.orientation );
	Vector dp2 = !( dp1 & ( ( src.beg - src.end ) * o.offset1 ) );
	Vector point2 = point1 + ( dp1 * cos( o.orient1 ) + dp2 * sin( o.orient1 ) ) * o.dist;
	Vector dd1 = !( (src.beg - src.end) * o.offset1 );
	Vector dd2 = !( dd1 & ( ( point1 - point2 ) ) );
	Vector dir2 = !( ( dd1 * cos( o.angle ) + dd2 * sin( o.angle ) ) * o.offset2 );
	sp.beg = point2 + dir2 * o.offset2;
	Vector do1 = !( (point1 - point2) );
	Vector do2 = !( do1 & ( dir2 * ( -o.offset2 ) ) );
	sp.orientation = ( do1 * cos( o.orient2 ) + do2 * sin( o.orient2 ) ) * last.last;
	sp.end = sp.beg + ( !( dir2 * ( -1. ) ) ) * last.dist;
}

static void unit_position_f( Space& sp, Space& src, Orientation& o, LastData& last )
{
	Vector point1 = src.beg + ( !( src.end - src.beg ) ) * o.offset2;
	Vector dp1 = !( src.orientation );
	Vector dp2 = !( dp1 & ( ( src.beg - src.end ) * o.offset2 ) );
	Vector point2 = point1 + ( dp1 * cos( o.orient2 ) + dp2 * sin( o.orient2 ) ) * o.dist;
	Vector dd1 = !( (src.beg - src.end) * o.offset2 );
	Vector dd2 = !( dd1 & ( ( point1 - point2 ) ) );
	Vector dir2 = !( ( dd1 * cos( o.angle ) + dd2 * sin( o.angle ) ) * o.offset1 );
	sp.beg = point2 + dir2 * o.offset1;
	Vector do1 = !( (point1 - point2));
	Vector do2 = !( do1 & ( dir2 * ( -o.offset1 ) ) );
	sp.orientation = ( do1 * cos( o.orient1 ) + do2 * sin( o.orient1 ) ) * last.last;
	sp.end = sp.beg + ( !( dir2 * ( -1. ) ) ) * last.dist;
}

typedef vector<Vector> VVector;


