
#include "common.h"

int Line::Read( FILE *ifile )
{
	int c;
	do
	{
		c = getc( ifile );
		if ( c == '\n' || c == '\r' || c == '<' ) continue;
		if ( c == EOF || c == '>' ) break;
		type.push_back( c );
	}
	while ( 1 );
	if ( type == "/" ) return eEOREC;
	do
	{
		c = getc( ifile );
		if ( c == '\r' || c == '\n' ) continue;
		if ( c == EOF || c == '<' ) break;
		tvalue.push_back( c );
	}
	while ( 1 );
	if ( c == EOF ) return eEOF;
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) return eEOF;
		if ( res == eEOREC ) break;
		if ( !l.field.size() )
		{
			field.push_back( l.type );
			value.push_back( l.tvalue );
		}
		else 
		{
			child.push_back( new Line( l ) );
		}
	}
	while ( 1 );
	return eOK;
}

Line::Line( const Line& l )
{
	type = l.type;
	field = l.field;
	value = l.value;
	for ( int cc = 0; cc < child.size(); cc++ ) delete child[cc];
	child.clear();
	for ( int cc = 0; cc < l.child.size(); cc++ ) child.push_back( new Line( *(l.child[cc]) ) );
}

void Line::operator=( const Line& l )
{
	type = l.type;
	field = l.field;
	value = l.value;
	for ( int cc = 0; cc < child.size(); cc++ ) delete child[cc];
	child.clear();
	for ( int cc = 0; cc < l.child.size(); cc++ ) child.push_back( new Line( *(l.child[cc]) ) );
}

Line::~Line()
{
	for ( int cc = 0; cc < child.size(); cc++ ) delete child[cc];
}

string Line::GetString( const string& f )
{
	for ( int fc = 0; fc < field.size(); fc++ )
	{
		if ( field[fc] == f ) return value[fc];
	}
	return string( "" );
}

Vector Line::GetVector( const string& f )
{
	string s = GetString( f );
	Vector rv;
	sscanf( s.data(), "%lg %lg %lg", &( rv.x ), &( rv.y ), &( rv.z ) );
	return rv;
}

bool Line::GetFirst( Line& l )
{
	if ( !child.size() ) return false;
	cnt = 1;
	l = *(child[0]);
	return true;
}

bool Line::GetNext( Line& l )
{
	if ( cnt >= child.size() ) return false;
	l = *(child[cnt]);
	cnt++;
	return true;
}

void Line::PutString( const string& f, const string& v )
{
	for ( int fc = 0; fc < field.size(); fc++ )
	{
		if ( field[fc] == f ) 
		{
			value[fc] = v;
			return;
		}
	}
	field.push_back( f );
	value.push_back( v );
}

void Line::PutInt( const string& f, int v )
{
	char buf[10];
	sprintf( buf, "%d", v );
	PutString( f, buf );
}

void Line::PutDouble( const string& f, double v )
{
	char buf[20];
	sprintf( buf, "%g", v );
	PutString( f, buf );
}

void Line::PutVector( const string& f, Vector v )
{
	char buf[60];
	sprintf( buf, "%g %g %g", v.x, v.y, v.z );
	PutString( f, buf );
}

void Line::PutLine( const Line& l )
{
	child.push_back( new Line( l ) );
}

int Line::Write( FILE *ofile )
{
	fprintf( ofile, "<%s>", type.data() );
	for ( int fc = 0; fc < field.size(); fc++ )
	{
		fprintf( ofile, "<%s>%s</>", field[fc].data(), value[fc].data() );
	}
	if ( child.size() ) fprintf( ofile, "\n" );
	for ( int cc = 0; cc < child.size(); cc++ ) child[cc]->Write( ofile );
	fprintf( ofile, "</>\n" );
	return 1;
}

