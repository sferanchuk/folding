
#include <set>
#include <algorithm>

#include "common.h"
#include "loopp.cpp"

/*
typedef vector<int> Scheme;


void operator |= ( Scheme& s, const Scheme& sp )
{
	if ( s.size() < sp.size() )
	{
		s.resize( sp.size() );
		zero( s );
	}
	for ( int c = 0; c < s.size(); c++ ) s[c] += sp[c];
}
*/

#include "scheme.h"

typedef Scheme* VScheme;

void zero( Scheme& s )
{
	for ( int c = 0; c < s.size(); c++ ) s[c] = 0;
}

void resize( VScheme s, int n )
{
	for ( int c = 0; c < 3; c++ ) 
	{
		s[c].resize( n );
		zero( s[c] );
	}
}

/*
void add( VScheme s, const VScheme& sp )
{
	for ( int c = 0; c < 3; c++ ) s[c] |= sp[c];
}
*/

int weight( Scheme& s )
{
	int rv = 0;
	for ( int c = 0; c < s.size(); c++ ) rv += int( s[c] );
	return rv;
}

struct SS
{
	int order;
	int first;
	int size;
	int type;
	string seq;
	double nh;
	vector<int> ncont;
	//Scheme scheme[3];
	//Scheme rscheme[3];
	CScheme scheme;
	Vector center;
	Vector orientation;
	Vector dir;
	Vector last;
	vector<Vector> res;
	//vector<int> link;
};

enum { cBeta, cHydr, cCys };

struct Contact
{
	int ss1;
	int ss2;
	int atype;
	int order;
	Scheme s1[3];
	Scheme s2[3];
};


struct Link
{
	set<int> ss[2];
	vector<int> contact;
};

struct Coil
{
	int first;
	int size;
	double distance;
	double angle;
	string seq;
	Vector orientation;
	vector<Vector> res;
};

struct Chain
{
	vector<SS> ss;
	vector<Contact> contact;
	vector<Coil> coil;
	vector<Link> link;
	vector<int> mono;
	string name;
	string letter;
	string seq;
};

const double minSquare = 70; // ~1 kkal/mol

//------------------------------------------------------------------------------

static Contact *find_contact( Chain& chain, int ss1, int ss2, bool add = true )
{
	for ( int cc = 0; cc < chain.contact.size(); cc++ )
	{
		if ( chain.contact[cc].ss1 == ss1
			&& chain.contact[cc].ss2 == ss2 
			|| chain.contact[cc].ss1 == ss2
			&& chain.contact[cc].ss2 == ss1 )
		{
			return &(chain.contact[cc]);
		}
	}
	if ( !add ) return 0;
	int order = chain.contact.size();
	chain.contact.resize( order + 1 );
	Contact& c = chain.contact.back();
	c.ss1 = ss1;
	c.ss2 = ss2;
	c.order = order;
	resize( c.s1, chain.ss[ss1].size );
	resize( c.s2, chain.ss[ss2].size );
	return &( chain.contact.back() );
}

static void get_relvector( RelVector& rv, SS& ss, Vector atom )
{
	Vector point = ss.dir * ( ( ss.dir * ( atom - ss.center ) ) / ss.dir.norm() / ss.dir.norm() );
	rv.dist = ( ss.dir * ( atom - ss.center ) ) / ss.dir.norm();
	rv.last = ( atom - ss.center - point ).norm();
	rv.angle = dihedral_angle( ss.center + ss.orientation, ss.center, ss.center + point, atom );
}

int LoadChain( Chain& chain, char *sname )
{
	FILE *ifile = fopen( sname, "rt" );
	if ( !ifile ) return 0;
	Line ll;
	if ( ll.Read( ifile ) != eOK ) return 0;
	if ( ll.GetType() != rHeader ) return 0;
	int ssize = ll.GetInt( fNumSS );
	chain.ss.resize( ssize );
	int csize = ll.GetInt( fNumCoils );
	chain.coil.resize( csize );
	chain.name = ll.GetString( fName );
	chain.letter = ll.GetString( fLetter );
	chain.seq = ll.GetString( fSeq );
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF || res == eEOREC ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() == rSS )
		{
			int ss = l.GetInt( fOrder );
			if ( ss >= ssize ) return 0;
			chain.ss[ss].order = ss;
			chain.ss[ss].first = l.GetInt( fFirst );
			chain.ss[ss].size = l.GetInt( fSize );
			chain.ss[ss].seq.resize( chain.ss[ss].size );
			chain.ss[ss].res.resize( chain.ss[ss].size );
			chain.ss[ss].ncont.resize( chain.ss[ss].size );
			chain.ss[ss].type = l.GetInt( fType );
			chain.ss[ss].center = l.GetVector( fCenter );
			chain.ss[ss].orientation = l.GetVector( fOrientation );
			chain.ss[ss].dir = l.GetVector( fDir );
			chain.ss[ss].scheme.resize( chain.ss[ss].size );
			//chain.ss[ss].scheme = 0;
		}
		else if ( l.GetType() == rSSDetail )
		{
			int ss = l.GetInt( fRef );
			if ( ss >= ssize ) return 0;
			int num = l.GetInt( fOrder ) - chain.ss[ss].first;
			if ( num >= chain.ss[ss].size ) return 0;
			chain.ss[ss].seq[num] = l.GetString( fLetter )[0];
			chain.ss[ss].ncont[num] = 0;
			get_relvector( chain.ss[ss].scheme.bb[num].atom[0], chain.ss[ss], l.GetVector( "ATOM0" ) );
			get_relvector( chain.ss[ss].scheme.bb[num].atom[1], chain.ss[ss], l.GetVector( "ATOM1" ) );
			get_relvector( chain.ss[ss].scheme.bb[num].atom[2], chain.ss[ss], l.GetVector( "ATOM2" ) );
			get_relvector( chain.ss[ss].scheme.bb[num].atom[3], chain.ss[ss], l.GetVector( "ATOM3" ) );
			chain.ss[ss].res[num] = l.GetVector( "ATOM1" );
			if ( num == chain.ss[ss].size - 1 ) 
				chain.ss[ss].last = l.GetVector( "ATOM1" );
		}
		else if ( l.GetType() == rCoil )
		{
			int cs = l.GetInt( fOrder );
			if ( cs >= csize ) return 0;
			chain.coil[cs].first = l.GetInt( fFirst );
			chain.coil[cs].size = l.GetInt( fSize );
			chain.coil[cs].distance = l.GetDouble( fDistance );
			chain.coil[cs].angle = l.GetDouble( fAngle );
			chain.coil[cs].orientation = l.GetVector( fOrientation );
			chain.coil[cs].seq.resize( chain.coil[cs].size );
			chain.coil[cs].res.resize( chain.coil[cs].size );
		}
		else if ( l.GetType() == rCoilDetail )
		{
			int cs = l.GetInt( fRef );
			if ( cs >= csize ) return 0;
			int num = l.GetInt( fOrder ) - chain.coil[cs].first;
			if ( num >= chain.coil[cs].size ) return 0;
			chain.coil[cs].seq[num] = l.GetString( fLetter )[0];
			chain.coil[cs].res[num] = l.GetVector( fCenter );
		}
		else if ( l.GetType() == rContact )
		{
			int ss1 = l.GetInt( fSS1 );
			int ss2 = l.GetInt( fSS2 );
			int num1 = l.GetInt( fRes1 ) - chain.ss[ss1].first;
			int num2 = l.GetInt( fRes2 ) - chain.ss[ss2].first;
			int type = l.GetInt( fType );
			Contact& c = *( find_contact( chain, ss1, ss2 ) );
			if ( type > 2 ) return 0;
   			c.s1[type][ num1 ]++;
   			c.s2[type][ num2 ]++;
			if ( type == cHydr ) 
			{
				chain.ss[ ss1 ].ncont[ num1 ]++;
				chain.ss[ ss2 ].ncont[ num2 ]++;
			}
		}
		else continue;
	}
	while ( 1 );
	for ( int cc = 0; cc < chain.contact.size(); cc++ )
	{
		Contact& c = chain.contact[cc];
		if ( c.ss1 != c.ss2 ) continue;
		chain.ss[c.ss1].scheme.add( c.s1 );
		chain.ss[c.ss1].scheme.add( c.s2 );
	}
	
	fclose( ifile );
	return 1;
}


struct Cluster
{
	set <int> ss;
	int order;
};

struct Ref
{
	vector<Cluster> cl;
};

int LoadPathway( Chain& chain, Line& ll )
{
	vector<Ref> ref;
	Line l;
	if ( ll.GetFirst( l ) ) do
	{
		if ( l.GetType() != rPWSim ) return 0;
		int order = l.GetInt( fOrder );
		int ccl = l.GetInt( fCluster );
		int type = l.GetInt( fType );
		if ( type == 0 )
		{
			int css = l.GetInt( fNumSS );
			ref.resize( ccl + 1 );
			ref[ccl].cl.resize( 1 );
			ref[ccl].cl[0].ss.insert( css );
			ref[ccl].cl[0].order = order;
			chain.mono.push_back( css );
		}
		else if ( type == 1 )
		{
			int css = l.GetInt( fNumSS );
			Ref& r = ref[ccl];
			int pos = -1;
			for ( int cc = 0; cc < r.cl.size(); )
			{
				Link link;
				Cluster& cl = r.cl[cc];
				int o1 = ( css < (*cl.ss.begin()) ) ? 1 : 0;//( cl.order < cl2.order ) ? 0 : 1;
				int o2 = 1 - o1;
				for ( set<int>::iterator sc = cl.ss.begin(); sc != cl.ss.end(); sc++ )
				{
					Contact *cont = find_contact( chain, css, *sc, false );
					if ( !cont ) continue;
					link.ss[o1].insert( *sc );
					link.contact.push_back( cont->order );
				}
				link.ss[o2].insert( css );
				if ( link.ss[o1].size() )
				{
					/*
					for ( set<int>::iterator si1 = link.ss[0].begin(); si1 != link.ss[0].end(); si1++ ) 
						chain.ss[ *si1 ].link.push_back( chain.link.size() );
					for ( set<int>::iterator si2 = link.ss[1].begin(); si2 != link.ss[1].end(); si2++ ) 
						chain.ss[ *si2 ].link.push_back( chain.link.size() );
					*/
					chain.link.push_back( link );
					if ( pos == -1 )
					{
						pos = cc;
						cl.ss.insert( css );
						cc++;
					}
					else
					{
						r.cl[pos].ss.insert( cl.ss.begin(), cl.ss.end() );
						r.cl.erase( r.cl.begin() + cc );
					}
				}
				else cc++;
			}
			if ( pos == -1 )
			{
				ref[ccl].cl.resize( ref[ccl].cl.size() + 1 );
				ref[ccl].cl.back().ss.insert( css );
				ref[ccl].cl.back().order = order;
				chain.mono.push_back( css );
			}
		}
		else if ( type == 2 )
		{
			int ccl2 = l.GetInt( fCluster2 );
			for ( int cc = 0; cc < ref[ccl].cl.size(); cc++ )
			{
				Cluster& cl = ref[ccl].cl[cc];
				for ( int cc2 = 0; cc2 < ref[ccl2].cl.size(); cc2++ )
				{
					Cluster& cl2 = ref[ccl2].cl[cc2];
					Link link;
					int o1 = 0;//( cl.order < cl2.order ) ? 0 : 1;
					int o2 = 1 - o1;
		  			for ( set<int>::iterator sc = cl.ss.begin(); sc != cl.ss.end(); sc++ )
  					{
						for ( set<int>::iterator scc = cl2.ss.begin(); scc != cl2.ss.end(); scc++ )
						{
							Contact *cont = find_contact( chain, *sc, *scc,  false );
							if ( !cont ) continue;
							link.ss[o1].insert( *sc );
							link.ss[o2].insert( *scc );
							link.contact.push_back( cont->order );
						}
					}	
					if ( link.ss[0].size() ) 
					{
						/*
						for ( set<int>::iterator si1 = link.ss[0].begin(); si1 != link.ss[0].end(); si1++ ) 
							chain.ss[ *si1 ].link.push_back( chain.link.size() );
						for ( set<int>::iterator si2 = link.ss[1].begin(); si2 != link.ss[1].end(); si2++ ) 
							chain.ss[ *si2 ].link.push_back( chain.link.size() );
						*/	
						chain.link.push_back( link );
						cl.ss.insert( cl2.ss.begin(), cl2.ss.end() );
					}
				}
			}
			do
			{
				bool ffm = false;
				for ( int cc = 0; cc < ref[ccl].cl.size(); cc++ )
				{
					bool fm = false;
					for ( int cc1 = 0; cc1 < cc; cc1++ )
					{
						set<int> is;
						set_intersection( 
							ref[ccl].cl[cc1].ss.begin(), 
							ref[ccl].cl[cc1].ss.end(), 
							ref[ccl].cl[cc].ss.begin(), 
							ref[ccl].cl[cc].ss.end(), 
							inserter(is, is.begin() ) 
							);
						if ( !is.empty() )
						{
							ref[ccl].cl[cc1].ss.insert( 
								ref[ccl].cl[cc].ss.begin(), 
								ref[ccl].cl[cc].ss.end() );
							fm = true;
							break;
						}
					}
					if ( fm )
					{
						ref[ccl].cl.erase( ref[ccl].cl.begin() + cc );
						ffm = true;
						break;
					}
				}
				if ( !ffm ) break;
			}
			while ( 1 );
		}
	}
	while ( ll.GetNext( l ) );
	return 1;
}

static double contact_weights( SS& ss )
{
	double rv = 0;
	for ( int sc = 0; sc < ss.seq.size(); sc++ )
	{
		int ord = strchr( tom1_ord, ss.seq[ sc ] ) - tom1_ord;
		rv += tom1[ ord * tom1_max + min( ss.ncont[sc], tom1_max - 1 ) ];
	}
	return rv;
}

#include "distr.cpp"

double SelEnergy( double length, double dist )
{
	dist /= 3.5;

	int il = (int)length - 3;
	if ( il < 0 ) return 0;
	if ( il >= 20 ) il = 20;
	int id = (int)( dist * 2 );
	if ( id >= 40 ) id = 40;
	double v = ldistr[il][id];
	if ( v == 0 ) return 0;

	return ( log( v ) ) * energyFactor;
}

double ChainEnergy( Chain& chain )
{
	double rv = 0;
	for ( int sc = 0; sc < chain.ss.size(); sc++ )
	{
		rv -= contact_weights( chain.ss[sc] );
		if ( sc > 0 ) rv += SelEnergy( chain.ss[sc].first - chain.ss[ sc - 1 ].size - chain.ss[ sc - 1 ].first,
			( chain.ss[sc].res[0] - chain.ss[ sc - 1 ].res.back() ).norm() );
	}
	return rv;
}


static void save_pair( Line& l, SS& ss1, SS& ss2)
{

	Vector center1 = ss1.center;
	Vector center2 = ss2.center;
	Vector dir1 = !( ss1.dir );
	Vector dir2 = !( ss2.dir );
	double t2 = ( ( center1 - center2 ) * ( dir2 - dir1 * ( dir1 * dir2 ) ) 
		/ ( 1. - ( dir1 * dir2 ) * ( dir1 * dir2 ) ) );
	double t1 = t2 * ( dir1 * dir2) - ( center1 - center2 ) * dir1;
	Vector point1 = center1 + dir1 * t1;
	Vector point2 = center2 + dir2 * t2;
	double angle = dihedral_angle( center1, point1, point2, center2 );
	double dist = ( point2 - point1 ).norm();
	double orient1 = dihedral_angle( point2, point1, center1, center1 + ss1.orientation );
	double orient2 = dihedral_angle( point1, point2, center2, center2 + ss2.orientation );

	l.PutDouble( fDistance, dist );
	l.PutDouble( fAngle, angle );
	l.PutDouble( fOrient1, orient1 );
	l.PutDouble( fOrient2, orient2 );
	l.PutDouble( fOffset1, t1 );
	l.PutDouble( fOffset2, t2 );
}

static void calc_scheme( Chain& chain, int cl, vector<CScheme> *sch, int& nh, vector<double> *nh_d )
{
	Link& link = chain.link[cl];
	sch[0].resize( link.ss[0].size() );
	sch[1].resize( link.ss[1].size() );
	nh_d[0].resize( link.ss[0].size() );
	nh_d[1].resize( link.ss[1].size() );
	set<int>::iterator it;
	int cnt;
	nh = 0;
	for ( it = link.ss[0].begin(), cnt = 0; it != link.ss[0].end(); it++, cnt++ )
	{
		nh_d[0][cnt] = 0;
		sch[0][cnt] = chain.ss[*it].scheme; 
		for ( int cc = 0; cc < link.contact.size(); cc++ )
		{
			Contact& cont = chain.contact[ link.contact[cc] ];
			if ( *it == cont.ss1 ) 
			{
				sch[0][cnt].add( cont.s1 );
				nh += weight( cont.s1[ cBeta ] );
				nh_d[0][cnt] += 0.5 * weight( cont.s1[ cBeta ] );
			}
			if ( *it == cont.ss2 ) 
			{
				sch[0][cnt].add( cont.s2 );
				nh += weight( cont.s2[ cBeta ] );
				nh_d[0][cnt] += 0.5 * weight( cont.s2[ cBeta ] );
			}
		}
	}
	for ( it = link.ss[1].begin(), cnt = 0; it != link.ss[1].end(); it++, cnt++ )
	{
		nh_d[1][cnt] = 0;
		sch[1][cnt] = chain.ss[*it].scheme; 
		for ( int cc = 0; cc < link.contact.size(); cc++ )
		{
			Contact& cont = chain.contact[ link.contact[cc] ];
			if ( *it == cont.ss1 ) 
			{
				sch[1][cnt].add( cont.s1 );
				nh += weight( cont.s1[ cBeta ] );
				nh_d[1][cnt] += 0.5 * weight( cont.s1[ cBeta ] );
			}
			if ( *it == cont.ss2 ) 
			{
				sch[1][cnt].add( cont.s2 );
				nh += weight( cont.s1[ cBeta ] );
				nh_d[1][cnt] += 0.5 * weight( cont.s2[ cBeta ] );
			}
		}
	}
}

static void save_scheme( CScheme& scheme, int ss, Line &owner, int side = 2 )
{
	for ( int type = 0; type < 3; type++ )
	{
		for ( int order = 0; order < scheme.s[type].size(); order++ )
		{
			//if ( !rscheme && !scheme[type][order] ) continue;
			Line l( rScheme );
			l.PutInt( fSS, ss );
			l.PutInt( fOrder, order );
			l.PutInt( fType, type );
			l.PutInt( fRecType, side );
			l.PutInt( fValue, int( scheme.s[type][order] ) );
			owner.PutLine( l );
		}
	}
	for ( int order = 0; order < scheme.bb.size(); order++ )
	{
		for ( int atom = 0; atom < 4; atom++ )
		{
			//if ( !rscheme && !scheme[type][order] ) continue;
			Line l( rBackbone );
			l.PutInt( fSS, ss );
			l.PutInt( fOrder, order );
			l.PutInt( fAtom, atom );
			l.PutInt( fRecType, side );
			l.PutDouble( fDistance, scheme.bb[order].atom[atom].dist );
			l.PutDouble( fAngle, scheme.bb[order].atom[atom].angle );
			l.PutDouble( fLast, scheme.bb[order].atom[atom].last );
			owner.PutLine( l );
		}
	}
}
				
static void save_link( Chain& chain, int cl, double value, Line& lseq )
{
	Link& link = chain.link[cl];
	
	vector<CScheme> sch[2];
	int nh;
	vector<double> nh_d[2];
	calc_scheme( chain, cl, sch, nh, nh_d );
	
	set<int>::iterator it = link.ss[0].begin();
	int ss0 = *it;
	Line ll( rLink );
	ll.PutInt( fNumSS1, link.ss[0].size() );
	ll.PutInt( fNumSS2, link.ss[1].size() );
	ll.PutInt( fHBond, nh / 2 );
	ll.PutDouble( fValue, value );
	int first = chain.seq.size();
	int last = 0;
	int cnt = 0;
	double rnh = 0;
	Vector prevRes;
	Vector prevDir;
	for ( ; it != link.ss[0].end(); it++, cnt++ )
	{
		int css = *it;
		Line l( rLinkDetail );
		l.PutInt( fRecType, 0 );
		l.PutInt( fOrder, cnt );
		l.PutInt( fSize, chain.ss[css].size );
		l.PutInt( fType, chain.ss[css].type );
		l.PutInt( fFirst, chain.ss[css].first );
		if ( cnt != 0 ) 
		{
			l.PutDouble( fCoilDistance, ( chain.ss[css].res[0] - prevRes ).norm() );
			l.PutDouble( fCoilAngle, acos( ( chain.ss[css].dir * prevDir ) / chain.ss[css].dir.norm() ) );
			save_pair( l, chain.ss[ss0], chain.ss[css] );
		}
		ll.PutLine( l );
		//add( chain.ss[css].rscheme, &(sch[0][0]) + cnt * 3 );
		chain.ss[css].nh += nh_d[0][cnt];
		rnh += chain.ss[css].nh;
		save_scheme( sch[0][cnt], cnt, ll, 0 );
		first = min( first, chain.ss[css].first );
		last  = max( last, chain.ss[css].first + chain.ss[css].size );
		prevRes = chain.ss[css].res.back();
		prevDir = chain.ss[css].dir * ( 1. / chain.ss[css].dir.norm() );
	}
	it = link.ss[1].begin();
	int ss1 = *it;
	cnt = 0;
	for ( ; it != link.ss[1].end(); it++, cnt++ )
	{
		int css = *it;
		Line l( rLinkDetail );
		l.PutInt( fRecType, 1 );
		l.PutInt( fOrder, cnt );
		l.PutInt( fSize, chain.ss[css].size );
		l.PutInt( fType, chain.ss[css].type );
		l.PutInt( fFirst, chain.ss[css].first );
		//l.PutInt( fScheme, sch[1][cnt] );
		l.PutDouble( fCoilDistance, ( chain.ss[css].res[0] - prevRes ).norm() );
		l.PutDouble( fCoilAngle, acos( ( chain.ss[css].dir * prevDir ) / chain.ss[css].dir.norm() ) );
		if ( cnt == 0 ) save_pair( l, chain.ss[ss0], chain.ss[ss1] );
		else save_pair( l, chain.ss[ss1], chain.ss[css] );
		ll.PutLine( l );
		//add( chain.ss[css].rscheme, &(sch[1][0]) + cnt * 3 );
		chain.ss[css].nh += nh_d[1][cnt];
		rnh += chain.ss[css].nh;
		save_scheme( sch[1][cnt], cnt, ll, 1 );
		first = min( first, chain.ss[css].first );
		last  = max( last, chain.ss[css].first + chain.ss[css].size );
		prevRes = chain.ss[css].res.back();
		prevDir = chain.ss[css].dir * ( 1. / chain.ss[css].dir.norm() );
	}
	ll.PutInt( fFirst, first );
	ll.PutInt( fLast, last );
	ll.PutDouble( fRHBond, rnh );
	lseq.PutLine( ll );
}

static void save_mono( Chain& chain, int css, double value, Line& lseq )
{
	SS &ss = chain.ss[css];
	Line l( rMono );
	l.PutInt( fType, ss.type );
	l.PutInt( fSize, ss.size );
	l.PutDouble( fValue, value );
	lseq.PutLine( l );
}

static void save_ss( Chain& chain, int css, Line& lseq )
{
	SS &ss = chain.ss[css];
	Line ll( rSS );
	ll.PutInt( fType, ss.type );
	ll.PutInt( fSize, ss.size );
	ss.nh =  weight( ss.scheme.s[cBeta] );
	ll.PutInt( fHBond, int( ss.nh ) );
	//l.PutInt( fOrder, 0 );
	ll.PutDouble( fDir, ss.dir.norm() );
	ll.PutDouble( fOrientation, dihedral_angle( ss.center + ss.orientation, ss.center, ss.center + ss.dir, ss.last ) );
	ll.PutDouble( fLast, ( ss.last - ss.center - ss.dir ).norm() );
	for ( int lc = 0; lc < ss.size; lc++ )
	{
   		Line l( rLetter );
   		l.PutInt( fRecType, 1 );
   		l.PutString( fLetter, string( &(ss.seq[lc]), 1 ) );
   		l.PutInt( fSize, ss.size );
   		l.PutInt( fType, ss.type );
   		ll.PutLine( l );
		/*
		for ( int sc = 0; sc < ss.scheme.size(); sc++ )
		{
			if ( ss.scheme[sc] & ( 1 << lc ) )
			{
				Line l( rLetter );
				l.PutInt( fRecType, 2 );
				l.PutString( fLetter, string( &(ss.seq[lc]), 1 ) );
				l.PutInt( fSize, ss.size );
				l.PutInt( fType, ss.type );
				l.Write( ofile );
			}
		}
		*/
   	}
	for ( int lc = 0; lc < ss.size; lc++ )
	{
   		Line l( rSSDetail );
   		l.PutInt( fSize, ss.size );
   		l.PutInt( fType, ss.type );
   		l.PutInt( fOrder, lc );
   		double dist = ( ss.res[lc] - ss.center ) * ( !ss.dir );
   		Vector base = ss.center + (!ss.dir ) * dist;
   		double angle = dihedral_angle( ss.center + ss.orientation, ss.center, base, ss.res[lc] );
   		double ori = ( ss.res[lc] - base ).norm();
   		l.PutDouble( fCenter, dist );
   		l.PutDouble( fAngle, angle );
   		l.PutDouble( fOrientation, ori );
   		ll.PutLine( l );
   	}
	save_scheme( ss.scheme, css, ll );
	lseq.PutLine( ll );
}

static void save_coil( Chain& chain, int cc, Line& lseq )
{
	Coil& coil = chain.coil[cc];
	Line ll( rCoil );
	ll.PutInt( fSize, coil.size );
	ll.PutDouble( fDistance, coil.distance );
	for ( int lc = 0; lc < coil.size; lc++ )
	{
   		Line l( rLetter );
   		l.PutInt( fRecType, 0 );
   		l.PutString( fLetter, string( &(coil.seq[lc]), 1 ) );
   		l.PutInt( fSize, coil.size );
   		ll.PutLine( l );
    }
    if ( coil.size > 2 )
    {
    	Vector center = coil.res[0];
    	Vector dir = !( coil.res[ coil.size - 1 ] - center );
    	for ( int lc = 0; lc < coil.size; lc++ )
    	{
       		Line l( rCoilDetail );
       		l.PutInt( fSize, coil.size );
       		l.PutDouble( fDistance, coil.distance );
       		l.PutDouble( fAngle, coil.angle );
     		double dist = ( coil.res[lc] - center ) * dir;
     		Vector base =  center + dir * dist;
     		double angle = dihedral_angle( center + coil.orientation, center, base, coil.res[lc] );
     		double ori = ( coil.res[lc] - base ).norm();
     		l.PutDouble( fCenter, dist );
     		//l.PutDouble( fAngle, angle );
     		l.PutDouble( fOrientation, ori );
     		ll.PutLine( l );
        }
    }
	lseq.PutLine( ll );
}

int main( int argc, char **argv )
{
	if ( argc < 4 ) return 1;
	Chain chain;
	if ( !LoadChain( chain, argv[1] ) ) return 1;
	FILE *ofile = fopen( argv[3], "at" );
	if ( !ofile )
	{
		ofile = fopen( argv[3], "wt" );
	}
	Line lseq( "CHAIN" );
	Line l( rHeader );
	l.PutString( fName, chain.name );
	l.PutString( fLetter, chain.letter );
	l.PutString( fSeq, chain.seq );
	lseq.PutLine( l );
	for ( int sc = 0; sc < chain.ss.size(); sc++ )
	{
		save_ss( chain, sc, lseq );
	}
	for ( int cc = 0; cc < chain.coil.size(); cc++ )
	{
		save_coil( chain, cc, lseq );
	}
	int ps;
	FILE *pfile = fopen( argv[2], "rt" );
	do
	{
		Line ll;
		int res = ll.Read( pfile );
		if ( res == eEOF ) break;
		if ( res != eOK ) return 1;
		if ( !( ps = LoadPathway( chain, ll ) ) ) return 1;
		double value = ll.GetDouble( fValue );
		if ( value == 0 ) value = 1;
		/*
		for ( int sc = 0; sc < chain.ss.size(); sc++ )
		{
			resize( chain.ss[sc].rscheme, chain.ss[sc].size );
			add( chain.ss[sc].rscheme, chain.ss[sc].scheme );
		}
		*/
		double tw = ChainEnergy( chain );
		for ( int sc = 0; sc < chain.mono.size(); sc++ )
		{
			save_mono( chain, chain.mono[sc], value, lseq );
		}
		for ( int cc = 0; cc < chain.link.size(); cc++ )
		{
			save_link( chain, cc, value, lseq );
		}
		chain.mono.clear();
		chain.link.clear();
	}
	while( 1 );
	lseq.Write( ofile );
	fclose( ofile );
	fclose( pfile );
	return 0;
}


