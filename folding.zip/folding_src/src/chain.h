
struct Atom
{
	Vector coord;
	int number;
	char name[5];
};

enum { aN, aCA, aC, aO };

struct Residue
{
	vector<Atom> atom;
	Vector center;
	int number;
	char icode;
	char name3[5];
	char name1;
	int order;
	int sstype;
	int rotamer;
	double freq;
};

struct Chain
{
	vector<Residue> residue;
};

struct RotResidue
{
	vector<Residue> r;
	int nr;
	double surface;
};

struct RotChain
{
	vector<RotResidue> residue;
};
