
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};


const int pdbLineSize = 100;

struct pdbLine
{
	char s[ pdbLineSize ];

	char *lineType() { return s; }
	char *atomNumber() { return s + 7; }
	char *atomType() { return s + 13; }
	char *chainName() { return s + 21; }
	char *aaNumber() { return s + 23; }
	char *aaName() { return s + 17; }
	char *x() { return s + 31; }
	char *y() { return s + 39; }
	char *z() { return s + 47; }
};

inline double sqr( double x ) { return x * x; }

int main( int argc, char **argv )
{
	double maxRad[26] = { 0 };
	FILE *ifile = fopen( argv[1], "rt" );
	if ( !ifile ) 
	{
		printf( "can't open pdb file\n" );
		return 1;
	}

	pdbLine line;
	int cc = 0;

	double cx, cy, cz;
	while ( fgets( line.s, pdbLineSize, ifile ) )
	{
		if ( strncmp( line.lineType(), "ATOM", 4 ) != 0 ) 
		{
			continue;
		}
		if ( strncmp( line.atomType(), "N ", 2 ) == 0 ) 
		{
			continue;
		}
		if ( strncmp( line.atomType(), "CA", 2 ) == 0 ) 
		{
			cx = atof( line.x() );
			cy = atof( line.y() );
			cz = atof( line.z() );
			continue;
		}
		int letter = -1;
		for ( int ac = 0; ac < 26; ac++ )
		{
			if ( strncmp( a_name[ac], line.aaName(), 3 ) == 0 )
			{
        		letter = ac;
        		break;
        	}
        }
		if ( letter == -1 ) continue;
		double dist = sqrt( sqr( atof( line.x() ) - cx ) 
			+ sqr( atof( line.y() ) - cy ) 
			+ sqr( atof( line.z() ) - cz ) );
		if ( dist > maxRad[ letter ] ) maxRad[letter] = dist;
	}
	fclose( ifile );
	printf( "double resRad[26] = { " );
	for ( int lc = 0; lc < 26; lc++ )
	{
		printf( "%10.1f", maxRad[lc] );
		if ( lc < 25 ) printf( "," );
	}
	printf( "};\n" );
	return 0;
}
