/* adapted from SDL by s.f.
*/


#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <execinfo.h>
#include <unistd.h>

#ifdef __CYGWIN__
#define DISABLE_STDIO
#endif

#define SIGBUS 7
#define SIGTERM 15

char ParachuteMsg[50000] = "";

static void print_msg(const char *text)
{
#ifndef DISABLE_STDIO
	fprintf(stderr, "%s\n", text);
#endif
}

void UninstallParachute(void);

static void Parachute(int sig)
{
    signal( sig, SIG_DFL );
	switch (sig) {
		case SIGSEGV:
			print_msg("Segmentation Fault");
			break;
#ifdef SIGBUS
#if SIGBUS != SIGSEGV
		case SIGBUS:
			print_msg("Bus Error");
			break;
#endif
#endif /* SIGBUS */
#ifdef SIGFPE
		case SIGFPE:
			print_msg("Floating Point Exception");
			break;
#endif /* SIGFPE */
#ifdef SIGQUIT
		case SIGQUIT:
			print_msg("Keyboard Quit");
			break;
#endif /* SIGQUIT */
#ifdef SIGPIPE
		case SIGPIPE:
			print_msg("Broken Pipe");
			break;
#endif /* SIGPIPE */
#ifdef SIGTERM
		case SIGTERM:
			print_msg("Terminate");
			break;
#endif /* SIGTERM */
		default:
#ifndef DISABLE_STDIO
			fprintf(stderr, "# %d", sig);
#endif
			break;
	}
	print_msg( ParachuteMsg );
	void *symbols[ 100 ];
	int res = backtrace( symbols, 100 );
	backtrace_symbols_fd( symbols, res, fileno( stderr ) );
	UninstallParachute();
	exit(-sig);
}

static int fatal_signals[] = {
	SIGSEGV,
#ifdef SIGBUS
	SIGBUS,
#endif
#ifdef SIGFPE
	SIGFPE,
#endif
#ifdef SIGQUIT
	SIGQUIT,
#endif
	SIGTERM,
	0
};

void InitParachute(void)
{
	/* Set a handler for any fatal signal not already handled */
	int i;
/*
#ifdef HAVE_SIGACTION
	struct sigaction action;

	for ( i=0; SDL_fatal_signals[i]; ++i ) {
		sigaction(fatal_signals[i], NULL, &action);
		if ( action.sa_handler == SIG_DFL ) {
			action.sa_handler = Parachute;
			sigaction(SDL_fatal_signals[i], &action, NULL);
		}
	}
#ifdef SIGALRM
	sigaction(SIGALRM, NULL, &action);
	if ( action.sa_handler == SIG_DFL ) {
		action.sa_handler = SIG_IGN;
		sigaction(SIGALRM, &action, NULL);
	}
#endif
#else
	void (*ohandler)(int);

	for ( i=0; fatal_signals[i]; ++i ) {
		ohandler = signal(fatal_signals[i], Parachute);
		if ( ohandler != SIG_DFL ) {
			signal(fatal_signals[i], ohandler);
		}
	}
#endif 
*/
	for ( i=0; fatal_signals[i]; ++i ) {
		//ohandler = 
		signal(fatal_signals[i], Parachute);
		/*
		if ( ohandler != SIG_DFL ) {
			signal(fatal_signals[i], ohandler);
		}
		*/
	}
	return;
}

void UninstallParachute(void)
{
	/* Remove a handler for any fatal signal handled */
	int i;
#ifdef HAVE_SIGACTION
	struct sigaction action;

	for ( i=0; fatal_signals[i]; ++i ) {
		sigaction(fatal_signals[i], NULL, &action);
		if ( action.sa_handler == Parachute ) {
			action.sa_handler = SIG_DFL;
			sigaction(fatal_signals[i], &action, NULL);
		}
	}
#else
	void (*ohandler)(int);

	for ( i=0; fatal_signals[i]; ++i ) {
		ohandler = signal(fatal_signals[i], SIG_DFL);
		if ( ohandler != Parachute ) {
			signal(fatal_signals[i], ohandler);
		}
	}
#endif /* HAVE_SIGACTION */
}


