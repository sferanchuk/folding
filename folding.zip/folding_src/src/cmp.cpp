
#include "common.h"

#include "geom-f.h"
//#include "geom.h"

//#include "rmsdd.cpp"

static char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};

/*
const int wmax = 100000;
const double temperature = 3;
const int tNode = 10;

struct TreeNode
{
	int number;
	int type;
	int pos;
	int length;
	int weight;
	int c[3];
	int nc;
	Vector first;
	Vector last;
};

struct Pathway
{
    int psize;
    int tsize;
    int maxn;
	vector< Node > node;
};

struct Pair
{
    int n1;
    int n2;
};

struct Path
{
    vector< Pair > p;
    int energy;
    int length;
    double measure;
};
*/

struct CSS
{
	int order;
	int first;
	int size;
	int type;
	string seq;
	int scheme;
	Vector center;
	Vector orientation;
	Vector dir;
	vector<Vector> res;
};

enum { cBeta, cHydr, cCys };

struct NSS 
{
	int beg;
	int size;
	int type;
	int order;
};

struct NSpace 
{
	Vector beg;
	Vector end;
	Vector orientation;
};

struct Unit
{
	NSS ss;
	NSpace sp;
};

struct Cluster
{
	vector<Unit> unit;
};

struct Prediction
{
	string seq;
	vector<Cluster> cluster;
};


struct PChain
{
	vector<CSS> ss;
	Prediction p;
};

struct PResidue
{
	Vector coord;
	int order;
	PResidue( Vector v, int o ) { coord = v; order = o; }
};

typedef vector<PResidue> VRes;

/*
Path ***sol;


int rec_energy( Pathway& p, int n )
{
    if ( p.node[n].type == 1 ) return p.node[n].length - 4;
    else if ( p.node[n].type == 5 ) return p.node[n].length - 5;
    else if ( p.node[n].type == 0 ) return 0;
    else if ( p.node[n].type == tNode ) 
    {
		int rv = p.node[n].weight;
		for ( int c = 0; c < p.node[n].nc; c++ ) 
		{
	    	if ( rv >= wmax ) return rv;
	    	rv += rec_energy( p, p.ÄÊnode[n].c[c] );
		}
		return rv;
    }
	return 0;    
}

int length( Pathway& p1, Pathway& p2, Path *p )
{
	int nb1 = p->p.back().n1;
	int nb2 = p->p.back().n2;
	int l1 = p1.node[ nb1 ].pos + p1.node[ nb1 ].length - p1.node[ p->p[0].n1 ].pos;
	int l2 = p2.node[ nb2 ].pos + p1.node[ nb2 ].length - p1.node[ p->p[0].n2 ].pos;
	return ( l1 + l2 ) / 2;
}
*/

/*

double wfunc( double w, double param = 20 )
{
	return param * ( 1 - exp( -w / param ) );
}

double pfunc( double w1, double w2 )
{
	double diff = w1 - w2;
	if ( diff < 0 ) diff = -diff;
	return wfunc( ( w1 + w2 ) / 2 ) - wfunc( diff, 10 );
}
*/

/*
double rec_compare( Pathway& p1, Pathway& p2, int n1, int n2, Path &res )
{
	if ( sol[n1][n2] )
	{
		Path *b = sol[n1][n2];
	    for ( int pc = 0; pc < b->p.size(); pc++ ) 
			res.p.push_back( b->p[pc] );
		return b->measure;
	}

    int rv = 0;
    int t1 = p1.node[n1].type; 
    int t2 = p2.node[n2].type;
    if ( t1 < tNode )
    {
		if ( t2 < tNode2 )
		{
	    	res.p.resize( res.p.size() + 1 );
	    	res.p.back().n1 = n1;
	    	res.p.back().n2 = n2;
			if ( t1 != t2 ) res.measure = -wfunc( (p1.node[n1].length + p2.node[n2].length) / 2 );
			else res.measure = pfunc( p1.node[n1].length, p2.node[n2].length );
	    	sol[n1][n2] = new Path( res );
	    	return res.measure;
		}
    }
    Path *best = 0;
    double wbest = -1000;
    if ( t2 >= tNode )
    {
		for ( int c1 = 0; c1 < p2.node[n2].nc; c1++ )
		{
	    	Path *cp = new Path;
	    	double w = rec_compare( p1, p2, n1, p2.node[n2].c[c1], *cp );// + p2.node[n2].weight;
	    	for ( int c2 = 0; c2 < p2.node[n2].nc; c2++ )
	    	{
				if ( c1 == c2 ) continue;
				w -= wfunc( rec_energy( p2, p2.node[n2].c[c2] ) );
	    	}
	    	cp->length = length( p1, p2, cp );
	    	if ( w > wbest )
	    	{
				wbest = w;
				delete best;
				best = cp;
				best->measure = w;
	    	}
	    	else delete cp;
		}
    }
    if ( t1 >= tNode )
    {
		for ( int c1 = 0; c1 < p1.node[n1].nc; c1++ )
		{
	    	Path *cp = new Path;
	    	double w = rec_compare( p1, p2, p1.node[n1].c[c1], n2, *cp );// + p1.node[n1].weight;
	    	for ( int c2 = 0; c2 < p1.node[n1].nc; c2++ )
	    	{
				if ( c1 == c2 ) continue;
				w -= wfunc( rec_energy( p1, p1.node[n1].c[c2] ) );
	    	}
	    	cp->length = length( p1, p2, cp );
	    	if ( w > wbest )
	    	{
				wbest = w;
				delete best;
				best = cp;
				best->measure = w;
	    	}
	    	else delete cp;
		}
    }
    if ( t1 >= tNode && t2 >= tNode )
    {
		Path *cp = new Path;
		double w = rec_compare( p1, p2, p1.node[n1].c[0], p2.node[n2].c[0], *cp );
		Path *cpp = new Path;
		double ww = rec_compare( p1, p2, 
	    	p1.node[n1].c[p1.node[n1].nc-1], 
	    	p2.node[n2].c[p2.node[n2].nc-1], *cpp );
   		for ( int pc = 0; pc < cpp->p.size(); pc++ ) 
       		cp->p.push_back( cpp->p[pc] );
    	w += ww;

		delete cpp;	
    	cp->length = length( p1, p2, cp );
    	if ( w > wbest )
		{
	    	wbest = w;
	    	delete best;
	    	best = cp;
	    	best->measure = w;
		}
		else delete cp;
    }
    sol[n1][n2] = best;
   	for ( int pc = 0; pc < best->p.size(); pc++ ) 
	res.p.push_back( best->p[pc] );
    return best->measure;
}	
*/

/*    
double **rmsd;

double mean_rmsd = 16;

double nconst = 15;

double calc_rmsd( Pathway& p1, Pathway &p2, Path *p )
{
	int n = p->p.size();
	Vector *v1 = new Vector[ 2 * n ];
	Vector *v2 = new Vector[ 2 * n ];
	int cn = 0;
	double rv = 0;
	for ( int i = 0; i < n; i++ )
	{
		if ( p1.node[ p->p[i].n1 ].type >= tNode ) continue;
		if ( p1.node[ p->p[i].n1 ].type != p2.node[ p->p[i].n2 ].type )
		{
			rv -= -wfunc( (p1.node[ p->p[i].n1 ].length + p2.node[ p->p[i].n2 ].length) / 2 ) / nconst;
		}
		else 
		{
			rv -= pfunc( p1.node[ p->p[i].n1 ].length, p2.node[ p->p[i].n2 ].length ) / nconst;
		}
		v1[cn] = p1.node[ p->p[i].n1 ].first;
		v2[cn] = p2.node[ p->p[i].n2 ].first;
		cn++;
		v1[cn] = p1.node[ p->p[i].n1 ].last;
		v2[cn] = p2.node[ p->p[i].n2 ].last;
		cn++;
	}
	if ( cn <= 2 ) return rv;
	double res = FindRmsd( cn, v1, v2 );
	delete v1;
	delete v2;
	doubple rmsd = res * res;
	int num = ( cn >= 10 ) ? 5 : cn - 4;
	int ord = ( rmsd >= 150 ) ? 29: rmsd / 5;
	double value = ( num >= 0 ) ? rmsdd[ num ][ ord ] : 0;
	if ( value == 0 ) return -cn + rv;
	return log( value ) + rv;

}

double rec_compare( Pathway& p1, Pathway& p2, int n1, int n2, Path &res )
{
	if ( sol[n1][n2] )
	{
		Path *b = sol[n1][n2];
	    for ( int pc = 0; pc < b->p.size(); pc++ )
			res.p.push_back( b->p[pc] );
		return b->measure;
	}

    double rv = 0;
    int t1 = p1.node[n1].type;
    int t2 = p2.node[n2].type;
    if ( t1 < tNode )
    {
		if ( t2 < tNode2 )
		{
	    	res.p.resize( res.p.size() + 1 );
	    	res.p.back().n1 = n1;
	    	res.p.back().n2 = n2;
			if ( t1 != t2 ) res.measure = wfunc( (p1.node[n1].length + p2.node[n2].length) / 2 );
			else res.measure = -pfunc( p1.node[n1].length, p2.node[n2].length );
	    	return res.measure;
		}
    }
    Path *best = 0;
    double wbest = 10000;
    if ( t2 >= tNode2 )
    {
		for ( int c1 = 0; c1 < p2.node[n2].nc; c1++ )
		{
	    	Path *cp = new Path;
	    	double w = rec_compare( p1, p2, n1, p2.node[n2].c[c1], *cp );
	    	for ( int c2 = 0; c2 < p2.node[n2].nc; c2++ )
	    	{
				if ( c1 == c2 ) continue;
				w += wfunc( rec_energy( p2, p2.node[n2].c[c2] ) );
	    	}
	    	if ( w < wbest )
	    	{
				wbest = w;
				delete best;
				best = cp;
	    	}
	    	else delete cp;
		}
    }
    if ( t1 >= tNode )
    {
		for ( int c1 = 0; c1 < p1.node[n1].nc; c1++ )
		{
	    	Path *cp = new Path;
	    	double w = rec_compare( p1, p2, p1.node[n1].c[c1], n2, *cp );
	    	for ( int c2 = 0; c2 < p1.node[n1].nc; c2++ )
	    	{
				if ( c1 == c2 ) continue;
				w += wfunc( rec_energy( p1, p1.node[n1].c[c2] ) );
	    	}
	    	if ( w < wbest )
	    	{
				wbest = w;
				delete best;
				best = cp;
	    	}
	    	else delete cp;
		}
    }
    if ( t1 >= tNode && t2 >= tNode )
    {
		Path *cp = new Path;
		double w = rec_compare( p1, p2, p1.node[n1].c[0], p2.node[n2].c[0], *cp );

		Path *cpp = new Path;
		double ww = rec_compare( p1, p2,
	    	p1.node[n1].c[p1.node[n1].nc-1],
	    	p2.node[n2].c[p2.node[n2].nc-1], *cpp );

   		for ( int pc = 0; pc < cpp->p.size(); pc++ )
       		cp->p.push_back( cpp->p[pc] );

		delete cpp;
		double measure = calc_rmsd( p1, p2, cp );
		w = nconst * measure;
	    if ( w < wbest )
		{
	    	wbest = w;
	    	delete best;
	    	best = cp;
		}
		else delete cp;
    }
    if ( !best ) best = new Path;
    best->measure = wbest;
    sol[n1][n2] = best;
   	for ( int pc = 0; pc < best->p.size(); pc++ )
		res.p.push_back( best->p[pc] );
    return wbest;
}


int LoadPathway( Pathway& p, Chain& chain, char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return 0;
	vector<Node>& input = p.node;
	char buf[80];
	p.tsize = p.psize = 0;
	p.maxn = 0;
	int maxp = 0;

	while ( fgets( buf, 80, ifile ) )
	{
		Node ni;
		if ( strncmp( buf, "Sheet", 5 ) == 0 )
		{
			ni.type = tSheet;
			int tt;
			sscanf( buf + 6, "%d %d %d %d %lg %lg %lg %lg %lg %lg", 
				&(ni.number), &(ni.pos), &(ni.length), &tt,
				&(ni.first.x), &(ni.first.y), &(ni.first.z),
				&(ni.last.x), &(ni.last.y), &(ni.last.z) );
			ni.number = atoi( buf + 6 );
			p.tsize++;
			p.psize++;
		}
		else if ( strncmp( buf, "Helix", 5 ) == 0 )
		{
			if ( strncmp( buf, "Helix3", 6 ) == 0 ) ni.type = tHelix3;
			else if ( strncmp( buf, "Helix4", 6 ) == 0 ) ni.type = tHelix4;
			else if ( strncmp( buf, "Helix5", 6 ) == 0 ) ni.type = tHelix5;
			//ni.type = tHelix4;
			int tt;

			sscanf( buf + 7, "%d %d %d %d %lg %lg %lg %lg %lg %lg", &(ni.number), &(ni.pos), &(ni.length), &tt,
				&(ni.first.x), &(ni.first.y), &(ni.first.z),
				&(ni.last.x), &(ni.last.y), &(ni.last.z) );
			p.tsize++;
			p.psize++;
		}
		else if ( strncmp( buf, "Node2", 5 ) == 0 )
		{
			ni.type = tNode2;
			ni.weight = 0;
			int ctype;
			sscanf( buf + 6, "%d %d %d %d", &ctype, &(ni.number), 
				&(ni.c[0]), &(ni.c[1]) );
			ni.nc = 2;
			if ( ctype == 2 ) ni.type = tNode2C;
			p.tsize++;
		}
		else if ( strncmp( buf, "Node3", 5 ) == 0 )
		{
			ni.weight = 0;
			ni.type = tNode3;
			sscanf( buf + 8, "%d %d %d %d", &(ni.number), 
			&(ni.c[0]), &(ni.c[2]), &(ni.c[1]) );
			ni.nc = 3;
			p.tsize++;
		}
   		else if ( strncmp( buf, "Feature", 7 ) == 0 )
		{
			int type;
			int nn;
			int c1;
			int c2;
			int weight;
			sscanf( buf + 8, "%d %d %d %d %d", &type, &nn, &c1, &c2, &weight );
			if ( type == 2 ) weight /= 4;
			for ( int nc = 0; nc < input.size(); nc++ )
			{
				if ( input[nc].number == nn ) input[nc].weight += weight;
			}
			continue;
		}

		else continue;
		if ( ni.number > maxp )
		{
			maxp = ni.number;
			p.maxn = input.size();
		}
		input.push_back( ni );
	}
	for ( int cc = p.psize; cc < input.size(); cc++ )
	{
		for ( int ccc = 0; ccc < input[cc].nc; ccc++ )
		{
			for ( int nc = 0; nc < input.size(); nc++ )
			{
				if ( input[nc].number == input[cc].c[ccc] ) 
				{
					input[cc].c[ccc] = nc;
					break;
				}
			}
		}
	}
	return 1;
}

int main( int argc, char **argv )
{
	if ( argc < 4 ) return 1;

	Protein p1;
	Protein p2;

	if ( !load( p1, argv[1] ) ) return 1;
	if ( !load( p2, argv[2] ) ) return 1;

	sol = new Path**[ p1.tsize ];
	for ( int sc = 0; sc < p1.tsize; sc++ )
	{
		sol[sc] = new Path*[ p2.tsize ];
		memset( sol[sc], 0, p2.tsize * sizeof( Path* ) );
	}
	Path *res = new Path;
	rmsd = new double*[ p1.tsize ];
	for ( int sc = 0; sc < p1.psize; sc++ )
	{
		rmsd[sc] = new double[ p2.psize ];
		memset( rmsd[sc], 0, p2.psize * sizeof( double ) );
	}
	calc_rmsd( p1, p2, res );
	for ( int ic = 0; ic < 1; ic++ )
	{
		for ( int sc = 0; sc < p1.tsize; sc++ )
		{
			for ( int scc = 0; scc < p2.tsize; scc++ ) 
			{
				delete sol[sc][scc];
				sol[sc][scc] = 0;
			}
		}
		delete res;
		res = new Path;
		double m = rec_compare_r( p1, p2, p1.maxn, p2.maxn, *res );
		//calc_rmsd( p1, p2, res );
		printf( "%g\n", m );
	}
		

	for ( int sc = 0; sc < p1.tsize; sc++ ) 
	{
		for ( int scc = 0; scc < p2.tsize; scc++ ) 
		{
			delete sol[sc][scc];
		}
		if ( sc < p1.psize ) delete rmsd[sc];
		delete sol[sc];
	}
	delete sol;
	delete rmsd;

	FILE *ofile = fopen( argv[3], "wt" );
	for ( int c = 0; c < res->p.size(); c++ )
	{
		fprintf( ofile, "%d %d %d\n", 
					p1.node[res->p[c].n1].pos, 
					p2.node[res->p[c].n2].pos,
					min( p1.node[res->p[c].n1].length, p2.node[res->p[c].n2].length ) );
	}
	fclose( ofile );

	return 0;
}
*/			

double FindCorr( VRes& r1, VRes& r2, int beg1, int beg2 )
{
	double res = 0;
	for ( int c1 = max( beg1, beg2 ); c1 < beg1 + r1.size() && c1 < beg2 + r2.size(); c1++ )
	{
		for ( int c2 = max( beg1, beg2 ); c2 < c1; c2++ )
		{
			if ( r1[ c1 - beg1 ].order == -1 || r1[ c2 - beg1 ].order == -1 || r1[ c1 - beg1 ].order == r1[ c2 - beg1 ].order ) continue;
			if ( r2[ c1 - beg2 ].order == -1 || r2[ c2 - beg2 ].order == -1 || r2[ c1 - beg2 ].order == r2[ c2 - beg2 ].order ) continue;
			double scale = 8;
			double d1 =  ( r1[c1-beg1].coord - r1[c2-beg1].coord ).norm();
			double f1 = exp( - d1 / scale );
			double d2 =  ( r2[c1-beg2].coord - r2[c2-beg2].coord ).norm();
			double f2 = exp( - d2 / scale );
			res += f1 * f2;
		}
	}
	return res;
}

double FindRMSD( VRes& r1, VRes& r2, int beg1, int beg2 )
{
	vector<Vector> v1, v2;
	for ( int c1 = max( beg1, beg2 ); c1 < beg1 + r1.size() && c1 < beg2 + r2.size(); c1++ )
	{
		v1.push_back( r1[ c1 - beg1 ].coord );
		v2.push_back( r2[ c1 - beg2 ].coord );
	}
	double res = FindRmsd( v1.size(), &( v1[0] ), &( v2[0] ) );
	res /= v1.size();
	return res;
}

int LoadChain( PChain& chain, const char *sname )
{
	FILE *ifile = fopen( sname, "rt" );
	if ( !ifile ) return 0;
	Line ll;
	if ( ll.Read( ifile ) != eOK ) return 0;
	if ( ll.GetType() != rHeader ) return 0;
	int ssize = ll.GetInt( fNumSS );
	chain.ss.resize( ssize );
	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF || res == eEOREC ) break;
		if ( res != eOK ) return 0;
		if ( l.GetType() == rSS )
		{
			int ss = l.GetInt( fOrder );
			if ( ss >= ssize ) return 0;
			chain.ss[ss].order = ss;
			chain.ss[ss].first = l.GetInt( fFirst );
			chain.ss[ss].size = l.GetInt( fSize );
			chain.ss[ss].seq.resize( chain.ss[ss].size );
			chain.ss[ss].res.resize( chain.ss[ss].size );
			chain.ss[ss].type = l.GetInt( fType );
			chain.ss[ss].center = l.GetVector( fCenter );
			chain.ss[ss].orientation = l.GetVector( fOrientation );
			chain.ss[ss].dir = l.GetVector( fDir );
		}
		else if ( l.GetType() == rSSDetail )
		{
			int ss = l.GetInt( fRef );
			if ( ss >= ssize ) return 0;
			int num = l.GetInt( fOrder ) - chain.ss[ss].first;
			if ( num >= chain.ss[ss].size ) return 0;
			chain.ss[ss].seq[num] = l.GetString( fLetter )[0];
			chain.ss[ss].res[num] = l.GetVector( fCenter );
		}
		else continue;
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}

int LoadPathway( PChain& chain, const char *pname, int pwnum )
{
	FILE *ifile = fopen( pname, "rt" );
	if ( !ifile ) return 0;
	do
	{
		Line ll;
		if ( ll.Read( ifile ) != eOK ) return 0;
		if ( ll.GetType() == rHeader ) 
		{
			chain.p.seq = ll.GetString( fSeq );
			continue;
		};
		if ( ll.GetType() != rStruct ) continue;
		if ( ll.GetInt( fOrder ) != pwnum ) continue;
		Line l;
		if ( ll.GetFirst( l ) ) do
		{
			if ( l.GetType() != rSS ) continue;
			Unit u;
			int order = l.GetInt( fOrder );
			int cluster = l.GetInt( fCluster );
			u.ss.type = l.GetInt( fType );
			u.ss.size = l.GetInt( fSize );
			u.ss.beg = l.GetInt( fFirst );
			u.sp.beg = l.GetVector( fCenter );
			u.sp.orientation = l.GetVector( fOrientation );
			u.sp.end = u.sp.beg + l.GetVector( fDir );
			if ( cluster <= chain.p.cluster.size() )
			{
				chain.p.cluster.resize( cluster + 1 );
			}
			chain.p.cluster[cluster].unit.push_back( u );
		}
		while ( ll.GetNext( l ) );
		break;
	}
	while ( 1 );
	fclose( ifile );
	return 1;
}


static void print_atom( FILE *ofile, int ac, char *aname, char *aatype, int rc, int lc, char chain, char *name, Vector coord )
{
	fprintf( ofile, 
		"ATOM   %4d  %-3.3s %-3.3s %c %3d     %7.3f %7.3f %7.3f  1.00 00.00 \n",
//		"ATOM   %4d  %-3.3s %-3.3s %c %3d     %7.3f %7.3f %7.3f  1.00 00.00      %4.4s%4d\n",
		ac, aname, aatype, chain, rc, coord.x, coord.y, coord.z );
}


int SavePdb( PChain &chain, int ss, int cluster, int unit, const char *oname )
{
	Unit& u = chain.p.cluster[cluster].unit[unit];
	CSS &css = chain.ss[ss];
	if ( u.ss.type != css.type ) return 0;
	if ( u.ss.size != css.size ) return 0;
	Vector v1[3], v2[3];
	v1[0] = css.center;
	v1[1] = css.center + css.orientation;
	v1[2] = css.center + css.dir;
	v2[0] = u.sp.beg;
	v2[1] = u.sp.beg + u.sp.orientation;
	v2[2] = u.sp.end;
	displacement *displ = FindDisplacement( 3, v1, v2 );
	//displacement *displ = find_it( 3, v1, v );
	if ( !displ ) return 0;
	/*
	char *a_name[] = {"ALA", "ASX", "CYS", "ASP", "GLU", "PHE", "GLY",
						"HIS", "ILE", "ACE", "LYS", "LEU", "MET", "ASN",
						"no ", "PRO", "GLN", "ARG", "SER", "THR", "UNK",
						"VAL", "TRP", "no ", "TYR", "GLX"};
	*/
	FILE *ofile = fopen( oname, "wt" );
	int ac = 0;
	int lc = 0;
	for ( int sc = 0; sc < chain.ss.size(); sc++ )
	{
   		for ( int pc = 0; pc < chain.ss[sc].size; pc++ )
   		{
   			Vector v = chain.ss[sc].center + chain.ss[sc].dir * ( double( pc ) / chain.ss[sc].size );
   			//if ( pc == 0 ) v = u.sp.beg + u.sp.orientation;
   			//if ( pc == u.ss.size - 1 ) v = last_last( u, i );
   			print_atom( ofile, ++ac, "CA", "ALA",
   				pc + chain.ss[sc].first, ++lc, 'F', "TST", v );
   		}
   		if ( sc + 1 == chain.ss.size() ) break;
   		int csize =  chain.ss[ sc + 1 ].first - chain.ss[sc].size - chain.ss[sc].first;
   		Vector last = chain.ss[sc].center + chain.ss[sc].dir;
   		for ( int pc = 0; pc < csize; pc++ )
   		{
   			Vector v = last + ( chain.ss[ sc + 1 ].center - last ) * ( double( pc ) / csize );
   			print_atom( ofile, ++ac, "CA", "ALA",
   				pc + chain.ss[sc].first + chain.ss[sc].size, ++lc, 'F', "TST", v );
   		}
   	}
   	Cluster &ccl = chain.p.cluster[cluster];
	for ( int uc = 0; uc < ccl.unit.size(); uc++ )
	{
   		for ( int pc = 0; pc < ccl.unit[uc].ss.size; pc++ )
   		{
   			Vector v = ccl.unit[uc].sp.beg + ( ccl.unit[uc].sp.end - ccl.unit[uc].sp.beg ) * ( double( pc ) / ccl.unit[uc].ss.size );
   			print_atom( ofile, ++ac, "CA", a_name[ chain.p.seq[ pc + ccl.unit[uc].ss.beg ] - 'A' ],
   				pc + ccl.unit[uc].ss.beg, ++lc, 'S', "TST", displ->Move( v ) );
   		}
   		if ( uc + 1 == ccl.unit.size() ) break;
   		int csize = ccl.unit[ uc + 1 ].ss.beg - ccl.unit[uc].ss.beg - ccl.unit[uc].ss.size;
   		for ( int pc = 0; pc < csize; pc++ )
   		{
   			Vector v = ccl.unit[uc].sp.end + ( ccl.unit[uc+1].sp.beg - ccl.unit[uc].sp.end ) * ( double( pc ) / csize );
   			print_atom( ofile, ++ac, "CA", "ALA",
   				pc + ccl.unit[uc].ss.beg + ccl.unit[uc].ss.size, ++lc, 'S', "TST", displ->Move(v) );
   		}
   	}
   	delete displ;
   	fclose( ofile );
   	return 1;
}

int SaveSS( PChain &chain, const char *oname )
{
	FILE *ofile = fopen( oname, "wt" );
	int ac = 0;
	int lc = 0;
	for ( int sc = 0; sc < chain.ss.size(); sc++ )
	{
   		for ( int pc = 0; pc < chain.ss[sc].size; pc++ )
   		{
   			Vector v = chain.ss[sc].center + chain.ss[sc].dir * ( double( pc ) / chain.ss[sc].size );
   			//if ( pc == 0 ) v = u.sp.beg + u.sp.orientation;
   			//if ( pc == u.ss.size - 1 ) v = last_last( u, i );
   			print_atom( ofile, ++ac, "CA", "ALA",
   				pc + chain.ss[sc].first, ++lc, 'F', "TST", v );
   		}
   		if ( sc + 1 == chain.ss.size() ) break;
   		int csize =  chain.ss[ sc + 1 ].first - chain.ss[sc].size - chain.ss[sc].first;
   		Vector last = chain.ss[sc].center + chain.ss[sc].dir;
   		for ( int pc = 0; pc < csize; pc++ )
   		{
   			Vector v = last + ( chain.ss[ sc + 1 ].center - last ) * ( double( pc ) / csize );
   			print_atom( ofile, ++ac, "CA", "ALA",
   				pc + chain.ss[sc].first + chain.ss[sc].size, ++lc, 'F', "TST", v );
   		}
   	}

   	fclose( ofile );
   	return 1;
}

int RealStruct( PChain &chain, VRes& vv )
{
	int rv = chain.ss[0].first;
	int lc = 0;
	for ( int sc = 0; sc < chain.ss.size(); sc++ )
	{
   		for ( int pc = 0; pc < chain.ss[sc].size; pc++ )
   		{
   			Vector v = chain.ss[sc].center + chain.ss[sc].dir * ( double( pc ) / chain.ss[sc].size );
			vv.push_back( PResidue( v, pc ) );
   		}
   		if ( sc + 1 == chain.ss.size() ) break;
   		int csize =  chain.ss[ sc + 1 ].first - chain.ss[sc].size - chain.ss[sc].first;
   		Vector last = chain.ss[sc].center + chain.ss[sc].dir;
   		for ( int pc = 0; pc < csize; pc++ )
   		{
   			Vector v = last + ( chain.ss[ sc + 1 ].center - last ) * ( double( pc ) / csize );
			vv.push_back( PResidue( v, -1 ) );
   		}
   	}
	return rv;
}

int ImagStruct( PChain &chain, VRes& vv )
{
   	Cluster &ccl = chain.p.cluster[0];
	int rv = ccl.unit[0].ss.beg;
	for ( int uc = 0; uc < ccl.unit.size(); uc++ )
	{
   		for ( int pc = 0; pc < ccl.unit[uc].ss.size; pc++ )
   		{
   			Vector v = ccl.unit[uc].sp.beg + ( ccl.unit[uc].sp.end - ccl.unit[uc].sp.beg ) * ( double( pc ) / ccl.unit[uc].ss.size );
			vv.push_back( PResidue( v, pc ) );
   		}
   		if ( uc + 1 == ccl.unit.size() ) break;
   		int csize = ccl.unit[ uc + 1 ].ss.beg - ccl.unit[uc].ss.beg - ccl.unit[uc].ss.size;
   		for ( int pc = 0; pc < csize; pc++ )
   		{
   			Vector v = ccl.unit[uc].sp.end + ( ccl.unit[uc+1].sp.beg - ccl.unit[uc].sp.end ) * ( double( pc ) / csize );
			vv.push_back( PResidue( v, -1 ) );
   		}
   	}
   	return rv;
}

int LoadBestPathway( PChain& chain, const char *pname )
{
	VRes real;
	int realBeg = RealStruct( chain, real );
	FILE *ifile = fopen( pname, "rt" );
	if ( !ifile ) return 0;
	double measure = 0;
	int best = -1;
	do
	{
		Line ll;
		int rl = ll.Read( ifile );
		if ( rl == eEOF ) break;
		if ( rl != eOK ) return 0;
		if ( ll.GetType() == rHeader ) 
		{
			chain.p.seq = ll.GetString( fSeq );
			continue;
		};
		if ( ll.GetType() != rStruct ) continue;
		int order = ll.GetInt( fOrder );
		Line l;
		chain.p.cluster.clear();
		if ( ll.GetFirst( l ) ) do
		{
			if ( l.GetType() != rSS ) continue;
			Unit u;
			int order = l.GetInt( fOrder );
			int cluster = 0;
			u.ss.type = l.GetInt( fType );
			u.ss.size = l.GetInt( fSize );
			u.ss.beg = l.GetInt( fFirst );
			u.sp.beg = l.GetVector( fCenter );
			u.sp.orientation = l.GetVector( fOrientation );
			u.sp.end = u.sp.beg + l.GetVector( fDir );
			if ( cluster <= chain.p.cluster.size() )
			{
				chain.p.cluster.resize( cluster + 1 );
			}
			chain.p.cluster[cluster].unit.push_back( u );
		}
		while ( ll.GetNext( l ) );
		if ( !chain.p.cluster.size() ) continue;
		VRes imag;
		int imagBeg = ImagStruct( chain, imag );
		//double res = FindCorr( real, imag, realBeg, imagBeg );
		double res = 1./FindRMSD( real, imag, realBeg, imagBeg );
		/*
		if ( res / size < measure )
		{
			measure = res / size;
			best = order;
		}
		*/
		if ( res > measure )
		{
			measure = res;
			best = order;
		}
	}
	while ( 1 );
	fclose( ifile );
	if ( best == -1 ) return 0;
	printf( "best %d, measure %g\n", best, measure );
	chain.p.cluster.clear();
	return LoadPathway( chain, pname, best );
	return 1;
}

int SaveSinglePdb( PChain &chain, const char *oname )
{
	FILE *ofile = fopen( oname, "wt" );
	int ac = 0;
	int lc = 0;
   	Cluster &ccl = chain.p.cluster[0];
	for ( int uc = 0; uc < ccl.unit.size(); uc++ )
	{
   		for ( int pc = 0; pc < ccl.unit[uc].ss.size; pc++ )
   		{
   			Vector v = ccl.unit[uc].sp.beg + ( ccl.unit[uc].sp.end - ccl.unit[uc].sp.beg ) * ( double( pc ) / ccl.unit[uc].ss.size );
   			print_atom( ofile, ++ac, "CA", a_name[ chain.p.seq[ pc + ccl.unit[uc].ss.beg ] - 'A' ],
   				pc + ccl.unit[uc].ss.beg, ++lc, 'S', "TST", v );
   		}
   		if ( uc + 1 == ccl.unit.size() ) break;
   		int csize = ccl.unit[ uc + 1 ].ss.beg - ccl.unit[uc].ss.beg - ccl.unit[uc].ss.size;
   		for ( int pc = 0; pc < csize; pc++ )
   		{
   			Vector v = ccl.unit[uc].sp.end + ( ccl.unit[uc+1].sp.beg - ccl.unit[uc].sp.end ) * ( double( pc ) / csize );
   			print_atom( ofile, ++ac, "CA", a_name[ chain.p.seq[ pc + ccl.unit[uc].ss.beg + ccl.unit[uc].ss.size ] - 'A' ],
   				pc + ccl.unit[uc].ss.beg + ccl.unit[uc].ss.size, ++lc, 'S', "TST", v );
   		}
   	}
   	fclose( ofile );
   	return 1;
}

#define coord( ch, i ) ch.residue[i].atom[aCA].coord
#define CMP
#include "build.cpp"
#include "counters.h"

void GDT_TS( PChain &chain, const char *rname, const char *iname )
{
	Chain rch;
	LoadChain( rch, rname );
	if ( !rch.residue.size() )
	{
		printf( "can't load real structure from %s\n", rname );
		return;
	}
	Chain ich;
	LoadChain( ich, iname );
	if ( !ich.residue.size() )
	{
		printf( "can't load predicted structure from %s\n", iname );
		return;
	}
   	Cluster &ccl = chain.p.cluster[0];
	int ibeg = ccl.unit[0].ss.beg;
	vector<Vector> v1, v2;
	for ( int uc = 0; uc < ccl.unit.size(); uc++ )
	{
   		for ( int pc = 0; pc < ccl.unit[uc].ss.size; pc++ )
   		{
			int pos = ccl.unit[uc].ss.beg + pc;
			if ( pos - ibeg >= ich.residue.size() ) break;
			v1.push_back( coord( rch, pos ) );
			v2.push_back( coord( ich, pos - ibeg ) );
   		}
   	}
	displacement *d = FindDisplacement( v1.size(), &(v1[0]), &(v2[0]) );
	double score[5]= { 0 };
	double threshold[4] = { 1, 2, 4, 8 };
	for ( int c1 = 0; c1 < ich.residue.size(); c1++ )
	{
		double dist = ( coord( rch, c1 + ibeg ) - d->Move( coord( ich, c1 ) ) ).norm();
		//double dist = ( coord( rch, c1 + ibeg ) - coord( ich, c1 ) ).norm();
		for ( int tc = 0; tc < 4; tc++ )
		{
			if ( dist < threshold[tc] ) 
			{
				score[tc]++;
				score[4]++;
			}
		}
	}
	score[4] *= 0.25;
	printf( "%g %g %g %g ;avg = %g\n", score[0], score[1], score[2], score[3], score[4] );
	FILE *ofile = fopen( "res.pdb", "wt" );
	int acc = 0;
	for ( int rc = 0; rc < rch.residue.size(); rc++ )
	{
		Residue& r = rch.residue[rc];
		for ( int ac = 0; ac < r.atom.size(); ac++ )
		{
   			print_atom( ofile, ++acc, r.atom[ac].name, r.name3, rc, 0, 'F', "TST", r.atom[ac].coord );
		}
	}
	for ( int rc = 0; rc < ich.residue.size(); rc++ )
	{
		Residue& r = ich.residue[rc];
		for ( int ac = 0; ac < r.atom.size(); ac++ )
		{
   			print_atom( ofile, ++acc, r.atom[ac].name, r.name3, rc, 0, 'S', "TST", d->Move( r.atom[ac].coord ) );
		}
	}
	delete d;
}

struct ISS
{
	int type;
	int size;
	ISS() {};
	ISS( int aType, int aSize ) { type = aType; size = aSize; }
};

struct WInput
{
	map< ISS, LastData, Comparer<ISS> > last;
	string seq;
};

static WInput *winput = 0;

bool LoadWeights( WInput& i, const char *fname )
{
	FILE *ifile = fopen( fname, "rt" );
	if ( !ifile ) return false;

	do
	{
		Line l;
		int res = l.Read( ifile );
		if ( res == eEOF ) break;

		if ( res != eOK ) return false;
		if ( l.GetType() == rLast )
		{
			ISS ss;
			LastData last;
			ss.type = l.GetInt( fType );
			ss.size = l.GetInt( fSize );
			last.dist = l.GetDouble( fDistance );
			last.angle = l.GetDouble( fAngle );
			last.last = l.GetDouble( fLast );
			last.weight = l.GetDouble( fValue );
			i.last[ss] = last;
		}
	}
	while ( 1 );
	fclose( ifile );
	return true;
}

double perturb( double ampl )
{
	return rand() * 2 * ampl / RAND_MAX - ampl;
}

void SaveSCPdb( PChain& chain, const char *oname, bool loops = false )
{
   	Cluster &ccl = chain.p.cluster[0];
	Chain schain;
	for ( int uc = 0; uc < ccl.unit.size(); uc++ )
	{
		const char *seq = chain.p.seq.data() + ccl.unit[uc].ss.beg;
		if ( ccl.unit[uc].ss.type == 0 ) BuildBeta( schain, ccl.unit[uc], ccl.unit[uc].ss.beg, seq );
		else if ( winput ) 
		{
			BuildAlpha( schain, ccl.unit[uc], winput->last[ 
				ISS( ccl.unit[uc].ss.type, ccl.unit[uc].ss.size ) ].angle, 
				ccl.unit[uc].ss.beg, seq, true );
		}
		else BuildAlpha( schain, ccl.unit[uc], 0, ccl.unit[uc].ss.beg, seq, false );
	}
	RotChain rchain;
	BuildSide( rchain, schain );
	Chain nchain;
	nchain.residue.resize( schain.residue.size() );
	PredictSide( nchain, rchain );
	if ( !loops )
	{
		SaveChain( nchain, oname );
		return;
	}
	int rc = 0;
	for ( int uc = 0; uc < ccl.unit.size() - 1; uc++ )
	{
   		int csize = ccl.unit[ uc + 1 ].ss.beg - ccl.unit[uc].ss.beg - ccl.unit[uc].ss.size;
		rc += ccl.unit[uc].ss.size;
   		for ( int pc = 0; pc < csize; pc++ )
   		{
   			Vector v = ccl.unit[uc].sp.end + ( ccl.unit[uc+1].sp.beg - ccl.unit[uc].sp.end ) * ( double( pc ) / csize );
			v.x += perturb( 0.3 );
			v.y += perturb( 0.3 );
			v.z += perturb( 0.3 );
			Residue r;
			r.number = rc + ccl.unit[0].ss.beg;
			r.name1 = chain.p.seq[ rc ];
			strcpy( r.name3, a_name[ r.name1 - 'A' ] );
			r.order = -1;
			r.center = v;
			r.atom.resize( 1 );
			r.atom[0].coord = v;
			strcpy( r.atom[0].name, "CA" );
   			nchain.residue.insert( nchain.residue.begin() + rc, r );
			rc++;
   		}
	}
	SaveChain( nchain, oname );
}

void OptimizeLoops( PChain& chain, const char *oname )
{
	SaveSCPdb( chain, "tmp-1.pdb", true );
   	Cluster &ccl = chain.p.cluster[0];
	char buf[100];
	
	/*
	FILE *pfile = fopen( "tmp.plop", "wt" );
	fprintf( pfile, "datadir /home/sergey/soft/plop/data/\n" );
	fprintf( pfile, "load pdb tmp-1.pdb\n" );
	*/
	/*
	for ( int uc = 0; uc < ccl.unit.size() - 1; uc++ )
	{
	
		fprintf( pfile, "loop predict _:%d _:%d\n", 
			ccl.unit[uc].ss.beg + ccl.unit[uc].ss.size - 1, ccl.unit[ uc + 1 ].ss.beg );
	}
	*/
	/*
	fprintf( pfile, "write pdb tmp-2.pdb\n" );
	fclose( pfile );
	system( "plop tmp.plop" );
	FILE *ofile = fopen( "tmp-3.pdb", "wt" );
	FILE *ifile = fopen( "tmp-2.pdb", "rt" );
	while( fgets( buf, 100, ifile ) )
	{
		if ( strncmp( buf, "ATOM", 4 ) == 0 )
		{
			fputs( buf, ofile );
		}
	}
	fclose( ifile );
	fclose( ofile );
	*/
	system( "cp tmp-1.pdb tmp-2.pdb" );
	for ( int uc = 0; uc < ccl.unit.size() - 1; uc++ )
	{
		int beg = ccl.unit[uc].ss.beg + ccl.unit[uc].ss.size - 1;
		int end = ccl.unit[uc+1].ss.beg;
		if ( end - beg < 4 )
		{
			beg--;
			end++;
		}
		int coffset = ( uc == 0 ) ? 0 : ccl.unit[0].ss.beg;
		sprintf( buf, "loopy -obj %d-%d -res %*.*s tmp-2.pdb", beg - coffset, end - coffset, 
			end - beg + 1, end - beg + 1, chain.p.seq.data() + beg );
		printf( "%s\n", buf );
		system( buf );
		if ( access( "tmp-2_loopy.pdb", R_OK ) == 0 ) system( "mv tmp-2_loopy.pdb tmp-2.pdb" );
	}
	sprintf( buf, "./gromacs.sh tmp-2 %s", oname );
	system( buf );
	/*
	pfile = fopen( "tmp.plop", "wt" );
	fprintf( pfile, "datadir /home/sergey/soft/plop/data/\n" );
	fprintf( pfile, "load pdb tmp-4.pdb\n" );
	fprintf( pfile, "minim res all res\n" );
	fprintf( pfile, "write pdb tmp-5.pdb\n", oname );
	fclose( pfile );
	system( "plop tmp.plop" );
	ofile = fopen( oname, "wt" );
	ifile = fopen( "tmp-5.pdb", "rt" );
	while( fgets( buf, 100, ifile ) )
	{
		if ( strncmp( buf, "ATOM", 4 ) == 0 )
		{
			fputs( buf, ofile );
		}
	}
	fclose( ifile );
	fclose( ofile );
	*/
	
}

struct Input
{
	string pname;
	int pnum;
	int unum;
	string sname;
	int snum;
	string oname;
	string iname;
	bool best;
	bool pair;
	bool sc;
	bool plop;
	bool justss;
	string rname;
	string prname;
	bool gdt_ts;
};

int ParseInput( Input& I, int argc, char **argv )
{
	I.oname = "res.pdb";
	I.pnum = 1;
	I.unum = 0;
	I.snum = 0;
	I.best = false;
	I.pair = false;
	I.sc = false;
	I.plop = false;
	I.justss = false;
	I.gdt_ts = false;
	for ( int ac = 1; ac < argc; ac++ )
	{
		if ( ( strcmp( argv[ac], "-p" ) == 0 ) && ac + 1 < argc )
		{
			I.pname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-o" ) == 0 ) && ac + 1 < argc )
		{
			I.oname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-s" ) == 0 ) && ac + 1 < argc )
		{
			I.sname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-rname" ) == 0 ) && ac + 1 < argc )
		{
			I.rname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-prname" ) == 0 ) && ac + 1 < argc )
		{
			I.prname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-i" ) == 0 ) && ac + 1 < argc )
		{
			I.iname = argv[ac+1];
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-n" ) == 0 ) && ac + 1 < argc )
		{
			I.pnum = atoi( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-u" ) == 0 ) && ac + 1 < argc )
		{
			I.unum = atoi( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-ss" ) == 0 ) && ac + 1 < argc )
		{
			I.snum = atoi( argv[ac+1] );
			ac++;
		}
		else if ( ( strcmp( argv[ac], "-b" ) == 0 ) )
		{
			I.best = true;
			I.pair = false;
		}
		else if ( ( strcmp( argv[ac], "-bb" ) == 0 ) )
		{
			I.best = true;
			I.pair = true;
		}
		else if ( ( strcmp( argv[ac], "-sc" ) == 0 ) )
		{
			I.sc = true;
		}
		else if ( ( strcmp( argv[ac], "-plop" ) == 0 ) )
		{
			I.plop = true;
		}
		else if ( ( strcmp( argv[ac], "-gdt_ts" ) == 0 ) )
		{
			I.gdt_ts = true;
		}
		else if ( ( strcmp( argv[ac], "-justss" ) == 0 ) )
		{
			I.justss = true;
		}
	}
	if ( I.justss && !I.sname.size() || !I.justss && !I.pname.size() )
	{
		printf( "No input file\n" );
		return 0;
	}
	return 1;
}

int main( int argc, char *argv[] )
{
	if ( argc < 2 )
	{
		printf( "usage: cmp -p <pwname> [ -n <pwnum> ] [ -s <ssname> ] [ -u <unit> ] [ -ss <ssnum> ]\n" );
		return 1;
	}
	Input I;
	if ( !ParseInput( I, argc, argv ) ) return 1;
	PChain chain;
	if ( I.sname.size() )
	{
		if ( !LoadChain( chain, I.sname.data() ) )
		{
			printf( "can't load ss\n" );
			return 1;
		}
		if ( I.justss )
		{
			SaveSS( chain, I.oname.data() );
			return 0;
		}
	}
	if ( I.iname.size() )
	{
		winput = new WInput;
		if ( !LoadWeights( *winput, I.iname.data() ) )
		{
			printf( "can't load geom data file\n" );
			return 1;
		}
	}
	if ( !I.best && !LoadPathway( chain, I.pname.data(), I.pnum ) )
	{
		printf( "can't load pathway\n" );
		return 1;
	}
	if ( I.gdt_ts )
	{
		GDT_TS( chain, I.rname.data(), I.prname.data() );
		return 0;
	}
	if ( I.sname.size() )
	{
		if ( I.best )
		{
			if ( !LoadBestPathway( chain, I.pname.data() ) )
			{
				printf( "can't load best pathway\n" );
				return 1;
			}
			SaveSinglePdb( chain, I.oname.data() );
		}
		if ( !SavePdb( chain, I.snum, 0, I.unum, I.oname.data() ) )
		{
			printf( "ss records don't match\n" );
			return 1;
		}
	}
	else if ( I.sc ) SaveSCPdb( chain, I.oname.data() );
	else if ( I.plop ) OptimizeLoops( chain, I.oname.data() );
	else SaveSinglePdb( chain, I.oname.data() );
	return 0;
}

